"""
Climate Variable Categorizer
Sistem kategorisasi 8 variabel iklim berdasarkan standar:
- WMO (World Meteorological Organization)
- BMD (Bangladesh Meteorological Department)
- FFWC (Flood Forecasting & Warning Centre Bangladesh)
- IPCC AR6 (sea level)
"""
from dataclasses import dataclass, field
from typing import Optional, List
from datetime import datetime


@dataclass
class Category:
    code: str
    label_en: str
    label_bn: str
    color: str
    level: int          # 0=normal 1=watch 2=warning 3=danger 4=extreme
    description: str
    action: str

    def to_dict(self):
        return {
            "code": self.code, "label_en": self.label_en, "label_bn": self.label_bn,
            "color": self.color, "level": self.level,
            "description": self.description, "action": self.action,
        }


#  1. SUHU UDARA (WMO + BMD Bangladesh) 
TEMP_CATS = [
    Category("VERY_COLD",    "Very Cold",    "অত শতল",     "#93c5fd", 2, "Below 10C - unusually cold", "Protect crops and livestock"),
    Category("COLD",         "Cold",         "শতল",          "#60a5fa", 1, "10-18C - cold season", "Wear warm clothing"),
    Category("COOL",         "Cool",         "ঠনড",         "#34d399", 0, "18-24C - comfortable cool", "Normal activities"),
    Category("NORMAL",       "Normal",       "সবভবক",     "#22c55e", 0, "24-30C - typical Bangladesh", "Normal activities"),
    Category("WARM",         "Warm",         "উষণ",           "#fbbf24", 1, "30-35C - warm, stay hydrated", "Drink water frequently"),
    Category("HOT",          "Hot",          "গরম",            "#f97316", 2, "35-40C - heat stress risk", "Avoid midday sun"),
    Category("VERY_HOT",     "Very Hot",     "অত গরম",       "#ef4444", 3, "40-45C - dangerous heat", "Stay indoors"),
    Category("EXTREME_HEAT", "Extreme Heat", "তবর তপপরবহ","#7f1d1d", 4, "Above 45C - life-threatening", "Emergency measures"),
]

def categorize_temperature(t):
    if t < 10:   return TEMP_CATS[0]
    elif t < 18: return TEMP_CATS[1]
    elif t < 24: return TEMP_CATS[2]
    elif t < 30: return TEMP_CATS[3]
    elif t < 35: return TEMP_CATS[4]
    elif t < 40: return TEMP_CATS[5]
    elif t < 45: return TEMP_CATS[6]
    else:        return TEMP_CATS[7]


#  2. CURAH HUJAN (BMD Bangladesh + WMO) 
RAIN_1H_CATS = [
    Category("NO_RAIN",    "No Rain",     "বষট নই",    "#1e293b", 0, "0 mm/h", "Normal"),
    Category("LIGHT",      "Light Rain",  "হলক বষট",  "#93c5fd", 0, "0.1-2.5 mm/h", "Normal activities"),
    Category("MODERATE",   "Moderate",    "মঝর বষট", "#3b82f6", 1, "2.5-7.5 mm/h", "Carry umbrella"),
    Category("HEAVY",      "Heavy Rain",  "ভর বষট",   "#1d4ed8", 2, "7.5-15 mm/h", "Avoid flooding areas"),
    Category("VERY_HEAVY", "Very Heavy",  "অত ভর",      "#f97316", 3, "15-30 mm/h", "Stay indoors, flood risk"),
    Category("EXTREME",    "Extreme",     "পরচণড বষট", "#ef4444", 4, ">30 mm/h", "Flash flood danger"),
]

RAIN_24H_CATS = [
    Category("NO_RAIN",    "No Rain",     "বষট নই",    "#1e293b", 0, "0 mm/day", "Normal"),
    Category("LIGHT",      "Light",       "হলক",          "#93c5fd", 0, "1-10 mm/day", "Normal"),
    Category("MODERATE",   "Moderate",    "মঝর",         "#3b82f6", 1, "10-35 mm/day", "Monitor"),
    Category("HEAVY",      "Heavy",       "ভর",           "#1d4ed8", 2, "35-65 mm/day", "Flood watch"),
    Category("VERY_HEAVY", "Very Heavy",  "অত ভর",      "#f97316", 3, "65-125 mm/day", "Flood warning"),
    Category("EXTREME",    "Extreme",     "চরম",            "#ef4444", 4, ">125 mm/day", "Severe flood danger"),
]

def categorize_rainfall_1h(mm):
    if mm <= 0:    return RAIN_1H_CATS[0]
    elif mm < 2.5: return RAIN_1H_CATS[1]
    elif mm < 7.5: return RAIN_1H_CATS[2]
    elif mm < 15:  return RAIN_1H_CATS[3]
    elif mm < 30:  return RAIN_1H_CATS[4]
    else:          return RAIN_1H_CATS[5]

def categorize_rainfall_24h(mm):
    if mm <= 0:    return RAIN_24H_CATS[0]
    elif mm < 10:  return RAIN_24H_CATS[1]
    elif mm < 35:  return RAIN_24H_CATS[2]
    elif mm < 65:  return RAIN_24H_CATS[3]
    elif mm < 125: return RAIN_24H_CATS[4]
    else:          return RAIN_24H_CATS[5]

#  3. KELEMBAPAN UDARA (WMO comfort index) 
HUM_CATS = [
    Category("VERY_DRY",    "Very Dry",     "অত শষক",    "#fde68a", 2, "<20% - very dry, fire risk", "Humidify, protect crops"),
    Category("DRY",         "Dry",          "শষক",         "#fbbf24", 1, "20-40% - dry conditions", "Stay hydrated"),
    Category("COMFORTABLE", "Comfortable",  "আরমদযক",    "#22c55e", 0, "40-60% - ideal humidity", "Normal activities"),
    Category("HUMID",       "Humid",        "আরদর",         "#60a5fa", 1, "60-75% - humid", "Normal with caution"),
    Category("VERY_HUMID",  "Very Humid",   "অত আরদর",   "#3b82f6", 2, "75-90% - very humid, heat stress", "Limit strenuous activity"),
    Category("OPPRESSIVE",  "Oppressive",   "দমবনধ",        "#ef4444", 3, ">90% - oppressive, health risk", "Stay cool, monitor health"),
]

def categorize_humidity(pct):
    if pct < 20:   return HUM_CATS[0]
    elif pct < 40: return HUM_CATS[1]
    elif pct < 60: return HUM_CATS[2]
    elif pct < 75: return HUM_CATS[3]
    elif pct < 90: return HUM_CATS[4]
    else:          return HUM_CATS[5]


#  4. KECEPATAN & ARAH ANGIN (Beaufort + Bangladesh Cyclone) 
WIND_CATS = [
    Category("CALM",     "Calm",         "শনত",          "#22c55e", 0, "0-5 km/h", "Normal"),
    Category("LIGHT",    "Light Breeze", "হলক বতস",   "#86efac", 0, "5-20 km/h", "Normal"),
    Category("MODERATE", "Moderate",     "মঝর বতস",  "#fbbf24", 1, "20-40 km/h", "Secure loose objects"),
    Category("STRONG",   "Strong",       "তবর বতস",   "#f97316", 2, "40-60 km/h", "Avoid outdoor activities"),
    Category("GALE",     "Gale",         "ঝড বতস",    "#ef4444", 3, "60-90 km/h", "Stay indoors"),
    Category("STORM",    "Storm",        "ঝড",            "#b91c1c", 3, "90-120 km/h", "Emergency shelter"),
    Category("CYCLONE",  "Cyclone",      "ঘরণঝড",     "#7f1d1d", 4, ">120 km/h", "Immediate evacuation"),
]

WIND_DIRS = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"]
WIND_DIR_BN = {
    "N":"উততর","NE":"উততর-পরব","E":"পরব","SE":"দকষণ-পরব",
    "S":"দকষণ","SW":"দকষণ-পশচম","W":"পশচম","NW":"উততর-পশচম",
}

def degrees_to_direction(deg):
    return WIND_DIRS[round(deg / 22.5) % 16]

def categorize_wind_speed(kmh):
    if kmh < 5:    return WIND_CATS[0]
    elif kmh < 20: return WIND_CATS[1]
    elif kmh < 40: return WIND_CATS[2]
    elif kmh < 60: return WIND_CATS[3]
    elif kmh < 90: return WIND_CATS[4]
    elif kmh < 120:return WIND_CATS[5]
    else:          return WIND_CATS[6]


#  5. GELOMBANG PANAS / HEATWAVE (WMO) 
HW_CATS = [
    Category("NONE",      "No Heatwave",   "তপপরবহ নই", "#22c55e", 0, "Normal temperature", "Normal"),
    Category("WATCH",     "Heat Watch",    "তপ সতরকত",   "#fbbf24", 1, "Temp >33C, 1-2 days", "Stay hydrated"),
    Category("WARNING",   "Heat Warning",  "তপ সতরকবরত","#f97316", 2, "Temp >35C, 3+ days", "Limit outdoor exposure"),
    Category("EMERGENCY", "Heat Emergency","তপ জরর",      "#ef4444", 3, "Temp >38C, 3+ days", "Emergency cooling centers"),
    Category("EXTREME",   "Extreme Heat",  "চরম তপপরবহ", "#7f1d1d", 4, "Temp >40C, 3+ days", "Life-threatening"),
]

def categorize_heatwave(temp_c, consecutive_hot_days=0):
    if consecutive_hot_days < 1 or temp_c < 33: return HW_CATS[0]
    elif temp_c < 35 or consecutive_hot_days < 3: return HW_CATS[1]
    elif temp_c < 38: return HW_CATS[2]
    elif temp_c < 40: return HW_CATS[3]
    else:             return HW_CATS[4]

def calculate_heat_index(temp_c, humidity_pct):
    """Rothfusz heat index equation."""
    T = temp_c * 9/5 + 32
    RH = humidity_pct
    HI = (-42.379 + 2.04901523*T + 10.14333127*RH - 0.22475541*T*RH
          - 0.00683783*T*T - 0.05481717*RH*RH + 0.00122874*T*T*RH
          + 0.00085282*T*RH*RH - 0.00000199*T*T*RH*RH)
    return (HI - 32) * 5/9


#  6. KEKERINGAN / DROUGHT (SPI-based, WMO) 
DROUGHT_CATS = [
    Category("NONE",       "No Drought",       "খর নই",       "#22c55e", 0, "Normal or above-normal rainfall", "Normal"),
    Category("ABNORM_DRY", "Abnormally Dry",   "অসবভবক শষক","#fde68a", 1, "Slightly below normal", "Monitor water levels"),
    Category("MODERATE",   "Moderate Drought", "মঝর খর",    "#fbbf24", 2, "Rainfall 50-75% of normal", "Water conservation"),
    Category("SEVERE",     "Severe Drought",   "তবর খর",     "#f97316", 3, "Rainfall 25-50% of normal", "Crop failure risk"),
    Category("EXTREME",    "Extreme Drought",  "চরম খর",       "#ef4444", 4, "Rainfall <25% of normal", "Emergency water supply"),
    Category("EXCEPTIONAL","Exceptional",      "অসধরণ খর",  "#7f1d1d", 4, "Exceptional drought", "Disaster declaration"),
]

def categorize_drought(rainfall_pct_of_normal):
    if rainfall_pct_of_normal >= 85:   return DROUGHT_CATS[0]
    elif rainfall_pct_of_normal >= 75: return DROUGHT_CATS[1]
    elif rainfall_pct_of_normal >= 50: return DROUGHT_CATS[2]
    elif rainfall_pct_of_normal >= 25: return DROUGHT_CATS[3]
    elif rainfall_pct_of_normal >= 10: return DROUGHT_CATS[4]
    else:                              return DROUGHT_CATS[5]


#  7. BANJIR (FFWC Bangladesh) 
FLOOD_CATS = [
    Category("NORMAL",       "Normal",        "সবভবক",    "#22c55e", 0, "River below 70% of danger level", "Normal"),
    Category("WATCH",        "Flood Watch",   "বনয সতরকত","#86efac", 1, "River 70-80% of danger level", "Monitor river levels"),
    Category("WARNING",      "Flood Warning", "বনয সতরকবরত","#fbbf24", 2, "River 80-90% of danger level", "Prepare for flooding"),
    Category("ALERT",        "Flood Alert",   "বনয সতরক",  "#f97316", 3, "River 90-100% of danger level", "Prepare evacuation"),
    Category("FLOOD",        "Flooding",      "বনয",         "#ef4444", 3, "River above danger level", "Evacuate flood-prone areas"),
    Category("SEVERE_FLOOD", "Severe Flood",  "তবর বনয",  "#b91c1c", 4, "River >120% of danger level", "Emergency evacuation"),
    Category("EXTREME_FLOOD","Extreme Flood", "চরম বনয",    "#7f1d1d", 4, "River >150% of danger level", "Disaster response"),
]

def categorize_flood(water_level_m, danger_level_m):
    if danger_level_m <= 0: return FLOOD_CATS[0]
    r = water_level_m / danger_level_m
    if r < 0.70:   return FLOOD_CATS[0]
    elif r < 0.80: return FLOOD_CATS[1]
    elif r < 0.90: return FLOOD_CATS[2]
    elif r < 1.00: return FLOOD_CATS[3]
    elif r < 1.20: return FLOOD_CATS[4]
    elif r < 1.50: return FLOOD_CATS[5]
    else:          return FLOOD_CATS[6]

def categorize_flood_probability(prob):
    if prob < 0.15:   return FLOOD_CATS[0]
    elif prob < 0.30: return FLOOD_CATS[1]
    elif prob < 0.50: return FLOOD_CATS[2]
    elif prob < 0.70: return FLOOD_CATS[3]
    elif prob < 0.85: return FLOOD_CATS[4]
    elif prob < 0.95: return FLOOD_CATS[5]
    else:             return FLOOD_CATS[6]


#  8. KENAIKAN MUKA LAUT (IPCC AR6 + Bangladesh coastal) 
SEA_CATS = [
    Category("NORMAL",    "Normal",     "সবভবক",    "#22c55e", 0, "Normal sea level", "Normal"),
    Category("ELEVATED",  "Elevated",   "উননত",         "#fbbf24", 1, "Slightly above normal (+0.1-0.3m)", "Monitor coastal areas"),
    Category("HIGH",      "High",       "উচচ",          "#f97316", 2, "Above normal (+0.3-0.5m)", "Coastal flood watch"),
    Category("VERY_HIGH", "Very High",  "অত উচচ",     "#ef4444", 3, "Well above normal (+0.5-1.0m)", "Coastal evacuation warning"),
    Category("EXTREME",   "Extreme",    "চরম",           "#7f1d1d", 4, "Extreme surge (>1.0m above normal)", "Emergency coastal evacuation"),
]

def categorize_sea_level_anomaly(anomaly_m):
    if anomaly_m < 0.1:   return SEA_CATS[0]
    elif anomaly_m < 0.3: return SEA_CATS[1]
    elif anomaly_m < 0.5: return SEA_CATS[2]
    elif anomaly_m < 1.0: return SEA_CATS[3]
    else:                 return SEA_CATS[4]

def estimate_sea_level_from_pressure(pressure_hpa, baseline_hpa=1013.25):
    """Inverted barometer: 1 hPa drop = +1 cm sea level rise."""
    return (baseline_hpa - pressure_hpa) / 100.0

#  COMPREHENSIVE ASSESSMENT 
@dataclass
class ClimateAssessment:
    zone_id: str
    assessed_at: datetime
    temperature: object
    rainfall_1h: object
    rainfall_24h: object
    humidity: object
    wind_speed: object
    wind_direction: str
    heatwave: object
    heat_index_c: object
    drought: object
    flood: object
    sea_level: object
    overall_level: int
    overall_color: str
    risk_summary: List[str]

    def to_dict(self):
        def cat_dict(c):
            return c.to_dict() if c and hasattr(c, "to_dict") else None
        return {
            "zone_id": self.zone_id,
            "assessed_at": self.assessed_at.isoformat(),
            "temperature": cat_dict(self.temperature),
            "rainfall_1h": cat_dict(self.rainfall_1h),
            "rainfall_24h": cat_dict(self.rainfall_24h),
            "humidity": cat_dict(self.humidity),
            "wind_speed": cat_dict(self.wind_speed),
            "wind_direction": self.wind_direction,
            "heatwave": cat_dict(self.heatwave),
            "heat_index_c": self.heat_index_c,
            "drought": cat_dict(self.drought),
            "flood": cat_dict(self.flood),
            "sea_level": cat_dict(self.sea_level),
            "overall_level": self.overall_level,
            "overall_color": self.overall_color,
            "risk_summary": self.risk_summary,
        }


def assess_all(
    temp_c=None, humidity_pct=None,
    rainfall_1h_mm=None, rainfall_24h_mm=None,
    wind_speed_kmh=None, wind_dir_deg=None,
    water_level_m=None, danger_level_m=None,
    flood_prob=None, pressure_hpa=None,
    consecutive_hot_days=0, rainfall_pct_of_normal=100.0,
    zone_id="UNKNOWN",
):
    cats = []
    risk = []

    temp_cat = categorize_temperature(temp_c) if temp_c is not None else None
    if temp_cat and temp_cat.level >= 2:
        risk.append(f"Temperature: {temp_cat.label_en} ({temp_c:.1f}C)")
    if temp_cat: cats.append(temp_cat.level)

    rain1h = categorize_rainfall_1h(rainfall_1h_mm) if rainfall_1h_mm is not None else None
    rain24h = categorize_rainfall_24h(rainfall_24h_mm) if rainfall_24h_mm is not None else None
    if rain1h and rain1h.level >= 2:
        risk.append(f"Rainfall: {rain1h.label_en} ({rainfall_1h_mm:.1f}mm/h)")
    if rain1h: cats.append(rain1h.level)
    if rain24h: cats.append(rain24h.level)

    hum_cat = categorize_humidity(humidity_pct) if humidity_pct is not None else None
    if hum_cat and hum_cat.level >= 3:
        risk.append(f"Humidity: {hum_cat.label_en} ({humidity_pct:.0f}%)")
    if hum_cat: cats.append(hum_cat.level)

    wind_cat = categorize_wind_speed(wind_speed_kmh) if wind_speed_kmh is not None else None
    wind_dir = degrees_to_direction(wind_dir_deg) if wind_dir_deg is not None else "--"
    if wind_cat and wind_cat.level >= 2:
        risk.append(f"Wind: {wind_cat.label_en} ({wind_speed_kmh:.0f}km/h from {wind_dir})")
    if wind_cat: cats.append(wind_cat.level)

    hw_cat = None
    heat_idx = None
    if temp_c is not None:
        hw_cat = categorize_heatwave(temp_c, consecutive_hot_days)
        if humidity_pct is not None:
            heat_idx = round(calculate_heat_index(temp_c, humidity_pct), 1)
        if hw_cat.level >= 2:
            risk.append(f"Heatwave: {hw_cat.label_en} (feels like {heat_idx}C)")
        cats.append(hw_cat.level)

    drought_cat = categorize_drought(rainfall_pct_of_normal)
    if drought_cat.level >= 2:
        risk.append(f"Drought: {drought_cat.label_en} ({rainfall_pct_of_normal:.0f}% of normal)")
    cats.append(drought_cat.level)

    flood_cat = None
    if water_level_m is not None and danger_level_m is not None:
        flood_cat = categorize_flood(water_level_m, danger_level_m)
    elif flood_prob is not None:
        flood_cat = categorize_flood_probability(flood_prob)
    if flood_cat and flood_cat.level >= 2:
        risk.append(f"Flood: {flood_cat.label_en}")
    if flood_cat: cats.append(flood_cat.level)

    sea_cat = None
    if pressure_hpa is not None:
        anomaly = estimate_sea_level_from_pressure(pressure_hpa)
        sea_cat = categorize_sea_level_anomaly(anomaly)
        if sea_cat.level >= 2:
            risk.append(f"Sea level: {sea_cat.label_en} (+{anomaly:.2f}m)")
        cats.append(sea_cat.level)

    overall = max(cats) if cats else 0
    colors = {0:"#22c55e", 1:"#86efac", 2:"#fbbf24", 3:"#ef4444", 4:"#7f1d1d"}

    return ClimateAssessment(
        zone_id=zone_id, assessed_at=datetime.utcnow(),
        temperature=temp_cat, rainfall_1h=rain1h, rainfall_24h=rain24h,
        humidity=hum_cat, wind_speed=wind_cat, wind_direction=wind_dir,
        heatwave=hw_cat, heat_index_c=heat_idx,
        drought=drought_cat, flood=flood_cat, sea_level=sea_cat,
        overall_level=overall, overall_color=colors.get(overall,"#22c55e"),
        risk_summary=risk,
    )
