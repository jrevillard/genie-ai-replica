# Crop Distribution: Sirajganj District

**Location:** Sirajganj (BD88)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 83600.00 | 3.97 | Kharif-2 (Jul-Dec) |
| rice_boro | 67769.10 | 5.20 | Rabi (Dec-May) |
| rice_aus | 13876.60 | 2.80 | Kharif-1 (Mar-Aug) |
| potato | 13322.50 | 19.72 | Rabi (Nov-Mar) |
| maize | 9940.50 | 8.40 | Rabi (Oct-Apr) |
| vegetables | 8920.00 | 11.97 | Rabi (Oct-Apr) |
| wheat | 8165.60 | 3.25 | Rabi (Nov-Mar) |
| jute | 6996.10 | 2.42 | Kharif-1 (Mar-Aug) |
| oilseeds | 6039.70 | 1.02 | Rabi (Oct-Mar) |
| pulses | 4967.30 | 1.22 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
