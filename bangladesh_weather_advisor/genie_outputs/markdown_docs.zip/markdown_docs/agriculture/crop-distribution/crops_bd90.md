# Crop Distribution: Sunamganj District

**Location:** Sunamganj (BD90)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 75811.80 | 4.94 | Rabi (Dec-May) |
| rice_aman | 61332.20 | 3.44 | Kharif-2 (Jul-Dec) |
| rice_aus | 12099.90 | 2.82 | Kharif-1 (Mar-Aug) |
| vegetables | 7372.60 | 12.33 | Rabi (Oct-Apr) |
| pulses | 6797.60 | 1.20 | Rabi (Oct-Mar) |
| oilseeds | 6117.40 | 0.97 | Rabi (Oct-Mar) |
| spices | 4031.50 | 4.55 | Rabi/Kharif |
| jute | 3201.40 | 2.31 | Kharif-1 (Mar-Aug) |
| potato | 1939.70 | 18.09 | Rabi (Nov-Mar) |
| maize | 1911.90 | 9.26 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
