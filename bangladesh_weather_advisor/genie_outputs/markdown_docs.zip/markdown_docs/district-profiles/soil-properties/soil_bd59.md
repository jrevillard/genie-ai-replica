# Soil Profile: Manikganj District

**Location:** Manikganj (BD59)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.61
- **Clay content:** 28.80%
- **Sand content:** 30.50%
- **Silt content:** 41.60%
- **Soil organic carbon:** 10.20 g/kg
- **CEC:** 15.90 cmol/kg
- **Nitrogen:** 0.99 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
