# Crop Distribution: Barishal District

**Location:** Barishal (BD06)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 116792.70 | 4.02 | Kharif-2 (Jul-Dec) |
| rice_boro | 87026.80 | 4.67 | Rabi (Dec-May) |
| rice_aus | 21203.00 | 2.37 | Kharif-1 (Mar-Aug) |
| vegetables | 7998.90 | 10.24 | Rabi (Oct-Apr) |
| pulses | 6797.40 | 1.21 | Rabi (Oct-Mar) |
| oilseeds | 5728.20 | 1.05 | Rabi (Oct-Mar) |
| jute | 3870.00 | 2.28 | Kharif-1 (Mar-Aug) |
| spices | 3446.60 | 3.98 | Rabi/Kharif |
| potato | 1899.60 | 22.08 | Rabi (Nov-Mar) |
| sugarcane | 1446.80 | 43.78 | Perennial |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
