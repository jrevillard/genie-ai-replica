"""
Rate limiting sederhana menggunakan in-memory cache.
Batasi request per IP/user untuk proteksi kuota Groq.
"""

import time
from collections import defaultdict
from typing import Dict, Tuple
from fastapi import HTTPException, Request


class RateLimiter:
    """Token bucket rate limiter."""

    def __init__(self):
        # {key: (tokens, last_refill_time)}
        self._buckets: Dict[str, Tuple[float, float]] = defaultdict(lambda: (10.0, time.time()))

    def check(self, key: str, max_tokens: float = 20, refill_rate: float = 1.0) -> bool:
        """
        Cek apakah request diizinkan.
        max_tokens: maksimum burst
        refill_rate: token per detik yang diisi ulang
        Returns True jika diizinkan, False jika rate limited.
        """
        tokens, last_refill = self._buckets[key]
        now = time.time()

        # Refill tokens
        elapsed = now - last_refill
        tokens = min(max_tokens, tokens + elapsed * refill_rate)

        if tokens >= 1.0:
            self._buckets[key] = (tokens - 1.0, now)
            return True
        else:
            self._buckets[key] = (tokens, now)
            return False

    def cleanup(self):
        """Hapus bucket yang sudah lama tidak dipakai."""
        now = time.time()
        to_delete = [k for k, (_, t) in self._buckets.items() if now - t > 3600]
        for k in to_delete:
            del self._buckets[k]


# Singleton
_limiter = RateLimiter()

# Limits per endpoint type
LIMITS = {
    "chat":    {"max_tokens": 10, "refill_rate": 0.5},   # 10 burst, 1 per 2 detik
    "api":     {"max_tokens": 60, "refill_rate": 2.0},   # 60 burst, 2 per detik
    "trigger": {"max_tokens": 3,  "refill_rate": 0.05},  # 3 burst, 1 per 20 detik
}


def get_client_key(request: Request) -> str:
    """Dapatkan identifier unik untuk client."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit(endpoint_type: str = "api"):
    """Dependency factory untuk rate limiting."""
    async def _check(request: Request):
        key = f"{endpoint_type}:{get_client_key(request)}"
        limits = LIMITS.get(endpoint_type, LIMITS["api"])

        if not _limiter.check(key, **limits):
            raise HTTPException(
                status_code=429,
                detail="Too many requests. Please slow down.",
                headers={"Retry-After": "2"},
            )
    return _check
