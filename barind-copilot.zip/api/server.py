"""
FastAPI Web Server — REST API dan webhook endpoint.

Endpoints:
- GET  /                    → Dashboard HTML
- GET  /api/status          → Status semua zona
- GET  /api/zone/{zone_id}  → Detail satu zona
- GET  /api/alerts          → Daftar alert aktif
- GET  /api/forecast/{zone} → Forecast zona
- POST /api/chat            → Chat API (web chatbot)
- POST /webhook/whatsapp    → Webhook WhatsApp (Twilio)
- POST /webhook/telegram    → Webhook Telegram
- POST /api/trigger-cycle   → Trigger manual satu siklus analisis
"""

from datetime import datetime
from typing import Optional, Dict, Any
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from loguru import logger

from config import BANGLADESH_ZONES, AlertLevel
from data.storage.database import (
    init_db, get_db, AsyncSessionLocal,
    get_active_alert, get_latest_weather, get_latest_river,
    AlertRecord, RegisteredUser, ForecastRecord
)
from chatbot.core import ChatbotEngine
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.auth import get_current_user, optional_auth
from api.admin import router as admin_router

app = FastAPI(
    title="Bangladesh Flood Early Warning System",
    description="Sistem Peringatan Dini Banjir Bangladesh",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files AFTER app is created
import os as _os
if _os.path.exists("dashboard"):
    app.mount("/static", StaticFiles(directory="dashboard"), name="static")

# Register admin router
app.include_router(admin_router)

chatbot = ChatbotEngine()


# ─────────────────────────────────────────────
# Startup
# ─────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    await init_db()
    logger.info("🚀 BFEWS API Server started")


# ─────────────────────────────────────────────
# Models
# ─────────────────────────────────────────────

class ChatRequest(BaseModel):
    user_id: str
    message: str
    platform: str = "web"
    lat: Optional[float] = None
    lon: Optional[float] = None
    lang: str = "auto"   # "en", "bn", or "auto" (detect from message)


class RegisterRequest(BaseModel):
    phone: str
    zone_id: str
    name: Optional[str] = None
    channel: str = "both"


# ─────────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Serve dashboard HTML."""
    try:
        with open("dashboard/index.html", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="<h1>Dashboard tidak ditemukan</h1>")


# ─────────────────────────────────────────────
# API Endpoints
# ─────────────────────────────────────────────

@app.get("/api/status")
async def get_all_status():
    """Status semua zona Bangladesh."""
    zones_data = []

    async with AsyncSessionLocal() as db:
        for zone_id, zone in BANGLADESH_ZONES.items():
            alert = await get_active_alert(zone_id, db)
            weather = await get_latest_weather(zone_id, db)

            zones_data.append({
                "zone_id":    zone_id,
                "name_bn":    zone.name_bn,
                "name_en":    zone.name_en,
                "district":   zone.district,
                "division":   zone.division,
                "lat":        zone.lat,
                "lon":        zone.lon,
                "alert_level": alert.level if alert else AlertLevel.GREEN,
                "risk_score":  alert.risk_score if alert else 0.0,
                "reason":      alert.reason if alert else None,
                "last_updated": weather.timestamp.isoformat() if weather else None,
                "temperature": weather.temperature if weather else None,
                "humidity":    weather.humidity if weather else None,
                "pressure":    weather.pressure if weather else None,
                "wind_speed":  weather.wind_speed if weather else None,
                "rainfall_1h": weather.rainfall_1h if weather else None,
                "rainfall_6h": weather.rainfall_6h if weather else None,
                "weather_desc": weather.weather_desc if weather else None,
            })

    # Hitung ringkasan
    red_count    = sum(1 for z in zones_data if z["alert_level"] == AlertLevel.RED)
    yellow_count = sum(1 for z in zones_data if z["alert_level"] == AlertLevel.YELLOW)
    green_count  = sum(1 for z in zones_data if z["alert_level"] == AlertLevel.GREEN)

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "summary": {
            "total_zones": len(zones_data),
            "red":    red_count,
            "yellow": yellow_count,
            "green":  green_count,
        },
        "zones": zones_data,
    }


@app.get("/api/zone/{zone_id}")
async def get_zone_detail(zone_id: str):
    """Detail lengkap satu zona."""
    zone = BANGLADESH_ZONES.get(zone_id)
    if not zone:
        raise HTTPException(status_code=404, detail=f"Zone {zone_id} tidak ditemukan")

    async with AsyncSessionLocal() as db:
        alert = await get_active_alert(zone_id, db)
        weather = await get_latest_weather(zone_id, db)

        # River readings
        river_data = []
        for station_id in zone.river_stations:
            reading = await get_latest_river(station_id, db)
            if reading:
                river_data.append({
                    "station_id":    station_id,
                    "water_level_m": reading.water_level_m,
                    "danger_level_m": reading.danger_level_m,
                    "level_pct":     reading.water_level_m / (reading.danger_level_m or 10),
                    "change_6h_m":   reading.change_6h_m,
                    "timestamp":     reading.timestamp.isoformat(),
                })

        # Forecasts
        forecasts = {}
        for h in [6, 12, 24]:
            result = await db.execute(
                select(ForecastRecord)
                .where(ForecastRecord.zone_id == zone_id,
                       ForecastRecord.horizon_hours == h)
                .order_by(ForecastRecord.created_at.desc())
                .limit(1)
            )
            fc = result.scalar_one_or_none()
            if fc:
                forecasts[f"{h}h"] = {
                    "rainfall_mm":   fc.predicted_rainfall_mm,
                    "flood_prob":    fc.flood_probability,
                    "confidence":    fc.confidence,
                    "forecast_for":  fc.forecast_for.isoformat(),
                }

    return {
        "zone_id":   zone_id,
        "name_bn":   zone.name_bn,
        "name_en":   zone.name_en,
        "district":  zone.district,
        "division":  zone.division,
        "lat":       zone.lat,
        "lon":       zone.lon,
        "alert": {
            "level":      alert.level if alert else AlertLevel.GREEN,
            "risk_score": alert.risk_score if alert else 0.0,
            "reason":     alert.reason if alert else None,
            "issued_at":  alert.issued_at.isoformat() if alert else None,
        },
        "weather": {
            "temperature": weather.temperature if weather else None,
            "humidity":    weather.humidity if weather else None,
            "pressure":    weather.pressure if weather else None,
            "wind_speed":  weather.wind_speed if weather else None,
            "rainfall_1h": weather.rainfall_1h if weather else None,
            "rainfall_6h": weather.rainfall_6h if weather else None,
            "description": weather.weather_desc if weather else None,
            "timestamp":   weather.timestamp.isoformat() if weather else None,
        },
        "rivers":    river_data,
        "forecasts": forecasts,
    }


@app.get("/api/alerts")
async def get_active_alerts():
    """Daftar semua alert aktif."""
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(AlertRecord)
            .where(AlertRecord.is_active == True)
            .order_by(AlertRecord.risk_score.desc())
        )
        alerts = result.scalars().all()

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "count": len(alerts),
        "alerts": [
            {
                "zone_id":    a.zone_id,
                "level":      a.level,
                "risk_score": a.risk_score,
                "reason":     a.reason,
                "issued_at":  a.issued_at.isoformat(),
                "zone_name":  BANGLADESH_ZONES.get(a.zone_id, {}).name_bn
                              if a.zone_id in BANGLADESH_ZONES else a.zone_id,
            }
            for a in alerts
        ],
    }


@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest, request: Request):
    """Web chatbot endpoint dengan rate limiting."""
    from api.rate_limit import rate_limit, get_client_key, _limiter, LIMITS
    key = f"chat:{get_client_key(request)}"
    if not _limiter.check(key, **LIMITS["chat"]):
        raise HTTPException(status_code=429, detail="Too many messages. Please wait a moment.")

    response, needs_escalation = await chatbot.process_message(
        user_id=req.user_id,
        message=req.message,
        platform=req.platform,
        location_lat=req.lat,
        location_lon=req.lon,
        lang=req.lang,
    )
    return {
        "response": response,
        "needs_escalation": needs_escalation,
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/api/register")
async def register_user(req: RegisterRequest):
    """Daftarkan pengguna untuk notifikasi."""
    zone = BANGLADESH_ZONES.get(req.zone_id)
    if not zone:
        raise HTTPException(status_code=400, detail="Zone tidak valid")

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(RegisteredUser).where(RegisteredUser.phone == req.phone)
        )
        existing = result.scalar_one_or_none()

        if existing:
            existing.zone_id = req.zone_id
            existing.is_active = True
            if req.name:
                existing.name = req.name
        else:
            new_user = RegisteredUser(
                phone=req.phone,
                zone_id=req.zone_id,
                name=req.name,
                district=zone.district,
                channel=req.channel,
                is_active=True,
            )
            db.add(new_user)
        await db.commit()

    return {"success": True, "message": f"Terdaftar di zona {zone.name_bn}"}


@app.post("/api/trigger-cycle")
async def trigger_analysis_cycle():
    """
    Trigger manual satu siklus analisis lengkap.
    Berguna untuk testing dan debugging.
    """
    from main import run_analysis_cycle
    try:
        await run_analysis_cycle()
        return {"success": True, "message": "Siklus analisis selesai"}
    except Exception as e:
        logger.error(f"Error trigger cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# Webhooks
# ─────────────────────────────────────────────

@app.post("/webhook/whatsapp")
async def whatsapp_webhook(request: Request):
    """
    Webhook untuk menerima pesan WhatsApp dari Twilio.
    Twilio mengirim POST request ke URL ini saat ada pesan masuk.
    """
    form_data = await request.form()

    from_number = str(form_data.get("From", "")).replace("whatsapp:", "")
    body = str(form_data.get("Body", "")).strip()
    num_media = int(form_data.get("NumMedia", 0))

    if not from_number or not body:
        return JSONResponse({"status": "ignored"})

    logger.info(f"📱 WhatsApp masuk dari {from_number}: {body[:80]}")

    # Proses pesan — auto-detect language from Bengali/English text
    response_text, needs_escalation = await chatbot.process_message(
        user_id=from_number,
        message=body,
        platform="whatsapp",
        lang="auto",
    )

    # Kirim balasan via Twilio
    from notifications.whatsapp_sender import WhatsAppSender
    sender = WhatsAppSender()
    await sender.send_message(from_number, response_text)

    # TwiML response (kosong karena kita kirim via API, bukan TwiML)
    return HTMLResponse(
        content='<?xml version="1.0" encoding="UTF-8"?><Response></Response>',
        media_type="application/xml"
    )


@app.get("/webhook/telegram/{token}")
@app.post("/webhook/telegram/{token}")
async def telegram_webhook(token: str, request: Request):
    """
    Webhook untuk Telegram Bot.
    Set webhook URL: https://api.telegram.org/bot{TOKEN}/setWebhook?url={YOUR_URL}/webhook/telegram/{TOKEN}
    """
    from config import TELEGRAM_BOT_TOKEN
    if token != TELEGRAM_BOT_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid token")

    try:
        data = await request.json()
        from telegram import Update
        from chatbot.telegram_bot import create_telegram_app
        tg_app = create_telegram_app()
        if tg_app:
            update = Update.de_json(data, tg_app.bot)
            await tg_app.process_update(update)
    except Exception as e:
        logger.error(f"Telegram webhook error: {e}")

    return {"ok": True}


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
    }


@app.get("/api/stats")
async def get_system_stats():
    """Statistik sistem — jumlah data, user terdaftar, dll."""
    from data.storage.database import (
        WeatherReading, RiverReading, AlertRecord,
        RegisteredUser, ChatSession, FieldReport
    )
    from sqlalchemy import func

    async with AsyncSessionLocal() as db:
        weather_count = (await db.execute(
            select(func.count()).select_from(WeatherReading)
        )).scalar()
        river_count = (await db.execute(
            select(func.count()).select_from(RiverReading)
        )).scalar()
        alert_count = (await db.execute(
            select(func.count()).select_from(AlertRecord)
        )).scalar()
        user_count = (await db.execute(
            select(func.count()).select_from(RegisteredUser)
            .where(RegisteredUser.is_active == True)
        )).scalar()
        chat_count = (await db.execute(
            select(func.count()).select_from(ChatSession)
        )).scalar()
        report_count = (await db.execute(
            select(func.count()).select_from(FieldReport)
        )).scalar()

        # Alert history last 7 days
        from datetime import timedelta
        cutoff = datetime.utcnow() - timedelta(days=7)
        recent_alerts = (await db.execute(
            select(AlertRecord)
            .where(AlertRecord.issued_at >= cutoff)
            .order_by(AlertRecord.issued_at.desc())
            .limit(20)
        )).scalars().all()

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "data_points": {
            "weather_readings": weather_count,
            "river_readings":   river_count,
            "alerts_total":     alert_count,
        },
        "users": {
            "registered_active": user_count,
            "chat_sessions":     chat_count,
            "field_reports":     report_count,
        },
        "recent_alerts": [
            {
                "zone_id":   a.zone_id,
                "level":     a.level,
                "risk_score": a.risk_score,
                "issued_at": a.issued_at.isoformat(),
                "is_active": a.is_active,
            }
            for a in recent_alerts
        ],
    }


@app.get("/api/history/{zone_id}")
async def get_zone_history(zone_id: str, hours: int = 24):
    """Riwayat data cuaca dan sungai untuk satu zona."""
    from data.storage.database import WeatherReading, RiverReading
    from datetime import timedelta

    zone = BANGLADESH_ZONES.get(zone_id)
    if not zone:
        raise HTTPException(status_code=404, detail="Zone not found")

    cutoff = datetime.utcnow() - timedelta(hours=min(hours, 168))  # max 7 hari

    async with AsyncSessionLocal() as db:
        weather_result = await db.execute(
            select(WeatherReading)
            .where(WeatherReading.zone_id == zone_id,
                   WeatherReading.timestamp >= cutoff)
            .order_by(WeatherReading.timestamp.asc())
        )
        weather_history = weather_result.scalars().all()

        river_history = {}
        for station_id in zone.river_stations:
            result = await db.execute(
                select(RiverReading)
                .where(RiverReading.station_id == station_id,
                       RiverReading.timestamp >= cutoff)
                .order_by(RiverReading.timestamp.asc())
            )
            readings = result.scalars().all()
            river_history[station_id] = [
                {
                    "timestamp":     r.timestamp.isoformat(),
                    "water_level_m": r.water_level_m,
                    "change_6h_m":   r.change_6h_m,
                }
                for r in readings
            ]

    return {
        "zone_id": zone_id,
        "hours":   hours,
        "weather": [
            {
                "timestamp":   w.timestamp.isoformat(),
                "temperature": w.temperature,
                "humidity":    w.humidity,
                "rainfall_1h": w.rainfall_1h,
                "rainfall_6h": w.rainfall_6h,
                "wind_speed":  w.wind_speed,
            }
            for w in weather_history
        ],
        "rivers": river_history,
    }


@app.get("/api/climate/{zone_id}")
async def get_climate_analysis(zone_id: str, days: int = 30):
    """
    Analisis tren climate change untuk satu zona.
    
    Parameters:
    - zone_id: ID zona (contoh: SYL-01, DHA-01)
    - days: periode analisis dalam hari (default 30, max 365)
    """
    from ml.climate.trend_analyzer import climate_analyzer

    zone = BANGLADESH_ZONES.get(zone_id)
    if not zone:
        raise HTTPException(status_code=404, detail=f"Zone {zone_id} not found")

    days = min(max(days, 7), 365)  # clamp 7-365 hari

    try:
        report = await climate_analyzer.analyze_zone(zone_id, days)

        # Serialize TrendResult dataclasses
        trends_dict = {}
        for var, trend in report.trends.items():
            trends_dict[var] = {
                "variable":        trend.variable,
                "unit":            trend.unit,
                "period_days":     trend.period_days,
                "data_points":     trend.data_points,
                "statistics": {
                    "mean":        trend.mean,
                    "std":         trend.std,
                    "min":         trend.min_val,
                    "max":         trend.max_val,
                },
                "trend": {
                    "slope_per_day":  trend.slope_per_day,
                    "slope_per_year": trend.slope_per_year,
                    "r_squared":      trend.r_squared,
                    "direction":      trend.trend_direction,
                    "strength":       trend.trend_strength,
                },
                "mann_kendall": {
                    "tau":         trend.mk_tau,
                    "significant": trend.mk_significant,
                },
                "anomalies": {
                    "count":          trend.anomaly_count,
                    "recent_anomaly": trend.recent_anomaly,
                },
                "interpretation":  trend.interpretation,
                "climate_signal":  trend.climate_signal,
            }

        return {
            "zone_id":       report.zone_id,
            "zone_name":     report.zone_name,
            "generated_at":  report.generated_at.isoformat(),
            "period_days":   report.period_days,
            "total_readings": report.total_readings,
            "confidence":    report.confidence,
            "summary":       report.summary,
            "risk_signals":  report.risk_signals,
            "trends":        trends_dict,
        }

    except Exception as e:
        logger.error(f"Climate analysis error for {zone_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/climate/compare/all")
async def compare_all_zones_climate(days: int = 30):
    """
    Bandingkan tren iklim semua zona — untuk melihat zona mana
    yang paling terdampak perubahan iklim.
    """
    from ml.climate.trend_analyzer import climate_analyzer

    days = min(max(days, 7), 90)
    results = {}

    for zone_id in list(BANGLADESH_ZONES.keys())[:5]:  # limit 5 zona untuk performa
        try:
            report = await climate_analyzer.analyze_zone(zone_id, days)
            temp_trend = report.trends.get("temperature")
            rain_trend = report.trends.get("rainfall_6h")
            results[zone_id] = {
                "zone_name":     report.zone_name,
                "confidence":    report.confidence,
                "risk_signals":  len(report.risk_signals),
                "temperature_trend": {
                    "slope_per_year": temp_trend.slope_per_year if temp_trend else 0,
                    "direction":      temp_trend.trend_direction if temp_trend else "stable",
                    "significant":    temp_trend.mk_significant if temp_trend else False,
                },
                "rainfall_trend": {
                    "slope_per_year": rain_trend.slope_per_year if rain_trend else 0,
                    "direction":      rain_trend.trend_direction if rain_trend else "stable",
                    "significant":    rain_trend.mk_significant if rain_trend else False,
                },
                "summary": report.summary,
            }
        except Exception as e:
            logger.error(f"Climate compare error {zone_id}: {e}")

    return {
        "generated_at": datetime.utcnow().isoformat(),
        "period_days":  days,
        "zones":        results,
    }


# ─────────────────────────────────────────────
# Admin Panel HTML
# ─────────────────────────────────────────────

@app.get("/admin", response_class=HTMLResponse)
async def admin_panel():
    """Serve admin panel HTML."""
    try:
        with open("dashboard/admin.html", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="<h1>Admin panel not found</h1>")


# ─────────────────────────────────────────────
# SSE — Server-Sent Events untuk notifikasi real-time
# ─────────────────────────────────────────────

import asyncio
from fastapi.responses import StreamingResponse as SSEResponse

# Global event queue untuk broadcast ke semua connected clients
_sse_clients: list = []


async def _sse_generator(request: Request):
    """Generator untuk SSE stream."""
    queue = asyncio.Queue()
    _sse_clients.append(queue)
    try:
        yield "data: {\"type\":\"connected\"}\n\n"
        while True:
            if await request.is_disconnected():
                break
            try:
                msg = await asyncio.wait_for(queue.get(), timeout=30.0)
                yield f"data: {msg}\n\n"
            except asyncio.TimeoutError:
                yield ": keepalive\n\n"
    finally:
        _sse_clients.remove(queue)


@app.get("/api/events")
async def sse_events(request: Request):
    """SSE endpoint untuk notifikasi real-time ke dashboard."""
    return SSEResponse(
        _sse_generator(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        }
    )


async def broadcast_event(event_type: str, data: dict):
    """Broadcast event ke semua SSE clients."""
    import json
    msg = json.dumps({"type": event_type, "data": data, "ts": datetime.utcnow().isoformat()})
    dead = []
    for queue in _sse_clients:
        try:
            queue.put_nowait(msg)
        except asyncio.QueueFull:
            dead.append(queue)
    for q in dead:
        try:
            _sse_clients.remove(q)
        except ValueError:
            pass


@app.get("/api/categories/{zone_id}")
async def get_zone_categories(zone_id: str):
    """
    Kategorisasi lengkap semua variabel iklim untuk satu zona.
    Mengembalikan kategori untuk: suhu, curah hujan, kelembapan,
    angin, gelombang panas, kekeringan, banjir, kenaikan muka laut.
    """
    from ml.climate.categorizer import assess_all

    zone = BANGLADESH_ZONES.get(zone_id)
    if not zone:
        raise HTTPException(status_code=404, detail="Zone not found")

    async with AsyncSessionLocal() as db:
        weather = await get_latest_weather(zone_id, db)

        # Get latest river reading for flood categorization
        river_level = None
        danger_level = None
        flood_prob = None
        for station_id in zone.river_stations:
            reading = await get_latest_river(station_id, db)
            if reading:
                river_level = reading.water_level_m
                danger_level = reading.danger_level_m
                break

        # Get latest forecast for flood probability
        result = await db.execute(
            select(ForecastRecord)
            .where(ForecastRecord.zone_id == zone_id,
                   ForecastRecord.horizon_hours == 24)
            .order_by(ForecastRecord.created_at.desc())
            .limit(1)
        )
        fc = result.scalar_one_or_none()
        if fc:
            flood_prob = fc.flood_probability

    # Run assessment
    assessment = assess_all(
        temp_c=weather.temperature if weather else None,
        humidity_pct=weather.humidity if weather else None,
        rainfall_1h_mm=weather.rainfall_1h if weather else None,
        rainfall_24h_mm=(weather.rainfall_6h * 4) if weather and weather.rainfall_6h else None,
        wind_speed_kmh=weather.wind_speed if weather else None,
        wind_dir_deg=weather.wind_dir if weather else None,
        water_level_m=river_level,
        danger_level_m=danger_level,
        flood_prob=flood_prob,
        pressure_hpa=weather.pressure if weather else None,
        zone_id=zone_id,
    )

    return assessment.to_dict()


@app.get("/api/categories/all/summary")
async def get_all_categories_summary():
    """Ringkasan kategori semua zona — untuk overview cepat."""
    from ml.climate.categorizer import assess_all

    results = {}
    async with AsyncSessionLocal() as db:
        for zone_id, zone in BANGLADESH_ZONES.items():
            weather = await get_latest_weather(zone_id, db)
            river_level = None
            danger_level = None
            for station_id in zone.river_stations:
                reading = await get_latest_river(station_id, db)
                if reading:
                    river_level = reading.water_level_m
                    danger_level = reading.danger_level_m
                    break

            assessment = assess_all(
                temp_c=weather.temperature if weather else None,
                humidity_pct=weather.humidity if weather else None,
                rainfall_1h_mm=weather.rainfall_1h if weather else None,
                wind_speed_kmh=weather.wind_speed if weather else None,
                water_level_m=river_level,
                danger_level_m=danger_level,
                pressure_hpa=weather.pressure if weather else None,
                zone_id=zone_id,
            )

            results[zone_id] = {
                "zone_name": zone.name_en,
                "overall_level": assessment.overall_level,
                "overall_color": assessment.overall_color,
                "temperature_cat": assessment.temperature.code if assessment.temperature else None,
                "rainfall_cat": assessment.rainfall_1h.code if assessment.rainfall_1h else None,
                "wind_cat": assessment.wind_speed.code if assessment.wind_speed else None,
                "flood_cat": assessment.flood.code if assessment.flood else None,
                "risk_count": len(assessment.risk_summary),
                "risk_summary": assessment.risk_summary,
            }

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "zones": results,
    }
