# Rainfall Climatology: District BD3082

## Climatology Summary
- **Mean daily climatological rainfall:** 4.85 mm
- **Median (P50) rainfall benchmark:** 2.72 mm
- **Upper percentile (P90) benchmark:** 11.39 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
