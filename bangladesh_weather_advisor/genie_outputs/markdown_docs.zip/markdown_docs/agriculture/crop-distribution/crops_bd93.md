# Crop Distribution: Tangail District

**Location:** Tangail (BD93)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 66962.30 | 3.54 | Kharif-2 (Jul-Dec) |
| rice_boro | 60964.40 | 5.34 | Rabi (Dec-May) |
| rice_aus | 12531.90 | 3.07 | Kharif-1 (Mar-Aug) |
| jute | 12015.30 | 2.46 | Kharif-1 (Mar-Aug) |
| maize | 9075.50 | 8.11 | Rabi (Oct-Apr) |
| vegetables | 6873.60 | 12.65 | Rabi (Oct-Apr) |
| pulses | 6617.60 | 0.96 | Rabi (Oct-Mar) |
| potato | 6089.70 | 22.52 | Rabi (Nov-Mar) |
| oilseeds | 4973.60 | 1.13 | Rabi (Oct-Mar) |
| spices | 4686.60 | 3.89 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
