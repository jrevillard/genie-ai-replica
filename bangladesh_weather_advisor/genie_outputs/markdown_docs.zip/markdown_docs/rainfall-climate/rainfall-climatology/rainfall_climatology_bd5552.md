# Rainfall Climatology: District BD5552

## Climatology Summary
- **Mean daily climatological rainfall:** 8.05 mm
- **Median (P50) rainfall benchmark:** 4.77 mm
- **Upper percentile (P90) benchmark:** 18.51 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
