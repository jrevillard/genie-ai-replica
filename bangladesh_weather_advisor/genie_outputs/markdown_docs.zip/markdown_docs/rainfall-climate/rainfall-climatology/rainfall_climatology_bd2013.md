# Rainfall Climatology: District BD2013

## Climatology Summary
- **Mean daily climatological rainfall:** 6.08 mm
- **Median (P50) rainfall benchmark:** 3.46 mm
- **Upper percentile (P90) benchmark:** 14.19 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
