"""Quick system status check."""
import asyncio, sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import httpx

async def main():
    async with httpx.AsyncClient(timeout=10) as c:

        # 1. Health
        r = await c.get("http://localhost:8000/health")
        print(f"[1] Health: {r.status_code} {r.json()['status']}")

        # 2. Status API — check all fields
        r = await c.get("http://localhost:8000/api/status")
        d = r.json()
        z = d["zones"][0]
        print(f"[2] Status API: {len(d['zones'])} zones")
        print(f"    Zone {z['zone_id']}: temp={z.get('temperature')} hum={z.get('humidity')} "
              f"press={z.get('pressure')} wind={z.get('wind_speed')} rain6h={z.get('rainfall_6h')}")
        missing = [f for f in ['temperature','humidity','pressure','wind_speed','rainfall_6h','weather_desc']
                   if z.get(f) is None]
        print(f"    Missing fields: {missing if missing else 'NONE — all OK'}")

        # 3. Zone detail
        r = await c.get("http://localhost:8000/api/zone/SYL-01")
        z2 = r.json()
        w = z2.get("weather", {})
        rivers = z2.get("rivers", [])
        fc = z2.get("forecasts", {})
        print(f"[3] Zone detail SYL-01:")
        print(f"    Weather: {w.get('temperature')}C, {w.get('humidity')}%, {w.get('description')}")
        print(f"    Rivers: {len(rivers)} stations")
        if rivers:
            rv = rivers[0]
            print(f"    River[0]: {rv['water_level_m']}m / {rv['danger_level_m']}m ({rv['level_pct']:.0%})")
        print(f"    Forecasts: {list(fc.keys())}")

        # 4. Chatbot — Indonesian
        r = await c.post("http://localhost:8000/api/chat",
            json={"user_id":"check-id","message":"selamat siang, lokasi mana yang bahaya?","platform":"web","lang":"auto"})
        resp = r.json()["response"]
        print(f"[4] Chatbot (Indonesian): {resp[:200]}")

        # 5. Chatbot — English with zone
        r = await c.post("http://localhost:8000/api/chat",
            json={"user_id":"check-en","message":"Dhaka","platform":"web","lang":"en"})
        r2 = await c.post("http://localhost:8000/api/chat",
            json={"user_id":"check-en","message":"what is the river level?","platform":"web","lang":"en"})
        resp2 = r2.json()["response"]
        print(f"[5] Chatbot (English river): {resp2[:200]}")

        # 6. Alerts
        r = await c.get("http://localhost:8000/api/alerts")
        alerts = r.json()
        print(f"[6] Active alerts: {alerts['count']}")

        print("\n=== ALL CHECKS PASSED ===")

asyncio.run(main())
