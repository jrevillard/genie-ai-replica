"""
BFEWS — Bangladesh Flood Early Warning System
Entry point utama sistem.

Menjalankan:
1. Scheduler untuk pengumpulan data otomatis (24/7)
2. Pipeline analisis AI (anomali + forecast + risk)
3. Alert engine (pengiriman peringatan)
4. FastAPI web server (API + dashboard + webhook)
5. Telegram bot (opsional)
"""

import asyncio
import signal
import sys
from datetime import datetime
from loguru import logger

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

import uvicorn

from config import (
    HOST, PORT, DEBUG,
    WEATHER_REFRESH_INTERVAL,
    RIVER_REFRESH_INTERVAL,
    FORECAST_REFRESH_INTERVAL,
    TELEGRAM_BOT_TOKEN,
)
from data.storage.database import init_db
from data.ingestion.weather_collector import collect_all_zones
from data.ingestion.river_collector import collect_all_rivers
from ml.forecasting.ensemble_forecast import ensemble_forecaster
from ml.anomaly.detector import AnomalyDetectionEngine
from ml.risk.engine import RiskEngine
from alerts.engine import AlertEngine
from api.server import app


# ─────────────────────────────────────────────
# Global instances
# ─────────────────────────────────────────────
scheduler = AsyncIOScheduler(timezone="Asia/Dhaka")
anomaly_engine = AnomalyDetectionEngine()
risk_engine = RiskEngine()
alert_engine = AlertEngine()


# ─────────────────────────────────────────────
# Pipeline Utama
# ─────────────────────────────────────────────

async def run_analysis_cycle():
    """
    Satu siklus analisis lengkap:
    1. Kumpulkan data terbaru
    2. Deteksi anomali
    3. Jalankan forecast
    4. Nilai risiko
    5. Kirim peringatan jika diperlukan
    """
    cycle_start = datetime.utcnow()
    logger.info(f"{'='*60}")
    logger.info(f"🔄 Memulai siklus analisis: {cycle_start.strftime('%Y-%m-%d %H:%M:%S')} UTC")

    try:
        # ── Tahap 1: Kumpulkan data ──
        logger.info("📡 Tahap 1: Pengumpulan data...")
        await asyncio.gather(
            collect_all_zones(),
            collect_all_rivers(),
        )

        # ── Tahap 2: Deteksi anomali ──
        logger.info("🔍 Tahap 2: Deteksi anomali...")
        anomalies = await anomaly_engine.detect_all_zones()

        # ── Tahap 3: Forecast ──
        logger.info("📈 Tahap 3: Menjalankan ensemble forecast (HoltWinters + AR + GloFAS)...")
        from config import BANGLADESH_ZONES
        forecasts = {}
        for zone_id in BANGLADESH_ZONES:
            try:
                zone_fc = await ensemble_forecaster.forecast_zone(zone_id)
                if zone_fc:
                    forecasts[zone_id] = zone_fc
                    await ensemble_forecaster.save_forecasts(zone_id, zone_fc)
            except Exception as e:
                logger.error(f"Forecast error zona {zone_id}: {e}")

        # ── Tahap 4: Penilaian risiko ──
        logger.info("📊 Tahap 4: Penilaian risiko...")
        assessments = await risk_engine.assess_all_zones(forecasts, anomalies)

        # ── Tahap 5: Kirim peringatan ──
        logger.info("📢 Tahap 5: Pengiriman peringatan...")
        await alert_engine.process_assessments(assessments)

        elapsed = (datetime.utcnow() - cycle_start).total_seconds()
        logger.info(f"✅ Siklus selesai dalam {elapsed:.1f} detik")
        logger.info(f"{'='*60}")

    except Exception as e:
        logger.error(f"❌ Error dalam siklus analisis: {e}", exc_info=True)


async def collect_weather_job():
    """Job pengumpulan data cuaca (setiap jam)."""
    logger.debug("⏰ Job: Pengumpulan data cuaca")
    await collect_all_zones()


async def collect_river_job():
    """Job pengumpulan data sungai (setiap 15 menit)."""
    logger.debug("⏰ Job: Pengumpulan data sungai")
    await collect_all_rivers()


async def analysis_job():
    """Job analisis lengkap (setiap 3 jam)."""
    logger.info("⏰ Job: Siklus analisis terjadwal")
    await run_analysis_cycle()


# ─────────────────────────────────────────────
# Scheduler Setup
# ─────────────────────────────────────────────

async def backup_job():
    """Job backup database harian."""
    logger.info("⏰ Job: Backup database")
    try:
        from scripts.backup_db import backup
        backup()
    except Exception as e:
        logger.error(f"Backup error: {e}")


def setup_scheduler():
    """Konfigurasi semua scheduled jobs."""

    scheduler.add_job(
        collect_weather_job,
        trigger=IntervalTrigger(seconds=WEATHER_REFRESH_INTERVAL),
        id="weather_collection", name="Weather Data Collection",
        replace_existing=True, max_instances=1,
    )
    scheduler.add_job(
        collect_river_job,
        trigger=IntervalTrigger(seconds=RIVER_REFRESH_INTERVAL),
        id="river_collection", name="River Data Collection",
        replace_existing=True, max_instances=1,
    )
    scheduler.add_job(
        analysis_job,
        trigger=IntervalTrigger(seconds=FORECAST_REFRESH_INTERVAL),
        id="analysis_cycle", name="Full Analysis Cycle",
        replace_existing=True, max_instances=1,
    )
    # Backup harian jam 02:00
    from apscheduler.triggers.cron import CronTrigger
    scheduler.add_job(
        backup_job,
        trigger=CronTrigger(hour=2, minute=0),
        id="daily_backup", name="Daily Database Backup",
        replace_existing=True,
    )

    logger.info("✅ Scheduler dikonfigurasi:")
    logger.info(f"   • Cuaca: setiap {WEATHER_REFRESH_INTERVAL//60} menit")
    logger.info(f"   • Sungai: setiap {RIVER_REFRESH_INTERVAL//60} menit")
    logger.info(f"   • Analisis: setiap {FORECAST_REFRESH_INTERVAL//3600} jam")


# ─────────────────────────────────────────────
# Startup Sequence
# ─────────────────────────────────────────────

async def startup_sequence():
    """Urutan startup sistem."""
    logger.info("🌊 Bangladesh Flood Early Warning System (BFEWS) v1.0")
    logger.info("=" * 60)

    # 1. Inisialisasi database
    logger.info("📦 Inisialisasi database...")
    await init_db()

    # 2. Jalankan siklus pertama untuk mengisi data awal
    logger.info("🚀 Menjalankan siklus analisis pertama...")
    await run_analysis_cycle()

    # 3. Setup dan mulai scheduler
    logger.info("⏰ Memulai scheduler...")
    setup_scheduler()
    scheduler.start()

    logger.info("=" * 60)
    logger.info(f"✅ Sistem siap! Dashboard: http://{HOST}:{PORT}")
    logger.info(f"   API Docs: http://{HOST}:{PORT}/docs")
    logger.info(f"   Health: http://{HOST}:{PORT}/health")
    logger.info("=" * 60)


# ─────────────────────────────────────────────
# Main Entry Point
# ─────────────────────────────────────────────

async def main():
    """Main async entry point."""

    # Jalankan startup sequence
    await startup_sequence()

    # Konfigurasi Telegram bot jika tersedia
    if TELEGRAM_BOT_TOKEN:
        try:
            from chatbot.telegram_bot import create_telegram_app
            tg_app = create_telegram_app()
            if tg_app:
                await tg_app.initialize()
                logger.info("✅ Telegram bot siap (gunakan webhook mode untuk produksi)")
        except Exception as e:
            logger.info(f"ℹ️  Telegram bot: {e} — gunakan webhook mode")

    # Konfigurasi uvicorn
    config = uvicorn.Config(
        app=app,
        host=HOST,
        port=PORT,
        log_level="warning" if not DEBUG else "info",
        reload=False,
        workers=1,  # single worker untuk async app
        access_log=DEBUG,
    )
    server = uvicorn.Server(config)

    # Graceful shutdown handler
    def handle_shutdown(sig, frame):
        logger.info("🛑 Menerima sinyal shutdown...")
        scheduler.shutdown(wait=False)
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)

    # Jalankan server
    logger.info(f"🌐 Web server berjalan di http://{HOST}:{PORT}")
    await server.serve()


if __name__ == "__main__":
    # Konfigurasi logging
    logger.remove()
    logger.add(
        sys.stdout,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}",
        level="DEBUG" if DEBUG else "INFO",
        colorize=True,
    )
    logger.add(
        "logs/bfews_{time:YYYY-MM-DD}.log",
        rotation="1 day",
        retention="30 days",
        level="INFO",
        encoding="utf-8",
    )

    asyncio.run(main())
