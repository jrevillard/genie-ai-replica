# Soil Profile: Rajshahi District

**Location:** Rajshahi (BD81)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.51
- **Clay content:** 38.30%
- **Sand content:** 23.00%
- **Silt content:** 40.20%
- **Soil organic carbon:** 9.80 g/kg
- **CEC:** 20.90 cmol/kg
- **Nitrogen:** 1.00 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
