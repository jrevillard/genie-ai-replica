# Soil Profile: Comilla District

**Location:** Comilla (BD19)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 7.00
- **Clay content:** 42.10%
- **Sand content:** 14.90%
- **Silt content:** 44.20%
- **Soil organic carbon:** 13.38 g/kg
- **CEC:** 24.00 cmol/kg
- **Nitrogen:** 1.35 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
