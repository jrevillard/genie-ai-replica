"""
Message templates — multi-language support.

Languages:
  "en"   → English (system default, dashboard)
  "bn"   → Bengali (WhatsApp/SMS alerts to residents)
  "auto" → detect from user input, respond in same language
"""

from typing import Dict, Optional
from config import AlertLevel, EMERGENCY_CONTACTS


def get_alert_emoji(level: str) -> str:
    return {"green": "🟢", "yellow": "🟡", "red": "🔴"}.get(level, "⚪")


# ─────────────────────────────────────────────
# Multi-language string tables
# ─────────────────────────────────────────────

STRINGS = {
    "level_label": {
        "en": {"green": "NORMAL", "yellow": "WARNING", "red": "DANGER"},
        "bn": {"green": "স্বাভাবিক", "yellow": "সতর্কতা", "red": "বিপদ"},
    },
    "status_title": {
        "en": "Current Status",
        "bn": "বর্তমান অবস্থা",
    },
    "risk_score": {
        "en": "Risk Score",
        "bn": "ঝুঁকি স্কোর",
    },
    "rainfall_6h": {
        "en": "Rainfall (6h)",
        "bn": "বৃষ্টি (৬ ঘণ্টা)",
    },
    "wind": {
        "en": "Wind",
        "bn": "বাতাস",
    },
    "river": {
        "en": "River level",
        "bn": "নদীর পানি",
    },
    "flood_prob": {
        "en": "Flood probability",
        "bn": "বন্যার সম্ভাবনা",
    },
    "in_6h": {"en": "in 6h", "bn": "৬ ঘণ্টায়"},
    "in_24h": {"en": "in 24h", "bn": "২৪ ঘণ্টায়"},
    "reasons": {"en": "Reasons", "bn": "কারণ"},
    "normal_summary": {
        "en": "Conditions are currently normal. Stay alert for changes.",
        "bn": "বর্তমানে পরিস্থিতি স্বাভাবিক। তবে আবহাওয়ার পরিবর্তনে সতর্ক থাকুন।",
    },
    "warning_summary": {
        "en": "Conditions are concerning. Monitor for changes.",
        "bn": "পরিস্থিতি সতর্কজনক। পরিবর্তনের দিকে নজর রাখুন।",
    },
    "danger_summary": {
        "en": "⚠️ Dangerous conditions! Take immediate precautionary action.",
        "bn": "⚠️ বিপজ্জনক পরিস্থিতি! অবিলম্বে সতর্কতামূলক ব্যবস্থা নিন।",
    },
    "evacuation_tip": {
        "en": "Type SHELTER for nearest evacuation centers.",
        "bn": "EVAKUASI টাইপ করুন আশ্রয়কেন্দ্রের তালিকার জন্য।",
    },
    "forecast_title": {"en": "Weather Forecast", "bn": "আবহাওয়ার পূর্বাভাস"},
    "forecast_footer": {
        "en": "_Forecast updated every 3 hours_\nType INFO for current status.",
        "bn": "_পূর্বাভাস প্রতি ৩ ঘণ্টায় আপডেট হয়_\nINFO টাইপ করুন বর্তমান অবস্থার জন্য।",
    },
    "prob_high":   {"en": "High",   "bn": "বেশি"},
    "prob_medium": {"en": "Medium", "bn": "মাঝারি"},
    "prob_low":    {"en": "Low",    "bn": "কম"},
    "shelter_title": {"en": "Evacuation Centers", "bn": "আশ্রয়কেন্দ্র"},
    "shelter_capacity": {"en": "Capacity", "bn": "ধারণক্ষমতা"},
    "shelter_none": {
        "en": "No shelter data available for this zone yet.\n\n",
        "bn": "এই এলাকার আশ্রয়কেন্দ্রের তথ্য এখনো আপডেট হয়নি।\n\n",
    },
    "shelter_tip": {
        "en": "⚠️ Inform your family before leaving.\nDo not walk through floodwater.",
        "bn": "⚠️ আশ্রয়কেন্দ্রে যাওয়ার আগে পরিবারকে জানান।\nবন্যার পানিতে হাঁটবেন না।",
    },
    "emergency": {
        "en": "Emergency: Fire 199 | Police 999 | Disaster Mgmt 1090",
        "bn": "জরুরি: ফায়ার ১৯৯ | পুলিশ ৯৯৯ | দুর্যোগ ব্যবস্থাপনা ১০৯০",
    },
    "welcome": {
        "en": (
            "🌊 *Bangladesh Flood Early Warning System*\n\n"
            "Hello! I can provide real-time flood and weather information.\n\n"
            "📍 Type your *district name* to get started:\n"
            "Sylhet, Dhaka, Chittagong, Barisal, Rajshahi, Khulna, Rangpur\n\n"
            "Quick commands:\n"
            "INFO — current status\n"
            "FORECAST — 24h weather forecast\n"
            "RIVER — river water levels\n"
            "SHELTER — evacuation centers & emergency numbers\n"
            "REGISTER — subscribe to automatic alerts"
        ),
        "bn": (
            "🌊 *বাংলাদেশ বন্যা সতর্কতা সিস্টেম*\n\n"
            "আস্সালামু আলাইকুম! আমি আপনার এলাকার আবহাওয়া ও বন্যার তথ্য দিতে পারব।\n\n"
            "📍 আপনার *জেলার নাম* টাইপ করুন:\n"
            "সিলেট, ঢাকা, চট্টগ্রাম, বরিশাল, রাজশাহী, খুলনা, রংপুর\n\n"
            "দ্রুত কমান্ড:\n"
            "INFO — বর্তমান অবস্থা\n"
            "CUACA — আবহাওয়ার পূর্বাভাস\n"
            "BANJIR — নদীর পানির স্তর\n"
            "BANTUAN — আশ্রয়কেন্দ্র ও জরুরি নম্বর\n"
            "DAFTAR — সতর্কতা বার্তার জন্য নিবন্ধন"
        ),
    },
    "ask_location": {
        "en": (
            "📍 Please type your *district name* to get local information.\n\n"
            "Examples: Sylhet, Dhaka, Chittagong, Barisal, Rajshahi, Khulna, Rangpur\n\n"
            "Or share your 📎 location via WhatsApp."
        ),
        "bn": (
            "📍 আপনার এলাকার তথ্য দিতে আপনার *জেলার নাম* টাইপ করুন।\n\n"
            "উদাহরণ: সিলেট, ঢাকা, চট্টগ্রাম, বরিশাল, রাজশাহী, খুলনা, রংপুর\n\n"
            "অথবা WhatsApp-এ 📎 দিয়ে লোকেশন শেয়ার করুন।"
        ),
    },
    "register_success": {
        "en": "✅ Successfully registered!\n\n📍 Your zone: *{zone}*\n\nYou will now receive automatic alerts.\nType UNSUBSCRIBE to stop.",
        "bn": "✅ আপনি সফলভাবে নিবন্ধিত হয়েছেন।\n\n📍 আপনার এলাকা: *{zone}*\n\nএখন থেকে আপনি স্বয়ংক্রিয়ভাবে সতর্কতা বার্তা পাবেন।\nনিবন্ধন বাতিল করতে BERHENTI টাইপ করুন।",
    },
    "unregister_success": {
        "en": "✅ You have been unsubscribed. You will no longer receive automatic alerts.",
        "bn": "✅ আপনার নিবন্ধন বাতিল করা হয়েছে। আর সতর্কতা বার্তা পাবেন না।",
    },
    "not_registered": {
        "en": "You were not registered.",
        "bn": "আপনি নিবন্ধিত ছিলেন না।",
    },
    "register_need_location": {
        "en": "Please type your district name first before registering.\nExample: Sylhet",
        "bn": "নিবন্ধনের আগে আপনার জেলার নাম টাইপ করুন।\nউদাহরণ: সিলেট",
    },
    "field_report_ack": {
        "en": "✅ Report received. Thank you!\n\nYour information has been forwarded to the disaster response team.\nFor emergency help: 999 or 1090",
        "bn": "✅ আপনার প্রতিবেদন পেয়েছি। ধন্যবাদ!\n\nআপনার তথ্য দুর্যোগ ব্যবস্থাপনা দলকে পাঠানো হয়েছে।\nজরুরি সাহায্যের জন্য: ৯৯৯ বা ১০৯০",
    },
    "escalation": {
        "en": "🔄 Your message is being forwarded to a duty officer.\n\nSomeone will contact you shortly.\n\nFor immediate emergency: 999 (Police/Fire) | 1090 (Disaster)",
        "bn": "🔄 আপনার বার্তা একজন কর্মকর্তার কাছে পাঠানো হচ্ছে।\n\nকিছুক্ষণের মধ্যে কেউ আপনার সাথে যোগাযোগ করবেন।\n\nজরুরি অবস্থায়: ৯৯৯ (পুলিশ/ফায়ার) | ১০৯০ (দুর্যোগ)",
    },
    "unknown_intent": {
        "en": (
            "I didn't understand that. Use these commands:\n\n"
            "INFO — current status\n"
            "FORECAST — weather forecast\n"
            "RIVER — river water levels\n"
            "SHELTER — evacuation centers\n"
            "REGISTER — subscribe to alerts"
        ),
        "bn": (
            "আমি বুঝতে পারিনি। নিচের কমান্ড ব্যবহার করুন:\n\n"
            "INFO — বর্তমান অবস্থা\n"
            "CUACA — আবহাওয়ার পূর্বাভাস\n"
            "BANJIR — নদীর পানির স্তর\n"
            "BANTUAN — আশ্রয়কেন্দ্র ও জরুরি নম্বর\n"
            "DAFTAR — সতর্কতা বার্তার জন্য নিবন্ধন"
        ),
    },
    "help_response": {
        "en": "🆘 *Emergency Help*\n\n{emergency}\n{centers}\n⚠️ If life is at risk, call 999 immediately.",
        "bn": "🆘 *জরুরি সাহায্য*\n\n{emergency}\n{centers}\n⚠️ জীবনের ঝুঁকি থাকলে এখনই ৯৯৯ কল করুন।",
    },
    "no_data": {
        "en": "No data available for this area.",
        "bn": "এলাকার তথ্য পাওয়া যায়নি।",
    },
    "connection_error": {
        "en": "Connection error. Please try again later.",
        "bn": "সংযোগ সমস্যা। পরে আবার চেষ্টা করুন।",
    },
}


def t(key: str, lang: str, **kwargs) -> str:
    """Translate a string key to the given language. Falls back to 'en'."""
    lang = lang if lang in ("en", "bn") else "en"
    val = STRINGS.get(key, {}).get(lang, STRINGS.get(key, {}).get("en", key))
    if kwargs:
        val = val.format(**kwargs)
    return val


def detect_language(text: str) -> str:
    """
    Detect script/language from text.
    Returns language code for template system.
    Bengali → "bn", everything else → "en" (Groq handles the actual translation).
    """
    for ch in text:
        if '\u0980' <= ch <= '\u09FF':
            return "bn"
    return "en"


def resolve_lang(requested_lang: str, message_text: str) -> str:
    """
    Resolve language for TEMPLATE responses (rule-based fallback).
    Groq handles all languages natively — this is only for template strings.
    - "auto" → detect Bengali vs everything else
    - "bn"   → Bengali templates
    - anything else → English templates (Groq will respond in actual user language)
    """
    if requested_lang == "auto":
        return detect_language(message_text)
    return requested_lang if requested_lang in ("en", "bn") else "en"


# ─────────────────────────────────────────────
# Formatted message builders
# ─────────────────────────────────────────────

def format_chatbot_status_response(
    zone_name: str,          # English name
    zone_name_bn: str,       # Bengali name
    alert_level: str,
    risk_score: float,
    reasons: list,           # English reasons
    reasons_bn: list,        # Bengali reasons
    rainfall_mm: float,
    wind_kmh: float,
    river_level_pct: float,
    flood_prob_6h: float,
    flood_prob_24h: float,
    weather_desc: str,
    lang: str = "en",
) -> str:
    emoji = get_alert_emoji(alert_level)
    level_label = t("level_label", lang)[alert_level]
    display_name = zone_name_bn if lang == "bn" else zone_name

    reason_list = reasons_bn if lang == "bn" else reasons
    reasons_text = "\n".join(f"• {r}" for r in reason_list[:3]) if reason_list else f"• {t('normal_summary', lang)}"

    summary_key = {"green": "normal_summary", "yellow": "warning_summary", "red": "danger_summary"}[alert_level]
    summary = t(summary_key, lang)

    return (
        f"{emoji} *{display_name} — {t('status_title', lang)}*\n\n"
        f"Level: *{level_label}* | {t('risk_score', lang)}: {risk_score:.0%}\n\n"
        f"{summary}\n\n"
        f"🌤️ {weather_desc}\n"
        f"🌧️ {t('rainfall_6h', lang)}: {rainfall_mm:.0f} mm\n"
        f"💨 {t('wind', lang)}: {wind_kmh:.0f} km/h\n"
        f"🌊 {t('river', lang)}: {river_level_pct:.0%} of danger level\n\n"
        f"📈 {t('flood_prob', lang)}:\n"
        f"• {t('in_6h', lang)}: {flood_prob_6h:.0%}\n"
        f"• {t('in_24h', lang)}: {flood_prob_24h:.0%}\n\n"
        f"*{t('reasons', lang)}:*\n{reasons_text}\n\n"
        f"{t('evacuation_tip', lang)}"
    )


def format_forecast_response(
    zone_name: str,
    zone_name_bn: str,
    forecast_6h: dict,
    forecast_12h: dict,
    forecast_24h: dict,
    lang: str = "en",
) -> str:
    display_name = zone_name_bn if lang == "bn" else zone_name

    def prob_text(p: float) -> str:
        if p >= 0.7:   return f"{t('prob_high', lang)} ({p:.0%})"
        elif p >= 0.4: return f"{t('prob_medium', lang)} ({p:.0%})"
        else:          return f"{t('prob_low', lang)} ({p:.0%})"

    return (
        f"🌤️ *{display_name} — {t('forecast_title', lang)}*\n\n"
        f"⏰ *6h:*\n"
        f"🌧️ {t('rainfall_6h', lang)}: {forecast_6h.get('rainfall_mm', 0):.0f} mm\n"
        f"🌊 {t('flood_prob', lang)}: {prob_text(forecast_6h.get('flood_prob', 0))}\n\n"
        f"⏰ *12h:*\n"
        f"🌧️ {t('rainfall_6h', lang)}: {forecast_12h.get('rainfall_mm', 0):.0f} mm\n"
        f"🌊 {t('flood_prob', lang)}: {prob_text(forecast_12h.get('flood_prob', 0))}\n\n"
        f"⏰ *24h:*\n"
        f"🌧️ {t('rainfall_6h', lang)}: {forecast_24h.get('rainfall_mm', 0):.0f} mm\n"
        f"🌊 {t('flood_prob', lang)}: {prob_text(forecast_24h.get('flood_prob', 0))}\n\n"
        f"{t('forecast_footer', lang)}"
    )


def format_evacuation_response(zone_id: str, zone_name: str, zone_name_bn: str, lang: str = "en") -> str:
    from config import EVACUATION_CENTERS
    centers = EVACUATION_CENTERS.get(zone_id, [])
    display_name = zone_name_bn if lang == "bn" else zone_name
    emergency = t("emergency", lang)

    if not centers:
        return (
            f"{t('shelter_none', lang)}"
            f"{emergency}"
        )

    centers_text = ""
    for i, c in enumerate(centers, 1):
        name = c["name_bn"] if lang == "bn" else c["name"]
        cap_label = t("shelter_capacity", lang)
        centers_text += f"\n{i}. *{name}*\n   {cap_label}: {c['capacity']:,}\n"

    return (
        f"🏠 *{display_name} — {t('shelter_title', lang)}*\n"
        f"{centers_text}\n"
        f"📞 {emergency}\n\n"
        f"{t('shelter_tip', lang)}"
    )


def format_welcome_message(lang: str = "en") -> str:
    return t("welcome", lang)


def format_registration_success(zone_name: str, zone_name_bn: str, lang: str = "en") -> str:
    display = zone_name_bn if lang == "bn" else zone_name
    return t("register_success", lang, zone=display)


def format_field_report_ack(lang: str = "en") -> str:
    return t("field_report_ack", lang)


def format_escalation_message(lang: str = "en") -> str:
    return t("escalation", lang)


# ─────────────────────────────────────────────
# WhatsApp / SMS alert templates (always Bengali for Bangladesh residents)
# ─────────────────────────────────────────────

def format_whatsapp_alert(
    zone_name_bn: str,
    zone_name_en: str,
    alert_level: str,
    risk_score: float,
    reasons_bn: list,
    rainfall_mm: float,
    wind_kmh: float,
    river_level_pct: float,
    flood_prob_24h: float,
    zone_id: str,
    lang: str = "bn",   # WhatsApp to residents → Bengali by default
) -> str:
    emoji = get_alert_emoji(alert_level)
    level_label = t("level_label", lang)[alert_level]
    display_name = zone_name_bn if lang == "bn" else zone_name_en

    if alert_level == AlertLevel.RED:
        if lang == "bn":
            header = f"🚨 *জরুরি সতর্কতা — {display_name}*"
            action = (
                "⚠️ *এখনই করণীয়:*\n"
                "• নিরাপদ স্থানে সরে যান\n"
                "• মূল্যবান জিনিস উঁচু স্থানে রাখুন\n"
                "• পরিবারকে সতর্ক করুন\n"
                "• নিকটতম আশ্রয়কেন্দ্রে যান\n"
                "• BANTUAN টাইপ করুন আশ্রয়কেন্দ্রের তালিকার জন্য"
            )
        else:
            header = f"🚨 *EMERGENCY ALERT — {display_name}*"
            action = (
                "⚠️ *Immediate actions:*\n"
                "• Move to higher ground immediately\n"
                "• Move valuables to higher floors\n"
                "• Alert your family\n"
                "• Go to nearest evacuation center\n"
                "• Type SHELTER for evacuation center list"
            )
    else:
        if lang == "bn":
            header = f"⚠️ *সতর্কতা — {display_name}*"
            action = (
                "📋 *করণীয়:*\n"
                "• পরিস্থিতি পর্যবেক্ষণ করুন\n"
                "• মূল্যবান জিনিস উঁচু স্থানে রাখুন\n"
                "• পরিবারকে সতর্ক রাখুন\n"
                "• প্রতি ২ ঘণ্টায় আপডেট চেক করুন"
            )
        else:
            header = f"⚠️ *WARNING — {display_name}*"
            action = (
                "📋 *Recommended actions:*\n"
                "• Monitor the situation closely\n"
                "• Move valuables to higher ground\n"
                "• Keep family informed\n"
                "• Check updates every 2 hours"
            )

    reasons_list = reasons_bn if lang == "bn" else []
    reasons_text = "\n".join(f"• {r}" for r in reasons_list[:3]) if reasons_list else ""
    emergency = t("emergency", lang)

    return (
        f"{header}\n\n"
        f"{emoji} *Level: {level_label}*\n"
        f"📊 {t('risk_score', lang)}: {risk_score:.0%}\n\n"
        f"{reasons_text}\n\n" if reasons_text else ""
        f"🌧️ {t('rainfall_6h', lang)}: {rainfall_mm:.0f} mm\n"
        f"💨 {t('wind', lang)}: {wind_kmh:.0f} km/h\n"
        f"🌊 {t('river', lang)}: {river_level_pct:.0%} of danger level\n"
        f"📈 {t('flood_prob', lang)} 24h: {flood_prob_24h:.0%}\n\n"
        f"{action}\n\n"
        f"📞 {emergency}"
    )


def format_sms_alert(zone_name_bn: str, alert_level: str, reasons_bn: list, lang: str = "bn") -> str:
    """SMS — max 160 chars, Bengali for residents."""
    level_label = t("level_label", lang)[alert_level]
    emoji = get_alert_emoji(alert_level)

    if alert_level == AlertLevel.RED:
        action = "এখনই নিরাপদ স্থানে যান। জরুরি: ৯৯৯" if lang == "bn" else "Move to safety now. Emergency: 999"
    else:
        action = "সতর্ক থাকুন। জরুরি: ৯৯৯" if lang == "bn" else "Stay alert. Emergency: 999"

    msg = f"{emoji}{zone_name_bn}: {level_label}। {action}"
    return msg[:160]
