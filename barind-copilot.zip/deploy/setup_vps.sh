#!/bin/bash
# ============================================================
# BFEWS VPS Setup Script
# Server IP : 187.77.116.110
# Domain    : forecast.masjidmupundong.com
# OS        : Ubuntu 22.04
# Jalankan sebagai root: bash setup_vps.sh
# ============================================================

set -e

DOMAIN="forecast.masjidmupundong.com"
APP_DIR="/var/www/bfews"

echo "🌊 BFEWS VPS Setup"
echo "   IP     : 187.77.116.110"
echo "   Domain : $DOMAIN"
echo "============================================================"

# ── 1. Update sistem ──
echo "📦 [1/8] Updating system..."
apt-get update -qq && apt-get upgrade -y -qq

# ── 2. Install dependencies ──
echo "📦 [2/8] Installing system dependencies..."
apt-get install -y -qq \
    python3.11 python3.11-venv python3.11-dev \
    python3-pip \
    nginx \
    certbot python3-certbot-nginx \
    git \
    curl \
    htop \
    ufw

# ── 3. Setup firewall ──
echo "🔒 [3/8] Configuring firewall..."
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

# ── 4. Buat direktori aplikasi ──
echo "📁 [4/8] Creating application directory..."
mkdir -p /var/www/bfews
mkdir -p /var/www/bfews/logs

# ── 5. Clone atau copy aplikasi ──
echo "📥 [5/8] Setting up application..."
# Jika pakai git:
# git clone https://github.com/YOUR_USERNAME/bfews.git /var/www/bfews
# Atau upload manual via SFTP ke /var/www/bfews

# ── 6. Setup Python virtual environment ──
echo "🐍 [6/8] Setting up Python environment..."
cd /var/www/bfews
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip -q
pip install -r requirements.txt -q

echo "✅ Python packages installed"

# ── 7. Setup environment file ──
echo "⚙️  [7/8] Setting up environment..."
if [ ! -f /var/www/bfews/.env ]; then
    cp /var/www/bfews/.env.production /var/www/bfews/.env
    echo "⚠️  Edit /var/www/bfews/.env with your API keys!"
fi

# Initialize database — ignore UNIQUE errors (demo data already exists)
cd /var/www/bfews
source venv/bin/activate
python scripts/init_db.py 2>/dev/null || echo "✅ Database already initialized"

# ── 8. Setup systemd service ──
echo "🔧 [8/8] Setting up systemd service..."
cp /var/www/bfews/deploy/bfews.service /etc/systemd/system/bfews.service

# Set permissions
chown -R www-data:www-data /var/www/bfews
chmod -R 755 /var/www/bfews
chmod 600 /var/www/bfews/.env

systemctl daemon-reload
systemctl enable bfews
systemctl start bfews

# ── Setup Nginx ──
echo "🌐 Setting up Nginx..."
cp /var/www/bfews/deploy/nginx.conf /etc/nginx/sites-available/bfews
ln -sf /etc/nginx/sites-available/bfews /etc/nginx/sites-enabled/bfews
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo ""
echo "============================================================"
echo "✅ BFEWS Setup Complete!"
echo ""
echo "Next steps:"
echo "  1. Edit $APP_DIR/.env — pastikan API keys sudah benar"
echo "  2. sudo systemctl restart bfews"
echo "  3. Pasang SSL:"
echo "     sudo certbot --nginx -d $DOMAIN"
echo ""
echo "Akses sistem:"
echo "  HTTP  : http://187.77.116.110:8000  (sementara)"
echo "  HTTPS : https://$DOMAIN  (setelah SSL)"
echo ""
echo "Check status: sudo systemctl status bfews"
echo "View logs:    sudo journalctl -u bfews -f"
echo "============================================================"
