# Crop Distribution: Pirojpur District

**Location:** Pirojpur (BD79)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 86380.00 | 4.45 | Kharif-2 (Jul-Dec) |
| rice_boro | 85090.70 | 5.82 | Rabi (Dec-May) |
| rice_aus | 22250.40 | 2.86 | Kharif-1 (Mar-Aug) |
| vegetables | 7490.40 | 10.68 | Rabi (Oct-Apr) |
| oilseeds | 5108.10 | 1.05 | Rabi (Oct-Mar) |
| pulses | 4932.80 | 1.16 | Rabi (Oct-Mar) |
| spices | 3831.60 | 5.09 | Rabi/Kharif |
| jute | 3652.10 | 2.43 | Kharif-1 (Mar-Aug) |
| potato | 2448.00 | 20.85 | Rabi (Nov-Mar) |
| sugarcane | 2025.00 | 47.63 | Perennial |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
