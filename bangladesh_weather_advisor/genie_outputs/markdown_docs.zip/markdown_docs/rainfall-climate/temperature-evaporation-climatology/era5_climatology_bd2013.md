# ERA5 Climatology: District BD2013

## Baseline Summary
- **Mean temperature climatology:** 25.75 °C
- **Mean evaporation climatology:** -3.05 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
