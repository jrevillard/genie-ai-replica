"""
Alert Engine — mesin pengiriman peringatan otomatis.

Alur kerja:
1. Terima hasil penilaian risiko dari RiskEngine
2. Cek apakah level berubah atau perlu dikirim ulang
3. Ambil daftar pengguna terdaftar di zona tersebut
4. Kirim peringatan via WhatsApp, SMS, dan Telegram
5. Catat pengiriman di database
"""

import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from loguru import logger

from config import AlertLevel, BANGLADESH_ZONES
from ml.risk.engine import RiskAssessment
from notifications.whatsapp_sender import WhatsAppSender, SMSSender
from notifications.templates.messages import (
    format_whatsapp_alert,
    format_sms_alert,
)
from data.storage.database import AsyncSessionLocal, RegisteredUser
from sqlalchemy.future import select


class AlertEngine:
    """
    Mesin pengiriman peringatan.
    Mengelola kapan dan bagaimana peringatan dikirim.
    """

    # Interval minimum antar pengiriman ulang (menit)
    RESEND_INTERVAL_YELLOW = 120   # 2 jam
    RESEND_INTERVAL_RED    = 30    # 30 menit

    def __init__(self):
        self.whatsapp = WhatsAppSender()
        self.sms = SMSSender()
        self._last_sent: Dict[str, datetime] = {}  # zone_id → waktu terakhir kirim

    def _should_send(self, zone_id: str, alert_level: str, level_changed: bool) -> bool:
        """
        Tentukan apakah peringatan perlu dikirim.
        Kirim jika:
        - Level berubah (selalu kirim)
        - Level merah dan sudah >30 menit sejak terakhir kirim
        - Level kuning dan sudah >2 jam sejak terakhir kirim
        """
        if alert_level == AlertLevel.GREEN:
            return False  # Tidak kirim untuk level hijau

        if level_changed:
            return True

        last_sent = self._last_sent.get(zone_id)
        if not last_sent:
            return True

        now = datetime.utcnow()
        elapsed_minutes = (now - last_sent).total_seconds() / 60

        if alert_level == AlertLevel.RED:
            return elapsed_minutes >= self.RESEND_INTERVAL_RED
        else:  # YELLOW
            return elapsed_minutes >= self.RESEND_INTERVAL_YELLOW

    async def get_zone_recipients(self, zone_id: str) -> Dict[str, List[str]]:
        """
        Ambil daftar penerima untuk zona tertentu.
        Returns: {"whatsapp": [...], "sms": [...], "telegram": [...]}
        """
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(RegisteredUser)
                .where(
                    RegisteredUser.zone_id == zone_id,
                    RegisteredUser.is_active == True
                )
            )
            users = result.scalars().all()

        whatsapp_numbers = []
        sms_numbers = []
        telegram_ids = []

        for user in users:
            if user.channel in ["whatsapp", "both"] and user.phone:
                whatsapp_numbers.append(user.phone)
            if user.channel in ["sms", "both"] and user.phone:
                sms_numbers.append(user.phone)
            if user.telegram_id:
                telegram_ids.append(user.telegram_id)

        return {
            "whatsapp": whatsapp_numbers,
            "sms": sms_numbers,
            "telegram": telegram_ids,
        }

    async def send_zone_alert(self, assessment: RiskAssessment) -> Dict:
        """
        Kirim peringatan untuk satu zona.
        Returns statistik pengiriman.
        """
        zone_id = assessment.zone_id
        zone = BANGLADESH_ZONES.get(zone_id)
        if not zone:
            return {}

        if not self._should_send(zone_id, assessment.alert_level, assessment.level_changed):
            logger.debug(f"⏭️  Skip alert {zone_id} (belum waktunya kirim ulang)")
            return {"skipped": True}

        logger.info(f"📢 Mengirim peringatan {assessment.alert_level.upper()} untuk zona {zone_id} "
                    f"({zone.name_bn})")

        # Ambil penerima
        recipients = await self.get_zone_recipients(zone_id)

        # Format pesan
        whatsapp_msg = format_whatsapp_alert(
            zone_name_bn=zone.name_bn,
            zone_name_en=zone.name_en,
            alert_level=assessment.alert_level,
            risk_score=assessment.risk_score,
            reasons_bn=assessment.reasons,
            rainfall_mm=assessment.current_rainfall_mm,
            wind_kmh=assessment.current_wind_kmh,
            river_level_pct=assessment.max_river_level_pct,
            flood_prob_24h=assessment.flood_prob_24h,
            zone_id=zone_id,
        )

        sms_msg = format_sms_alert(
            zone_name_bn=zone.name_bn,
            alert_level=assessment.alert_level,
            reasons_bn=assessment.reasons,
        )

        stats = {
            "zone_id": zone_id,
            "level": assessment.alert_level,
            "whatsapp": {"success": 0, "failed": 0},
            "sms": {"success": 0, "failed": 0},
            "telegram": {"success": 0, "failed": 0},
        }

        # Kirim WhatsApp
        if recipients["whatsapp"]:
            wa_result = await self.whatsapp.broadcast(
                recipients["whatsapp"], whatsapp_msg
            )
            stats["whatsapp"] = wa_result
        else:
            logger.debug(f"  Tidak ada penerima WhatsApp di zona {zone_id}")

        # Kirim SMS
        if recipients["sms"]:
            sms_result = await self.sms.broadcast_sms(
                recipients["sms"], sms_msg
            )
            stats["sms"] = sms_result
        else:
            logger.debug(f"  Tidak ada penerima SMS di zona {zone_id}")

        # Kirim Telegram
        if recipients["telegram"]:
            tg_success, tg_failed = await self._send_telegram_alerts(
                recipients["telegram"], whatsapp_msg
            )
            stats["telegram"] = {"success": tg_success, "failed": tg_failed}

        # Update waktu terakhir kirim
        self._last_sent[zone_id] = datetime.utcnow()

        # Update last_alert_sent di database
        await self._update_last_sent(zone_id)

        total_sent = (
            stats["whatsapp"].get("success", 0) +
            stats["sms"].get("success", 0) +
            stats["telegram"].get("success", 0)
        )
        logger.info(f"✅ Alert {zone_id}: {total_sent} pesan terkirim")

        return stats

    async def _send_telegram_alerts(self, telegram_ids: List[str], message: str):
        """Kirim alert via Telegram."""
        try:
            from config import TELEGRAM_BOT_TOKEN
            if not TELEGRAM_BOT_TOKEN:
                return 0, 0

            from telegram import Bot
            bot = Bot(token=TELEGRAM_BOT_TOKEN)
            from chatbot.telegram_bot import broadcast_alert_telegram
            return await broadcast_alert_telegram(bot, telegram_ids, message)
        except Exception as e:
            logger.error(f"Telegram alert error: {e}")
            return 0, len(telegram_ids)

    async def _update_last_sent(self, zone_id: str):
        """Update timestamp last_alert_sent untuk semua user di zona."""
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(RegisteredUser)
                .where(RegisteredUser.zone_id == zone_id, RegisteredUser.is_active == True)
            )
            users = result.scalars().all()
            for user in users:
                user.last_alert_sent = datetime.utcnow()
            await db.commit()

    async def process_assessments(self, assessments: Dict[str, RiskAssessment]) -> Dict:
        """
        Proses semua hasil penilaian risiko dan kirim peringatan yang diperlukan.
        """
        alert_stats = {}
        zones_alerted = 0

        for zone_id, assessment in assessments.items():
            if assessment.alert_level in [AlertLevel.YELLOW, AlertLevel.RED]:
                stats = await self.send_zone_alert(assessment)
                if not stats.get("skipped"):
                    alert_stats[zone_id] = stats
                    zones_alerted += 1

        if zones_alerted > 0:
            logger.info(f"🚨 Peringatan dikirim untuk {zones_alerted} zona")
        else:
            logger.info("✅ Tidak ada peringatan yang perlu dikirim saat ini")

        return alert_stats
