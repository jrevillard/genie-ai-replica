# Soil Profile: Faridpur District

**Location:** Faridpur (BD29)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.55
- **Clay content:** 39.50%
- **Sand content:** 21.40%
- **Silt content:** 39.20%
- **Soil organic carbon:** 9.82 g/kg
- **CEC:** 22.90 cmol/kg
- **Nitrogen:** 1.05 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
