# Crop Distribution: Narsingdi District

**Location:** Narsingdi (BD73)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 95212.30 | 4.22 | Kharif-2 (Jul-Dec) |
| rice_boro | 79291.70 | 4.55 | Rabi (Dec-May) |
| rice_aus | 15569.60 | 2.56 | Kharif-1 (Mar-Aug) |
| jute | 12199.30 | 2.35 | Kharif-1 (Mar-Aug) |
| vegetables | 7985.50 | 12.79 | Rabi (Oct-Apr) |
| pulses | 7095.80 | 1.08 | Rabi (Oct-Mar) |
| maize | 6676.20 | 7.26 | Rabi (Oct-Apr) |
| potato | 4931.40 | 19.01 | Rabi (Nov-Mar) |
| oilseeds | 4423.40 | 0.93 | Rabi (Oct-Mar) |
| wheat | 3647.20 | 3.39 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
