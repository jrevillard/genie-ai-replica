# Crop Distribution: Satkhira District

**Location:** Satkhira (BD87)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 88249.10 | 3.51 | Kharif-2 (Jul-Dec) |
| rice_boro | 63772.70 | 5.45 | Rabi (Dec-May) |
| rice_aus | 16103.40 | 2.73 | Kharif-1 (Mar-Aug) |
| jute | 7606.80 | 2.69 | Kharif-1 (Mar-Aug) |
| pulses | 7120.10 | 1.05 | Rabi (Oct-Mar) |
| vegetables | 6500.40 | 13.42 | Rabi (Oct-Apr) |
| oilseeds | 5758.90 | 1.11 | Rabi (Oct-Mar) |
| potato | 4045.00 | 22.53 | Rabi (Nov-Mar) |
| spices | 3440.40 | 4.73 | Rabi/Kharif |
| wheat | 2302.90 | 3.15 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
