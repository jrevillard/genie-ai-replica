# Soil Profile: Chandpur District

**Location:** Chandpur (BD22)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.68
- **Clay content:** 43.50%
- **Sand content:** 14.50%
- **Silt content:** 42.60%
- **Soil organic carbon:** 14.16 g/kg
- **CEC:** 23.40 cmol/kg
- **Nitrogen:** 1.46 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
