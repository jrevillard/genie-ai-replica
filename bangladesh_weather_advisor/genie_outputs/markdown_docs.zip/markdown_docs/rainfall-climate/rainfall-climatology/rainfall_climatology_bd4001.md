# Rainfall Climatology: District BD4001

## Climatology Summary
- **Mean daily climatological rainfall:** 5.23 mm
- **Median (P50) rainfall benchmark:** 3.27 mm
- **Upper percentile (P90) benchmark:** 11.78 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
