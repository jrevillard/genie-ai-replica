# Rainfall Climatology: District BD3059

## Climatology Summary
- **Mean daily climatological rainfall:** 5.70 mm
- **Median (P50) rainfall benchmark:** 3.17 mm
- **Upper percentile (P90) benchmark:** 13.43 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
