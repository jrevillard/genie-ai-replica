# Rainfall Climatology: District BD2051

## Climatology Summary
- **Mean daily climatological rainfall:** 7.29 mm
- **Median (P50) rainfall benchmark:** 4.40 mm
- **Upper percentile (P90) benchmark:** 16.66 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
