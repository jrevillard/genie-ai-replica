# ERA5 Climatology: District BD6091

## Baseline Summary
- **Mean temperature climatology:** 24.20 °C
- **Mean evaporation climatology:** -2.86 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
