# Soil Profile: Noakhali District

**Location:** Noakhali (BD75)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.77
- **Clay content:** 43.90%
- **Sand content:** 14.80%
- **Silt content:** 44.30%
- **Soil organic carbon:** 13.90 g/kg
- **CEC:** 23.30 cmol/kg
- **Nitrogen:** 1.39 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
