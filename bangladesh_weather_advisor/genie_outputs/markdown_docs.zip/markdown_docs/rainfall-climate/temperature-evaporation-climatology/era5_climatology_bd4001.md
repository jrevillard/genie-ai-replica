# ERA5 Climatology: District BD4001

## Baseline Summary
- **Mean temperature climatology:** 25.96 °C
- **Mean evaporation climatology:** -3.18 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
