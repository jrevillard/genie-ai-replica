# Crop Distribution: Feni District

**Location:** Feni (BD30)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 69610.00 | 5.30 | Rabi (Dec-May) |
| rice_aman | 65006.60 | 3.95 | Kharif-2 (Jul-Dec) |
| rice_aus | 14020.70 | 2.87 | Kharif-1 (Mar-Aug) |
| vegetables | 8571.00 | 11.73 | Rabi (Oct-Apr) |
| pulses | 7104.00 | 1.01 | Rabi (Oct-Mar) |
| jute | 6319.10 | 2.75 | Kharif-1 (Mar-Aug) |
| oilseeds | 4555.20 | 1.03 | Rabi (Oct-Mar) |
| spices | 4497.70 | 4.37 | Rabi/Kharif |
| maize | 3354.80 | 9.59 | Rabi (Oct-Apr) |
| potato | 2569.00 | 18.06 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
