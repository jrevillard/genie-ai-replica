# Soil Profile: Kurigram District

**Location:** Kurigram (BD49)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 5.85
- **Clay content:** 24.30%
- **Sand content:** 35.90%
- **Silt content:** 41.10%
- **Soil organic carbon:** 9.89 g/kg
- **CEC:** 14.40 cmol/kg
- **Nitrogen:** 1.10 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
