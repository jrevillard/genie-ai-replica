# Soil Profile: Khulna District

**Location:** Khulna (BD50)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.24
- **Clay content:** 31.20%
- **Sand content:** 30.40%
- **Silt content:** 40.90%
- **Soil organic carbon:** 9.52 g/kg
- **CEC:** 16.20 cmol/kg
- **Nitrogen:** 1.01 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
