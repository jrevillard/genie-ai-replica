# Crop Distribution: Munshiganj District

**Location:** Munshiganj (BD67)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 74119.20 | 3.92 | Kharif-2 (Jul-Dec) |
| rice_boro | 71419.70 | 4.60 | Rabi (Dec-May) |
| rice_aus | 15720.20 | 2.81 | Kharif-1 (Mar-Aug) |
| jute | 13501.00 | 2.24 | Kharif-1 (Mar-Aug) |
| maize | 8609.80 | 8.81 | Rabi (Oct-Apr) |
| potato | 6887.80 | 20.11 | Rabi (Nov-Mar) |
| vegetables | 6819.10 | 13.04 | Rabi (Oct-Apr) |
| oilseeds | 6014.90 | 0.87 | Rabi (Oct-Mar) |
| pulses | 5453.70 | 1.01 | Rabi (Oct-Mar) |
| wheat | 3750.20 | 3.45 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
