# Soil Profile: Jessore District

**Location:** Jessore (BD41)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.14
- **Clay content:** 38.70%
- **Sand content:** 22.80%
- **Silt content:** 40.00%
- **Soil organic carbon:** 9.97 g/kg
- **CEC:** 22.20 cmol/kg
- **Nitrogen:** 1.01 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
