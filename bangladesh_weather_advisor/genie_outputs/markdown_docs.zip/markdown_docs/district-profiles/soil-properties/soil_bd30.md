# Soil Profile: Feni District

**Location:** Feni (BD30)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 7.08
- **Clay content:** 40.30%
- **Sand content:** 14.90%
- **Silt content:** 43.00%
- **Soil organic carbon:** 13.25 g/kg
- **CEC:** 22.90 cmol/kg
- **Nitrogen:** 1.36 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
