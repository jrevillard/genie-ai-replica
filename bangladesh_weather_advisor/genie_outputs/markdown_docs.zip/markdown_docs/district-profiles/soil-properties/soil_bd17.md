# Soil Profile: Chapainawabganj District

**Location:** Chapainawabganj (BD17)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.48
- **Clay content:** 36.20%
- **Sand content:** 21.20%
- **Silt content:** 41.10%
- **Soil organic carbon:** 9.35 g/kg
- **CEC:** 22.50 cmol/kg
- **Nitrogen:** 1.05 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
