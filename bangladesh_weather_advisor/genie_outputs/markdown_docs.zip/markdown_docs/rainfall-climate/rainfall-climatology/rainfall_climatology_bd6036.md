# Rainfall Climatology: District BD6036

## Climatology Summary
- **Mean daily climatological rainfall:** 7.40 mm
- **Median (P50) rainfall benchmark:** 5.05 mm
- **Upper percentile (P90) benchmark:** 16.15 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
