# Soil Profile: Madaripur District

**Location:** Madaripur (BD56)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 6.87
- **Clay content:** 38.80%
- **Sand content:** 22.70%
- **Silt content:** 38.70%
- **Soil organic carbon:** 10.08 g/kg
- **CEC:** 21.50 cmol/kg
- **Nitrogen:** 0.98 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
