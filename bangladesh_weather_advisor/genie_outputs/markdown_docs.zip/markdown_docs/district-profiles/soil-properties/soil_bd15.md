# Soil Profile: Chattogram District

**Location:** Chattogram (BD15)

## Soil Characteristics
- **Soil region:** Chittagong_Coastal_Plain
- **Soil pH:** 5.37
- **Clay content:** 28.00%
- **Sand content:** 38.30%
- **Silt content:** 33.60%
- **Soil organic carbon:** 8.28 g/kg
- **CEC:** 11.80 cmol/kg
- **Nitrogen:** 0.87 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
