# Soil Profile: Narail District

**Location:** Narail (BD72)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.01
- **Clay content:** 37.40%
- **Sand content:** 22.00%
- **Silt content:** 40.70%
- **Soil organic carbon:** 9.41 g/kg
- **CEC:** 21.20 cmol/kg
- **Nitrogen:** 0.98 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
