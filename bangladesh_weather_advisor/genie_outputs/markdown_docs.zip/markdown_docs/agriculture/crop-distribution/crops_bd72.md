# Crop Distribution: Narail District

**Location:** Narail (BD72)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 87737.00 | 3.37 | Kharif-2 (Jul-Dec) |
| rice_boro | 76155.90 | 5.50 | Rabi (Dec-May) |
| rice_aus | 16839.40 | 2.32 | Kharif-1 (Mar-Aug) |
| jute | 7653.00 | 2.25 | Kharif-1 (Mar-Aug) |
| vegetables | 7310.80 | 13.13 | Rabi (Oct-Apr) |
| pulses | 6980.30 | 1.20 | Rabi (Oct-Mar) |
| oilseeds | 6481.50 | 0.93 | Rabi (Oct-Mar) |
| potato | 4398.20 | 20.39 | Rabi (Nov-Mar) |
| spices | 3606.10 | 4.78 | Rabi/Kharif |
| maize | 2769.40 | 8.77 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
