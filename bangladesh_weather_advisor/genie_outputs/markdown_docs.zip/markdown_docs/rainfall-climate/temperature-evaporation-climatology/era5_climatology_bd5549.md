# ERA5 Climatology: District BD5549

## Baseline Summary
- **Mean temperature climatology:** 24.70 °C
- **Mean evaporation climatology:** -2.81 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
