# ERA5 Climatology: District BD2003

## Baseline Summary
- **Mean temperature climatology:** 24.74 °C
- **Mean evaporation climatology:** -2.82 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
