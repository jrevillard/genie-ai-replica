# Crop Distribution: Tangail District

**Location:** Tangail (BD64)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 90352.60 | 4.32 | Kharif-2 (Jul-Dec) |
| rice_boro | 58576.30 | 5.19 | Rabi (Dec-May) |
| rice_aus | 16266.60 | 3.01 | Kharif-1 (Mar-Aug) |
| jute | 14502.90 | 2.67 | Kharif-1 (Mar-Aug) |
| vegetables | 8888.00 | 13.10 | Rabi (Oct-Apr) |
| maize | 7091.40 | 8.19 | Rabi (Oct-Apr) |
| pulses | 6432.40 | 1.21 | Rabi (Oct-Mar) |
| potato | 6403.40 | 18.23 | Rabi (Nov-Mar) |
| oilseeds | 4686.70 | 0.98 | Rabi (Oct-Mar) |
| wheat | 4573.50 | 3.12 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
