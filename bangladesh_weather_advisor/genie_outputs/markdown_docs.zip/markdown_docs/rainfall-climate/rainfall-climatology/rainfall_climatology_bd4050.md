# Rainfall Climatology: District BD4050

## Climatology Summary
- **Mean daily climatological rainfall:** 4.47 mm
- **Median (P50) rainfall benchmark:** 2.56 mm
- **Upper percentile (P90) benchmark:** 10.43 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
