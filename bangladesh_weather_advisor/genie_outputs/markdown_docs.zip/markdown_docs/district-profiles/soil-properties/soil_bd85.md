# Soil Profile: Rangpur District

**Location:** Rangpur (BD85)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 6.06
- **Clay content:** 25.00%
- **Sand content:** 34.20%
- **Silt content:** 39.40%
- **Soil organic carbon:** 9.90 g/kg
- **CEC:** 13.90 cmol/kg
- **Nitrogen:** 1.07 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
