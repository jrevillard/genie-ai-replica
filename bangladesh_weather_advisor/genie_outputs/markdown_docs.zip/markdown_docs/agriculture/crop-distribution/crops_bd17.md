# Crop Distribution: Chapainawabganj District

**Location:** Chapainawabganj (BD17)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 86698.40 | 4.04 | Kharif-2 (Jul-Dec) |
| rice_boro | 51129.10 | 4.58 | Rabi (Dec-May) |
| rice_aus | 16686.60 | 2.86 | Kharif-1 (Mar-Aug) |
| potato | 12010.50 | 20.57 | Rabi (Nov-Mar) |
| wheat | 11663.60 | 3.08 | Rabi (Nov-Mar) |
| maize | 10227.60 | 8.11 | Rabi (Oct-Apr) |
| vegetables | 9101.10 | 10.96 | Rabi (Oct-Apr) |
| jute | 7713.10 | 2.17 | Kharif-1 (Mar-Aug) |
| pulses | 7112.90 | 0.99 | Rabi (Oct-Mar) |
| oilseeds | 4841.20 | 0.84 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
