"""
DeepSeek AI client untuk chatbot BFEWS.

DeepSeek API kompatibel dengan format OpenAI, sehingga
menggunakan endpoint: https://api.deepseek.com/v1/chat/completions

Fungsi utama:
- generate_response(): jawab pertanyaan bebas dari pengguna
  dengan konteks data cuaca & banjir real-time
- Mendukung Bengali, English, dan bahasa lain secara otomatis
- Fallback ke rule-based jika API tidak tersedia / error
"""

import json
from datetime import datetime
from typing import Optional, Dict, List
import httpx
from loguru import logger

from config import DEEPSEEK_API_KEY

DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
DEEPSEEK_MODEL   = "deepseek-chat"   # atau "deepseek-reasoner" untuk analisis lebih dalam


# ─────────────────────────────────────────────
# System Prompt
# ─────────────────────────────────────────────

SYSTEM_PROMPT = """You are BFEWS Assistant — the AI chatbot for the Bangladesh Flood Early Warning System.

Your role:
- Provide accurate, real-time flood and weather information for Bangladesh
- Help residents understand risks and take appropriate action
- Respond in the SAME language the user writes in (Bengali, English, or any other language)
- Be concise, clear, and calm — avoid causing unnecessary panic
- Always prioritize life safety

You have access to real-time data for the user's zone:
{context}

Guidelines:
- If the user writes in Bengali (বাংলা), respond entirely in Bengali
- If the user writes in English, respond in English
- If the user writes in another language, respond in that language
- For danger situations, always mention emergency numbers: Police 999, Disaster 1090
- Keep responses under 300 words unless detailed explanation is needed
- Use simple language that rural residents can understand
- For evacuation queries, always provide specific shelter names and distances
- Never make up data — only use the provided real-time context

Current date/time: {datetime} (Bangladesh Standard Time)
"""


# ─────────────────────────────────────────────
# Context Builder
# ─────────────────────────────────────────────

def build_context(
    zone_name_en: str,
    zone_name_bn: str,
    alert_level: str,
    risk_score: float,
    weather: Optional[Dict],
    river_data: List[Dict],
    forecast: Optional[Dict],
    reasons: List[str],
) -> str:
    """
    Bangun konteks data real-time untuk dikirim ke DeepSeek.
    Format teks ringkas agar tidak membuang token.
    """
    lines = [
        f"ZONE: {zone_name_en} ({zone_name_bn})",
        f"ALERT LEVEL: {alert_level.upper()}",
        f"RISK SCORE: {risk_score:.0%}",
    ]

    if weather:
        lines += [
            f"WEATHER: {weather.get('weather_desc', 'N/A')}",
            f"TEMPERATURE: {weather.get('temperature', 'N/A')}°C",
            f"HUMIDITY: {weather.get('humidity', 'N/A')}%",
            f"RAINFALL (1h): {weather.get('rainfall_1h', 0):.1f} mm",
            f"RAINFALL (6h): {weather.get('rainfall_6h', 0):.1f} mm",
            f"WIND: {weather.get('wind_speed', 0):.0f} km/h",
            f"PRESSURE: {weather.get('pressure', 'N/A')} hPa",
        ]

    if river_data:
        lines.append("RIVER STATIONS:")
        for r in river_data:
            pct = r.get("level_pct", 0)
            lines.append(
                f"  - {r.get('station_id', '?')}: "
                f"{r.get('water_level_m', 0):.2f}m / {r.get('danger_level_m', 0):.1f}m "
                f"({pct:.0%} of danger level), "
                f"6h change: {r.get('change_6h_m', 0):+.2f}m"
            )

    if forecast:
        horizons = forecast.get("horizons", {})
        lines.append("FORECAST:")
        for h, data in horizons.items():
            lines.append(
                f"  - {h}h: rainfall {data.get('rainfall_mm', 0):.0f}mm, "
                f"flood probability {data.get('flood_prob', 0):.0%}"
            )

    if reasons:
        lines.append(f"RISK REASONS: {'; '.join(reasons[:3])}")

    return "\n".join(lines)


# ─────────────────────────────────────────────
# DeepSeek Client
# ─────────────────────────────────────────────

class DeepSeekClient:
    """
    Client untuk DeepSeek API.
    Digunakan untuk pertanyaan bebas yang tidak bisa dijawab
    oleh rule-based intent classifier.
    """

    def __init__(self):
        self.available = bool(DEEPSEEK_API_KEY and DEEPSEEK_API_KEY != "your_deepseek_api_key_here")
        if self.available:
            logger.info("✅ DeepSeek AI client siap")
        else:
            logger.warning("⚠️  DeepSeek API key tidak dikonfigurasi — chatbot berjalan dalam mode rule-based")

    async def generate_response(
        self,
        user_message: str,
        conversation_history: List[Dict],
        context_data: Dict,
        lang: str = "auto",
    ) -> Optional[str]:
        """
        Generate respons menggunakan DeepSeek.

        Args:
            user_message: pesan terbaru dari pengguna
            conversation_history: riwayat percakapan [{role, content}, ...]
            context_data: data real-time zona (weather, river, forecast, dll)
            lang: bahasa respons ("en", "bn", "auto")

        Returns:
            Teks respons, atau None jika gagal
        """
        if not self.available:
            return None

        # Build context string
        context_str = build_context(
            zone_name_en  = context_data.get("zone_name_en", "Unknown"),
            zone_name_bn  = context_data.get("zone_name_bn", "অজানা"),
            alert_level   = context_data.get("alert_level", "green"),
            risk_score    = context_data.get("risk_score", 0),
            weather       = context_data.get("weather"),
            river_data    = context_data.get("river_data", []),
            forecast      = context_data.get("forecast"),
            reasons       = context_data.get("reasons", []),
        )

        # Language instruction
        if lang == "bn":
            lang_instruction = "IMPORTANT: Always respond in Bengali (বাংলা) regardless of the question language."
        elif lang == "en":
            lang_instruction = "IMPORTANT: Always respond in English regardless of the question language."
        else:
            lang_instruction = "IMPORTANT: Detect the user's language and respond in the SAME language."

        # Build system prompt
        system = SYSTEM_PROMPT.format(
            context=context_str if context_str else "No zone data available yet.",
            datetime=datetime.now().strftime("%Y-%m-%d %H:%M BST"),
        ) + f"\n\n{lang_instruction}"

        # Build messages array
        messages = [{"role": "system", "content": system}]

        # Add conversation history (last 6 turns to save tokens)
        for msg in conversation_history[-6:]:
            if msg.get("role") in ("user", "assistant") and msg.get("content"):
                messages.append({"role": msg["role"], "content": msg["content"]})

        # Add current message
        messages.append({"role": "user", "content": user_message})

        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                resp = await client.post(
                    DEEPSEEK_API_URL,
                    headers={
                        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": DEEPSEEK_MODEL,
                        "messages": messages,
                        "max_tokens": 400,
                        "temperature": 0.4,   # lebih deterministik untuk info faktual
                        "stream": False,
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            response_text = data["choices"][0]["message"]["content"].strip()
            tokens_used = data.get("usage", {}).get("total_tokens", 0)
            logger.debug(f"🤖 DeepSeek response: {len(response_text)} chars, {tokens_used} tokens")
            return response_text

        except httpx.HTTPStatusError as e:
            logger.error(f"DeepSeek HTTP error {e.response.status_code}: {e.response.text[:200]}")
            return None
        except httpx.TimeoutException:
            logger.warning("DeepSeek timeout — falling back to rule-based")
            return None
        except Exception as e:
            logger.error(f"DeepSeek error: {e}")
            return None

    async def classify_intent_with_ai(self, message: str, lang: str = "auto") -> Optional[str]:
        """
        Gunakan DeepSeek untuk klasifikasi intent yang lebih akurat
        ketika rule-based classifier tidak yakin (confidence rendah).

        Returns: intent name atau None
        """
        if not self.available:
            return None

        prompt = f"""Classify this message into ONE of these intents:
greeting, status_query, forecast_query, river_query, evacuation_query, 
help_query, register, unregister, field_report, unknown

Message: "{message}"

Reply with ONLY the intent name, nothing else."""

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(
                    DEEPSEEK_API_URL,
                    headers={
                        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": DEEPSEEK_MODEL,
                        "messages": [{"role": "user", "content": prompt}],
                        "max_tokens": 20,
                        "temperature": 0.1,
                    },
                )
                resp.raise_for_status()
                intent = resp.json()["choices"][0]["message"]["content"].strip().lower()

                valid_intents = {
                    "greeting", "status_query", "forecast_query", "river_query",
                    "evacuation_query", "help_query", "register", "unregister",
                    "field_report", "unknown"
                }
                return intent if intent in valid_intents else None

        except Exception as e:
            logger.debug(f"DeepSeek intent classification error: {e}")
            return None


# Singleton instance
deepseek = DeepSeekClient()
