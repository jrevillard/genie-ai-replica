# Soil Profile: Khagrachhari District

**Location:** Khagrachhari (BD46)

## Soil Characteristics
- **Soil region:** Hill_Tracts
- **Soil pH:** 4.61
- **Clay content:** 34.10%
- **Sand content:** 30.90%
- **Silt content:** 36.40%
- **Soil organic carbon:** 15.27 g/kg
- **CEC:** 14.70 cmol/kg
- **Nitrogen:** 1.57 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
