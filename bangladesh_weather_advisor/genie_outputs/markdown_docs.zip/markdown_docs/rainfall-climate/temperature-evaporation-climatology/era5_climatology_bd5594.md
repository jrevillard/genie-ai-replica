# ERA5 Climatology: District BD5594

## Baseline Summary
- **Mean temperature climatology:** 24.48 °C
- **Mean evaporation climatology:** -2.60 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
