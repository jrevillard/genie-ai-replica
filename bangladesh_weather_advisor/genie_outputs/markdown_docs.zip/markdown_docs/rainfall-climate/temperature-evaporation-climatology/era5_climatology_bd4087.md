# ERA5 Climatology: District BD4087

## Baseline Summary
- **Mean temperature climatology:** 26.16 °C
- **Mean evaporation climatology:** -3.21 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
