# Soil Profile: Thakurgaon District

**Location:** Thakurgaon (BD94)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 6.00
- **Clay content:** 24.90%
- **Sand content:** 34.20%
- **Silt content:** 41.70%
- **Soil organic carbon:** 10.01 g/kg
- **CEC:** 14.60 cmol/kg
- **Nitrogen:** 1.05 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
