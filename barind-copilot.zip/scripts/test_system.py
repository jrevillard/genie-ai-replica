"""
Script testing komponen sistem secara individual.
Jalankan untuk memverifikasi semua komponen berfungsi.
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from loguru import logger


async def test_weather_collector():
    """Test pengumpulan data cuaca dari Open-Meteo."""
    logger.info("🧪 Test: Weather Collector (Open-Meteo)")
    from data.ingestion.weather_collector import fetch_openmeteo

    # Test dengan koordinat Dhaka
    data = await fetch_openmeteo(23.8103, 90.4125)
    if data:
        logger.success(f"  ✅ Open-Meteo OK: {data['temperature']}°C, {data['weather_desc']}")
    else:
        logger.error("  ❌ Open-Meteo gagal")
    return data is not None


async def test_river_simulator():
    """Test simulasi level sungai."""
    logger.info("🧪 Test: River Level Simulator")
    from data.ingestion.river_collector import simulate_river_level
    from datetime import datetime

    data = simulate_river_level("surma_sylhet", datetime.utcnow(), recent_rainfall_mm=25.0)
    logger.success(f"  ✅ River simulator OK: {data['water_level_m']}m "
                   f"(bahaya: {data['danger_level_m']}m)")
    return True


async def test_anomaly_detector():
    """Test deteksi anomali."""
    logger.info("🧪 Test: Anomaly Detector")
    from ml.anomaly.detector import RuleBasedDetector

    detector = RuleBasedDetector()

    # Test river surge
    anomaly = detector.check_river_surge(
        current_level=9.5, prev_level=7.0,
        hours=3.0, danger_level=10.5,
        zone_id="SYL-01", station_id="surma_sylhet"
    )
    if anomaly:
        logger.success(f"  ✅ River surge detected: severity={anomaly.severity:.2f}")
    else:
        logger.warning("  ⚠️  Tidak ada anomali terdeteksi (mungkin threshold tidak tercapai)")

    # Test pressure drop
    anomaly2 = detector.check_pressure_drop(
        current_pressure=985.0, prev_pressure=1005.0,
        hours=6.0, zone_id="CTG-02"
    )
    if anomaly2:
        logger.success(f"  ✅ Pressure drop detected: {anomaly2.description}")

    return True


async def test_intent_classifier():
    """Test klasifikasi intent chatbot."""
    logger.info("🧪 Test: Intent Classifier")
    from chatbot.nlp.intent_classifier import IntentClassifier

    classifier = IntentClassifier()

    test_cases = [
        ("হ্যালো", "greeting"),
        ("INFO", "status_query"),
        ("CUACA", "forecast_query"),
        ("BANJIR", "river_query"),
        ("BANTUAN", "evacuation_query"),
        ("EVAKUASI", "evacuation_query"),
        ("DAFTAR", "register"),
        ("BERHENTI", "unregister"),
        ("আবহাওয়ার পূর্বাভাস দিন", "forecast_query"),
    ]

    passed = 0
    for text, expected in test_cases:
        intent = classifier.classify(text)
        status = "✅" if intent.name == expected else "⚠️ "
        if intent.name == expected:
            passed += 1
        logger.info(f"  {status} '{text}' → {intent.name} (expected: {expected})")

    logger.info(f"  Hasil: {passed}/{len(test_cases)} benar")
    return passed >= len(test_cases) * 0.7  # 70% pass rate


async def test_message_templates():
    """Test format pesan."""
    logger.info("🧪 Test: Message Templates")
    from notifications.templates.messages import (
        format_whatsapp_alert, format_sms_alert, format_welcome_message,
        format_chatbot_status_response,
    )

    welcome_en = format_welcome_message(lang="en")
    assert len(welcome_en) > 50, "Welcome EN terlalu pendek"

    welcome_bn = format_welcome_message(lang="bn")
    assert len(welcome_bn) > 50, "Welcome BN terlalu pendek"

    sms = format_sms_alert("সিলেট", "yellow", ["নদীর পানি বাড়ছে"], lang="bn")
    assert len(sms) <= 160, f"SMS terlalu panjang: {len(sms)} karakter"

    wa = format_whatsapp_alert(
        "সিলেট", "Sylhet", "yellow", 0.65,
        ["নদীর পানি বাড়ছে"], 45.0, 35.0, 0.75, 0.4, "SYL-01", lang="bn"
    )
    assert len(wa) > 100, "WhatsApp message terlalu pendek"

    status_en = format_chatbot_status_response(
        "Sylhet Sadar", "সিলেট সদর", "green", 0.1,
        ["Normal conditions"], ["পরিস্থিতি স্বাভাবিক"],
        5.0, 15.0, 0.6, 0.05, 0.1, "Cloudy", lang="en"
    )
    assert "Current Status" in status_en, "Status EN missing English text"
    assert "Rainfall" in status_en, "Status EN missing Rainfall"

    logger.success(f"  ✅ Templates OK (SMS: {len(sms)} chars, WA: {len(wa)} chars, Status EN: {len(status_en)} chars)")
    return True


async def test_database():
    """Test koneksi dan operasi database."""
    logger.info("🧪 Test: Database")
    from data.storage.database import init_db, AsyncSessionLocal, WeatherReading
    from datetime import datetime

    await init_db()

    async with AsyncSessionLocal() as db:
        # Insert test record
        reading = WeatherReading(
            zone_id="TEST-01",
            timestamp=datetime.utcnow(),
            temperature=28.5,
            humidity=80.0,
            pressure=1010.0,
            wind_speed=15.0,
            rainfall_1h=5.0,
            rainfall_6h=20.0,
            source="test",
        )
        db.add(reading)
        await db.commit()

        # Query back
        from sqlalchemy.future import select
        result = await db.execute(
            select(WeatherReading).where(WeatherReading.zone_id == "TEST-01").limit(1)
        )
        saved = result.scalar_one_or_none()
        assert saved is not None, "Record tidak tersimpan"
        assert saved.temperature == 28.5

        # Cleanup
        await db.delete(saved)
        await db.commit()

    logger.success("  ✅ Database OK")
    return True


async def run_all_tests():
    """Jalankan semua test."""
    logger.info("=" * 60)
    logger.info("🧪 BFEWS System Tests")
    logger.info("=" * 60)

    tests = [
        ("Database", test_database),
        ("Weather Collector", test_weather_collector),
        ("River Simulator", test_river_simulator),
        ("Anomaly Detector", test_anomaly_detector),
        ("Intent Classifier", test_intent_classifier),
        ("Message Templates", test_message_templates),
    ]

    results = {}
    for name, test_fn in tests:
        try:
            result = await test_fn()
            results[name] = result
        except Exception as e:
            logger.error(f"  ❌ {name} ERROR: {e}")
            results[name] = False

    logger.info("=" * 60)
    logger.info("📊 Hasil Test:")
    passed = sum(1 for v in results.values() if v)
    for name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        logger.info(f"  {status} — {name}")

    logger.info(f"\n  Total: {passed}/{len(tests)} test berhasil")
    logger.info("=" * 60)

    return passed == len(tests)


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)
