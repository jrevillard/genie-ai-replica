# Soil Profile: Satkhira District

**Location:** Satkhira (BD87)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.61
- **Clay content:** 31.00%
- **Sand content:** 30.20%
- **Silt content:** 41.40%
- **Soil organic carbon:** 9.88 g/kg
- **CEC:** 15.70 cmol/kg
- **Nitrogen:** 0.98 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
