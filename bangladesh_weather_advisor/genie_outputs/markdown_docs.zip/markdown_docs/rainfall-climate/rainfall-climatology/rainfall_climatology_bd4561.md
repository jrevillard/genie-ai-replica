# Rainfall Climatology: District BD4561

## Climatology Summary
- **Mean daily climatological rainfall:** 6.41 mm
- **Median (P50) rainfall benchmark:** 4.26 mm
- **Upper percentile (P90) benchmark:** 14.14 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
