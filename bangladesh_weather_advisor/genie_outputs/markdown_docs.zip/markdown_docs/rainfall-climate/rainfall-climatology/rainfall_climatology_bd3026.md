# Rainfall Climatology: District BD3026

## Climatology Summary
- **Mean daily climatological rainfall:** 5.79 mm
- **Median (P50) rainfall benchmark:** 3.44 mm
- **Upper percentile (P90) benchmark:** 13.29 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
