"""
Konfigurasi pusat sistem BFEWS.
Semua konstanta, zona Bangladesh, dan pengaturan sistem ada di sini.
"""

import os
from dataclasses import dataclass, field
from typing import Dict, List, Tuple
from dotenv import load_dotenv

load_dotenv()


# ─────────────────────────────────────────────
# API Keys & Credentials
# ─────────────────────────────────────────────
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_WHATSAPP_FROM = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")
TWILIO_SMS_FROM = os.getenv("TWILIO_SMS_FROM", "")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
DEEPSEEK_API_KEY  = os.getenv("DEEPSEEK_API_KEY", "")
GROQ_API_KEY      = os.getenv("GROQ_API_KEY", "")

# ─────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./bfews.db")

# ─────────────────────────────────────────────
# Server
# ─────────────────────────────────────────────
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))
DEBUG = os.getenv("DEBUG", "true").lower() == "true"

# ─────────────────────────────────────────────
# Alert Thresholds
# ─────────────────────────────────────────────
RIVER_RISE_WARNING_M = float(os.getenv("RIVER_RISE_THRESHOLD_M", 1.5))
RIVER_RISE_DANGER_M = float(os.getenv("RIVER_DANGER_THRESHOLD_M", 2.5))
RAINFALL_WARNING_MM = float(os.getenv("RAINFALL_WARNING_MM", 50))
RAINFALL_DANGER_MM = float(os.getenv("RAINFALL_DANGER_MM", 100))
WIND_WARNING_KMH = float(os.getenv("WIND_WARNING_KMH", 60))
WIND_DANGER_KMH = float(os.getenv("WIND_DANGER_KMH", 90))

# ─────────────────────────────────────────────
# Refresh Intervals (detik)
# ─────────────────────────────────────────────
WEATHER_REFRESH_INTERVAL = int(os.getenv("WEATHER_REFRESH_INTERVAL", 3600))
RIVER_REFRESH_INTERVAL = int(os.getenv("RIVER_REFRESH_INTERVAL", 900))
SATELLITE_REFRESH_INTERVAL = int(os.getenv("SATELLITE_REFRESH_INTERVAL", 21600))
FORECAST_REFRESH_INTERVAL = int(os.getenv("FORECAST_REFRESH_INTERVAL", 10800))

# ─────────────────────────────────────────────
# Zona Bangladesh — Distrik & Koordinat
# ─────────────────────────────────────────────
@dataclass
class Zone:
    id: str
    name_en: str
    name_bn: str          # Nama dalam Bahasa Bengali
    district: str
    division: str
    lat: float
    lon: float
    river_stations: List[str] = field(default_factory=list)
    risk_multiplier: float = 1.0   # Zona rawan banjir dapat multiplier lebih tinggi


BANGLADESH_ZONES: Dict[str, Zone] = {
    # ── Divisi Sylhet (sangat rawan banjir) ──
    "SYL-01": Zone("SYL-01", "Sylhet Sadar", "সিলেট সদর", "Sylhet", "Sylhet",
                   24.8949, 91.8687, ["surma_sylhet"], 1.4),
    "SYL-02": Zone("SYL-02", "Sunamganj", "সুনামগঞ্জ", "Sunamganj", "Sylhet",
                   25.0658, 91.3950, ["surma_sunamganj", "kushiyara"], 1.6),
    "SYL-03": Zone("SYL-03", "Moulvibazar", "মৌলভীবাজার", "Moulvibazar", "Sylhet",
                   24.4826, 91.7774, ["manu_river"], 1.3),
    "SYL-04": Zone("SYL-04", "Habiganj", "হবিগঞ্জ", "Habiganj", "Sylhet",
                   24.3745, 91.4152, ["khowai_river"], 1.3),

    # ── Divisi Dhaka ──
    "DHA-01": Zone("DHA-01", "Dhaka City", "ঢাকা শহর", "Dhaka", "Dhaka",
                   23.8103, 90.4125, ["buriganga", "turag"], 1.2),
    "DHA-02": Zone("DHA-02", "Manikganj", "মানিকগঞ্জ", "Manikganj", "Dhaka",
                   23.8624, 90.0051, ["padma_manikganj"], 1.5),
    "DHA-03": Zone("DHA-03", "Munshiganj", "মুন্সীগঞ্জ", "Munshiganj", "Dhaka",
                   23.5422, 90.5302, ["padma_munshiganj", "meghna"], 1.4),
    "DHA-04": Zone("DHA-04", "Faridpur", "ফরিদপুর", "Faridpur", "Dhaka",
                   23.6070, 89.8429, ["padma_faridpur"], 1.5),

    # ── Divisi Chittagong (rawan siklon) ──
    "CTG-01": Zone("CTG-01", "Chittagong City", "চট্টগ্রাম শহর", "Chittagong", "Chittagong",
                   22.3569, 91.7832, ["karnaphuli"], 1.3),
    "CTG-02": Zone("CTG-02", "Cox's Bazar", "কক্সবাজার", "Cox's Bazar", "Chittagong",
                   21.4272, 92.0058, ["matamuhuri"], 1.8),
    "CTG-03": Zone("CTG-03", "Noakhali", "নোয়াখালী", "Noakhali", "Chittagong",
                   22.8696, 91.0994, ["meghna_noakhali"], 1.6),
    "CTG-04": Zone("CTG-04", "Feni", "ফেনী", "Feni", "Chittagong",
                   23.0233, 91.3960, ["feni_river"], 1.4),

    # ── Divisi Barisal (delta, sangat rawan) ──
    "BAR-01": Zone("BAR-01", "Barisal City", "বরিশাল শহর", "Barisal", "Barisal",
                   22.7010, 90.3535, ["kirtankhola"], 1.5),
    "BAR-02": Zone("BAR-02", "Bhola", "ভোলা", "Bhola", "Barisal",
                   22.6860, 90.6480, ["meghna_bhola", "tetulia"], 1.9),
    "BAR-03": Zone("BAR-03", "Patuakhali", "পটুয়াখালী", "Patuakhali", "Barisal",
                   22.3596, 90.3290, ["payra_river"], 1.7),

    # ── Divisi Rajshahi ──
    "RAJ-01": Zone("RAJ-01", "Rajshahi City", "রাজশাহী শহর", "Rajshahi", "Rajshahi",
                   24.3745, 88.6042, ["padma_rajshahi"], 1.2),
    "RAJ-02": Zone("RAJ-02", "Sirajganj", "সিরাজগঞ্জ", "Sirajganj", "Rajshahi",
                   24.4534, 89.7006, ["jamuna_sirajganj"], 1.6),

    # ── Divisi Khulna ──
    "KHU-01": Zone("KHU-01", "Khulna City", "খুলনা শহর", "Khulna", "Khulna",
                   22.8456, 89.5403, ["rupsha", "bhairab"], 1.3),
    "KHU-02": Zone("KHU-02", "Satkhira", "সাতক্ষীরা", "Satkhira", "Khulna",
                   22.7185, 89.0705, ["ichamati"], 1.5),

    # ── Divisi Rangpur ──
    "RAN-01": Zone("RAN-01", "Rangpur City", "রংপুর শহর", "Rangpur", "Rangpur",
                   25.7439, 89.2752, ["teesta_rangpur"], 1.3),
    "RAN-02": Zone("RAN-02", "Kurigram", "কুড়িগ্রাম", "Kurigram", "Rangpur",
                   25.8074, 89.6364, ["brahmaputra_kurigram", "teesta"], 1.8),

    # ── Divisi Mymensingh ──
    "MYM-01": Zone("MYM-01", "Mymensingh City", "ময়মনসিংহ শহর", "Mymensingh", "Mymensingh",
                   24.7471, 90.4203, ["brahmaputra_mymensingh", "old_brahmaputra"], 1.4),
}

# ─────────────────────────────────────────────
# Stasiun Sungai Simulasi (koordinat nyata)
# ─────────────────────────────────────────────
RIVER_STATIONS = {
    "surma_sylhet":        {"name": "Surma di Sylhet",       "lat": 24.8949, "lon": 91.8687, "danger_level_m": 10.5},
    "surma_sunamganj":     {"name": "Surma di Sunamganj",    "lat": 25.0658, "lon": 91.3950, "danger_level_m": 8.2},
    "kushiyara":           {"name": "Sungai Kushiyara",      "lat": 24.5000, "lon": 92.0000, "danger_level_m": 9.0},
    "brahmaputra_kurigram":{"name": "Brahmaputra di Kurigram","lat": 25.8074, "lon": 89.6364, "danger_level_m": 19.5},
    "jamuna_sirajganj":    {"name": "Jamuna di Sirajganj",   "lat": 24.4534, "lon": 89.7006, "danger_level_m": 14.8},
    "padma_rajshahi":      {"name": "Padma di Rajshahi",     "lat": 24.3745, "lon": 88.6042, "danger_level_m": 18.5},
    "padma_faridpur":      {"name": "Padma di Faridpur",     "lat": 23.6070, "lon": 89.8429, "danger_level_m": 12.0},
    "meghna_bhola":        {"name": "Meghna di Bhola",       "lat": 22.6860, "lon": 90.6480, "danger_level_m": 5.5},
    "karnaphuli":          {"name": "Karnaphuli di Chittagong","lat": 22.3569, "lon": 91.7832, "danger_level_m": 6.8},
    "teesta_rangpur":      {"name": "Teesta di Rangpur",     "lat": 25.7439, "lon": 89.2752, "danger_level_m": 11.2},
    "buriganga":           {"name": "Buriganga di Dhaka",    "lat": 23.7104, "lon": 90.3759, "danger_level_m": 6.0},
}

# ─────────────────────────────────────────────
# Level Peringatan
# ─────────────────────────────────────────────
class AlertLevel:
    GREEN  = "green"   # Normal
    YELLOW = "yellow"  # Waspada
    RED    = "red"     # Bahaya

ALERT_LEVEL_LABELS = {
    AlertLevel.GREEN:  {"en": "NORMAL",   "bn": "স্বাভাবিক"},
    AlertLevel.YELLOW: {"en": "WARNING",  "bn": "সতর্কতা"},
    AlertLevel.RED:    {"en": "DANGER",   "bn": "বিপদ"},
}

# ─────────────────────────────────────────────
# Titik Pengungsian (Evacuation Centers)
# ─────────────────────────────────────────────
EVACUATION_CENTERS = {
    "SYL-01": [
        {"name": "Sylhet Government College", "name_bn": "সিলেট সরকারি কলেজ", "lat": 24.9045, "lon": 91.8611, "capacity": 2000},
        {"name": "Osmani Stadium", "name_bn": "ওসমানী স্টেডিয়াম", "lat": 24.8978, "lon": 91.8723, "capacity": 5000},
    ],
    "CTG-02": [
        {"name": "Cox's Bazar Cyclone Shelter 1", "name_bn": "কক্সবাজার ঘূর্ণিঝড় আশ্রয়কেন্দ্র ১", "lat": 21.4350, "lon": 92.0100, "capacity": 3000},
        {"name": "Cox's Bazar Government School", "name_bn": "কক্সবাজার সরকারি বিদ্যালয়", "lat": 21.4200, "lon": 91.9950, "capacity": 1500},
    ],
    "BAR-02": [
        {"name": "Bhola Cyclone Shelter", "name_bn": "ভোলা ঘূর্ণিঝড় আশ্রয়কেন্দ্র", "lat": 22.6900, "lon": 90.6500, "capacity": 4000},
    ],
    "RAN-02": [
        {"name": "Kurigram Flood Shelter", "name_bn": "কুড়িগ্রাম বন্যা আশ্রয়কেন্দ্র", "lat": 25.8100, "lon": 89.6400, "capacity": 2500},
    ],
}

# Emergency contacts
EMERGENCY_CONTACTS = {
    "bn": "জরুরি নম্বর: ফায়ার সার্ভিস ১৯৯, পুলিশ ৯৯৯, দুর্যোগ ব্যবস্থাপনা ১০৯০",
    "en": "Emergency: Fire 199, Police 999, Disaster Management 1090",
}
