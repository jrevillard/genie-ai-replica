# Soil Profile: Sylhet District

**Location:** Sylhet (BD91)

## Soil Characteristics
- **Soil region:** Sylhet_Basin
- **Soil pH:** 5.10
- **Clay content:** 31.40%
- **Sand content:** 19.80%
- **Silt content:** 48.70%
- **Soil organic carbon:** 17.31 g/kg
- **CEC:** 19.60 cmol/kg
- **Nitrogen:** 1.74 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
