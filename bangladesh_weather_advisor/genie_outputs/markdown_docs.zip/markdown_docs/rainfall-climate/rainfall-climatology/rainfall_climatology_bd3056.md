# Rainfall Climatology: District BD3056

## Climatology Summary
- **Mean daily climatological rainfall:** 5.41 mm
- **Median (P50) rainfall benchmark:** 3.15 mm
- **Upper percentile (P90) benchmark:** 12.49 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
