# Rainfall Climatology: District BD4057

## Climatology Summary
- **Mean daily climatological rainfall:** 4.21 mm
- **Median (P50) rainfall benchmark:** 2.43 mm
- **Upper percentile (P90) benchmark:** 9.85 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
