# Soil Profile: Brahmanbaria District

**Location:** Brahmanbaria (BD13)

## Soil Characteristics
- **Soil region:** Hill_Tracts
- **Soil pH:** 5.04
- **Clay content:** 35.90%
- **Sand content:** 30.20%
- **Silt content:** 33.60%
- **Soil organic carbon:** 16.32 g/kg
- **CEC:** 15.20 cmol/kg
- **Nitrogen:** 1.43 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
