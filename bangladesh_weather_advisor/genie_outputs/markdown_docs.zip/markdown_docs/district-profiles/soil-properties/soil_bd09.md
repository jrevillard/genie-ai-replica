# Soil Profile: Bhola District

**Location:** Bhola (BD09)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.73
- **Clay content:** 43.00%
- **Sand content:** 14.50%
- **Silt content:** 41.60%
- **Soil organic carbon:** 13.54 g/kg
- **CEC:** 24.10 cmol/kg
- **Nitrogen:** 1.42 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
