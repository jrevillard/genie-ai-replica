# Rainfall Climatology: District BD4572

## Climatology Summary
- **Mean daily climatological rainfall:** 8.18 mm
- **Median (P50) rainfall benchmark:** 5.40 mm
- **Upper percentile (P90) benchmark:** 18.12 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
