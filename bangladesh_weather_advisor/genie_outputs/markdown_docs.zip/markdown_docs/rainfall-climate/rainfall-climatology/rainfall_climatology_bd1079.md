# Rainfall Climatology: District BD1079

## Climatology Summary
- **Mean daily climatological rainfall:** 5.44 mm
- **Median (P50) rainfall benchmark:** 3.23 mm
- **Upper percentile (P90) benchmark:** 12.51 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
