"""
Pengirim pesan WhatsApp via Twilio API.
Twilio menyediakan trial gratis dengan saldo $15.

Untuk produksi, bisa diganti dengan:
- Meta WhatsApp Business API langsung
- 360dialog
- WATI
"""

import asyncio
from typing import List, Optional
from loguru import logger

try:
    from twilio.rest import Client as TwilioClient
    from twilio.base.exceptions import TwilioRestException
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False
    logger.warning("Twilio tidak tersedia, WhatsApp sender dinonaktifkan")

from config import TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_WHATSAPP_FROM


class WhatsAppSender:
    """Pengirim pesan WhatsApp via Twilio."""

    def __init__(self):
        self.client = None
        if TWILIO_AVAILABLE and TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
            self.client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
            logger.info("✅ WhatsApp sender (Twilio) siap")
        else:
            logger.warning("⚠️  WhatsApp sender tidak aktif (Twilio tidak dikonfigurasi)")

    def _format_number(self, phone: str) -> str:
        """Format nomor telepon ke format WhatsApp Twilio."""
        # Hapus karakter non-digit
        digits = "".join(c for c in phone if c.isdigit())

        # Tambah kode negara Bangladesh jika belum ada
        if digits.startswith("0"):
            digits = "880" + digits[1:]
        elif not digits.startswith("880"):
            digits = "880" + digits

        return f"whatsapp:+{digits}"

    async def send_message(self, to_phone: str, message: str) -> bool:
        """
        Kirim satu pesan WhatsApp.
        Returns True jika berhasil.
        """
        if not self.client:
            logger.debug(f"[MOCK WhatsApp] → {to_phone}: {message[:80]}...")
            return True  # Mock mode untuk development

        to_formatted = self._format_number(to_phone)

        try:
            # Jalankan di thread pool (Twilio client tidak async)
            loop = asyncio.get_event_loop()
            msg = await loop.run_in_executor(
                None,
                lambda: self.client.messages.create(
                    from_=TWILIO_WHATSAPP_FROM,
                    to=to_formatted,
                    body=message,
                )
            )
            logger.debug(f"✅ WhatsApp terkirim ke {to_phone}: SID={msg.sid}")
            return True

        except TwilioRestException as e:
            logger.error(f"❌ WhatsApp gagal ke {to_phone}: {e.msg}")
            return False
        except Exception as e:
            logger.error(f"❌ WhatsApp error ke {to_phone}: {e}")
            return False

    async def broadcast(self, phone_numbers: List[str], message: str,
                        batch_size: int = 10, delay_seconds: float = 1.0) -> dict:
        """
        Kirim pesan ke banyak nomor sekaligus.
        Menggunakan batching untuk menghindari rate limit.
        """
        total = len(phone_numbers)
        success = 0
        failed = 0

        logger.info(f"📤 Memulai WhatsApp broadcast ke {total} nomor...")

        for i in range(0, total, batch_size):
            batch = phone_numbers[i:i + batch_size]
            tasks = [self.send_message(phone, message) for phone in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for result in results:
                if result is True:
                    success += 1
                else:
                    failed += 1

            # Delay antar batch
            if i + batch_size < total:
                await asyncio.sleep(delay_seconds)

            logger.debug(f"  Batch {i//batch_size + 1}: {success}/{total} terkirim")

        logger.info(f"✅ WhatsApp broadcast selesai: {success} berhasil, {failed} gagal")
        return {"success": success, "failed": failed, "total": total}


class SMSSender:
    """Pengirim SMS via Twilio (fallback untuk HP tanpa internet)."""

    def __init__(self):
        self.client = None
        from config import TWILIO_SMS_FROM
        self.from_number = TWILIO_SMS_FROM

        if TWILIO_AVAILABLE and TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
            self.client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
            logger.info("✅ SMS sender (Twilio) siap")
        else:
            logger.warning("⚠️  SMS sender tidak aktif")

    def _format_number(self, phone: str) -> str:
        """Format nomor ke E.164."""
        digits = "".join(c for c in phone if c.isdigit())
        if digits.startswith("0"):
            digits = "880" + digits[1:]
        elif not digits.startswith("880"):
            digits = "880" + digits
        return f"+{digits}"

    async def send_sms(self, to_phone: str, message: str) -> bool:
        """Kirim SMS. Pesan dipotong ke 160 karakter."""
        # Potong ke 160 karakter
        if len(message) > 160:
            message = message[:157] + "..."

        if not self.client:
            logger.debug(f"[MOCK SMS] → {to_phone}: {message}")
            return True

        to_formatted = self._format_number(to_phone)

        try:
            loop = asyncio.get_event_loop()
            msg = await loop.run_in_executor(
                None,
                lambda: self.client.messages.create(
                    from_=self.from_number,
                    to=to_formatted,
                    body=message,
                )
            )
            logger.debug(f"✅ SMS terkirim ke {to_phone}: SID={msg.sid}")
            return True

        except Exception as e:
            logger.error(f"❌ SMS gagal ke {to_phone}: {e}")
            return False

    async def broadcast_sms(self, phone_numbers: List[str], message: str) -> dict:
        """Broadcast SMS ke banyak nomor."""
        success = 0
        failed = 0

        for phone in phone_numbers:
            result = await self.send_sms(phone, message)
            if result:
                success += 1
            else:
                failed += 1
            await asyncio.sleep(0.1)  # Rate limiting

        logger.info(f"✅ SMS broadcast: {success}/{len(phone_numbers)} berhasil")
        return {"success": success, "failed": failed}
