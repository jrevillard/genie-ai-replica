# Crop Distribution: Magura District

**Location:** Magura (BD65)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 83122.60 | 4.23 | Kharif-2 (Jul-Dec) |
| rice_boro | 61129.50 | 5.08 | Rabi (Dec-May) |
| rice_aus | 18875.30 | 2.57 | Kharif-1 (Mar-Aug) |
| vegetables | 8465.80 | 13.34 | Rabi (Oct-Apr) |
| jute | 7356.20 | 2.15 | Kharif-1 (Mar-Aug) |
| pulses | 6816.50 | 0.94 | Rabi (Oct-Mar) |
| oilseeds | 6080.90 | 0.86 | Rabi (Oct-Mar) |
| spices | 3888.80 | 4.73 | Rabi/Kharif |
| potato | 3758.80 | 20.67 | Rabi (Nov-Mar) |
| maize | 2671.50 | 7.86 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
