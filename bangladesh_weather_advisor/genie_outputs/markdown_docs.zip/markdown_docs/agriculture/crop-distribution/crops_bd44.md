# Crop Distribution: Jhenaidah District

**Location:** Jhenaidah (BD44)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 82306.10 | 3.66 | Kharif-2 (Jul-Dec) |
| rice_boro | 74372.60 | 5.10 | Rabi (Dec-May) |
| rice_aus | 16402.20 | 2.70 | Kharif-1 (Mar-Aug) |
| jute | 9260.70 | 2.45 | Kharif-1 (Mar-Aug) |
| vegetables | 8238.80 | 12.74 | Rabi (Oct-Apr) |
| oilseeds | 5724.50 | 1.12 | Rabi (Oct-Mar) |
| pulses | 5507.00 | 1.14 | Rabi (Oct-Mar) |
| potato | 3875.10 | 19.41 | Rabi (Nov-Mar) |
| spices | 3132.70 | 5.11 | Rabi/Kharif |
| maize | 2637.10 | 9.77 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
