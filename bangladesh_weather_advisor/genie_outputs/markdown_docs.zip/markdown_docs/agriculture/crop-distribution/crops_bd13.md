# Crop Distribution: Brahmanbaria District

**Location:** Brahmanbaria (BD13)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 67613.30 | 5.18 | Rabi (Dec-May) |
| rice_aman | 58289.00 | 3.70 | Kharif-2 (Jul-Dec) |
| rice_aus | 15597.90 | 2.86 | Kharif-1 (Mar-Aug) |
| jute | 6597.70 | 2.39 | Kharif-1 (Mar-Aug) |
| vegetables | 6475.60 | 10.31 | Rabi (Oct-Apr) |
| pulses | 5741.80 | 1.23 | Rabi (Oct-Mar) |
| oilseeds | 5307.30 | 0.97 | Rabi (Oct-Mar) |
| spices | 4651.80 | 4.37 | Rabi/Kharif |
| maize | 3928.10 | 9.22 | Rabi (Oct-Apr) |
| potato | 2815.60 | 19.08 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
