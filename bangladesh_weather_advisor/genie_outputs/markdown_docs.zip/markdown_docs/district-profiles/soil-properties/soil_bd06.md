# Soil Profile: Barishal District

**Location:** Barishal (BD06)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.93
- **Clay content:** 41.90%
- **Sand content:** 14.80%
- **Silt content:** 42.30%
- **Soil organic carbon:** 13.81 g/kg
- **CEC:** 23.90 cmol/kg
- **Nitrogen:** 1.34 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
