# Soil Profile: Gazipur District

**Location:** Gazipur (BD33)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.34
- **Clay content:** 30.20%
- **Sand content:** 30.90%
- **Silt content:** 39.60%
- **Soil organic carbon:** 10.23 g/kg
- **CEC:** 15.50 cmol/kg
- **Nitrogen:** 1.01 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
