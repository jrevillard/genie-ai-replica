"""
Genie AI Client — Integrasi BFEWS dengan Genie AI Platform (Llama 3.1 8B)

Server: 164.52.195.30:8000 (vLLM OpenAI-compatible API)
Model: meta-llama/Llama-3.1-8B-Instruct
Format: OpenAI Chat Completions API

Fallback: Groq (jika Genie AI tidak tersedia)
"""

import os
from datetime import datetime
from typing import Optional, Dict, List
import httpx
from loguru import logger

GENIE_AI_URL = os.getenv("GENIE_AI_URL", "http://164.52.195.30:8000")
GENIE_AI_MODEL = os.getenv("GENIE_AI_MODEL", "meta-llama/Llama-3.1-8B-Instruct")
GENIE_AI_ENABLED = os.getenv("GENIE_AI_ENABLED", "true").lower() == "true"


SYSTEM_PROMPT = """You are BFEWS Assistant for the Bangladesh Flood Early Warning System.

## Personality
- Warm, helpful, conversational
- Calm and reassuring; only urgent when situation is truly dangerous
- Adapt tone to user's message

## LANGUAGE RULE
Detect the user's language and respond in the EXACT SAME language.
Bengali, English, Indonesian, Arabic, French, Chinese - any language.
NEVER mix languages.

## Real-Time Data
{context}

## Behavior
1. Greeting -> greet back, ask which district
2. Which area dangerous -> list highest-risk zones
3. Question without district -> answer generally, ask for district
4. Zone data available -> include key numbers (river pct, rainfall, flood prob)
5. RED alert -> mention Police 999, Disaster 1090
6. Keep responses 2-5 sentences for simple questions
7. Never fabricate data

Current time: {datetime} UTC (Bangladesh = UTC+6)
"""



def build_zone_context(ctx):
    if not ctx:
        return 'No zone selected yet.'
    zone = ctx.get('zone_name_en', '?')
    level = ctx.get('alert_level', 'green').upper()
    risk = ctx.get('risk_score', 0)
    lines = [f'ZONE: {zone} | ALERT: {level} | RISK: {risk:.0%}']
    w = ctx.get('weather')
    if w:
        desc = w.get('weather_desc', '?')
        temp = w.get('temperature', '?')
        rain = w.get('rainfall_6h', 0)
        wind = w.get('wind_speed', 0)
        lines.append(f'WEATHER: {desc} | Temp: {temp}C | Rain: {rain}mm/6h | Wind: {wind}km/h')
    for r in ctx.get('river_data', []):
        name = r.get('name', '?')
        lev = r.get('water_level_m', 0)
        dan = r.get('danger_level_m', 10)
        pct = r.get('level_pct', 0)
        lines.append(f'RIVER {name}: {lev:.2f}m / {dan:.1f}m ({pct:.0%})')
    return chr(10).join(lines)

class GenieAIClient:
    """Client for Genie AI vLLM server (Llama 3.1 8B)."""

    def __init__(self):
        self.available = GENIE_AI_ENABLED
        self.url = GENIE_AI_URL
        self.model = GENIE_AI_MODEL
        if self.available:
            logger.info(f"Genie AI client ready: {self.url} model={self.model}")
        else:
            logger.info("Genie AI disabled, using Groq fallback")


    async def generate_response(
        self,
        user_message: str,
        conversation_history: List[Dict],
        context_data: Dict,
        lang: str = "auto",
        zone_id: Optional[str] = None,
    ) -> Optional[str]:
        if not self.available:
            return None

        pass
        zone_context = build_zone_context(context_data)
        zone_summary = ""

        now_utc = datetime.utcnow().strftime("%Y-%m-%d %H:%M")
        system_content = SYSTEM_PROMPT.format(
            context=zone_context + "\n" + zone_summary,
            datetime=now_utc,
        )

        messages = [{"role": "system", "content": system_content}]
        for msg in conversation_history[-8:]:
            if msg.get("role") in ("user", "assistant") and msg.get("content"):
                messages.append({"role": msg["role"], "content": msg["content"]})
        messages.append({"role": "user", "content": user_message})

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(
                    f"{self.url}/v1/chat/completions",
                    json={
                        "model": self.model,
                        "messages": messages,
                        "max_tokens": 500,
                        "temperature": 0.5,
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            text = data["choices"][0]["message"]["content"].strip()
            tokens = data.get("usage", {}).get("total_tokens", 0)
            logger.debug(f"Genie AI: {len(text)} chars, {tokens} tokens")
            return text

        except httpx.ConnectError:
            logger.warning("Genie AI unreachable, falling back to Groq")
            return None
        except httpx.TimeoutException:
            logger.warning("Genie AI timeout, falling back to Groq")
            return None
        except Exception as e:
            logger.error(f"Genie AI error: {e}")
            return None


genie_ai_client = GenieAIClient()
