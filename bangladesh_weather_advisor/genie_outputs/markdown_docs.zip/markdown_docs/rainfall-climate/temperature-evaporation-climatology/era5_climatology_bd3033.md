# ERA5 Climatology: District BD3033

## Baseline Summary
- **Mean temperature climatology:** 25.37 °C
- **Mean evaporation climatology:** -2.78 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
