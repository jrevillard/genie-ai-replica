# ERA5 Climatology: District BD1006

## Baseline Summary
- **Mean temperature climatology:** 25.79 °C
- **Mean evaporation climatology:** -3.07 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
