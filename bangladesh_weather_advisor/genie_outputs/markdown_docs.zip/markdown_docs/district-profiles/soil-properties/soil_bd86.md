# Soil Profile: Shariatpur District

**Location:** Shariatpur (BD86)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.26
- **Clay content:** 36.90%
- **Sand content:** 22.50%
- **Silt content:** 39.50%
- **Soil organic carbon:** 9.97 g/kg
- **CEC:** 21.00 cmol/kg
- **Nitrogen:** 1.01 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
