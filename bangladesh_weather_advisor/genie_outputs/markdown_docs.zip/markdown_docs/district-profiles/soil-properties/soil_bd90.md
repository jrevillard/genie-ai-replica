# Soil Profile: Sunamganj District

**Location:** Sunamganj (BD90)

## Soil Characteristics
- **Soil region:** Sylhet_Basin
- **Soil pH:** 5.07
- **Clay content:** 29.30%
- **Sand content:** 19.40%
- **Silt content:** 49.20%
- **Soil organic carbon:** 17.69 g/kg
- **CEC:** 20.80 cmol/kg
- **Nitrogen:** 1.86 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
