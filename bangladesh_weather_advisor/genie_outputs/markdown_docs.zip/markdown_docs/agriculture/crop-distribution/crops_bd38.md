# Crop Distribution: Habiganj District

**Location:** Habiganj (BD38)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 83908.30 | 3.89 | Kharif-2 (Jul-Dec) |
| rice_boro | 53388.70 | 4.90 | Rabi (Dec-May) |
| rice_aus | 14627.70 | 2.99 | Kharif-1 (Mar-Aug) |
| vegetables | 7022.60 | 13.33 | Rabi (Oct-Apr) |
| pulses | 5380.80 | 0.98 | Rabi (Oct-Mar) |
| oilseeds | 4662.10 | 0.84 | Rabi (Oct-Mar) |
| spices | 3165.10 | 4.29 | Rabi/Kharif |
| jute | 3096.00 | 2.67 | Kharif-1 (Mar-Aug) |
| potato | 2272.00 | 19.64 | Rabi (Nov-Mar) |
| maize | 2068.40 | 8.15 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
