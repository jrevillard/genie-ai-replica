"""
River Data Collector — Open-Meteo Flood API (GloFAS v4)

Sumber: https://flood-api.open-meteo.com/v1/flood
- Data: debit sungai real (m³/s) dari model GloFAS
- Update: harian
- Gratis, tanpa API key
- Historis sejak 1984, forecast hingga 210 hari

Konversi debit (m³/s) → level air (m):
  Menggunakan Manning's equation approximation:
  h ≈ (Q / (w * C)) ^ (3/5)
  dimana w = lebar sungai estimasi, C = koefisien aliran
"""

import asyncio
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import httpx
from loguru import logger

from config import RIVER_STATIONS, BANGLADESH_ZONES
from data.storage.database import AsyncSessionLocal, RiverReading
from sqlalchemy.future import select


FLOOD_API_URL = "https://flood-api.open-meteo.com/v1/flood"

# Parameter sungai untuk konversi debit → level
# Format: {station_id: {width_m, manning_n, slope, danger_level_m}}
RIVER_PARAMS = {
    "surma_sylhet":         {"width": 120, "coeff": 0.045, "danger_level_m": 10.5},
    "surma_sunamganj":      {"width": 100, "coeff": 0.042, "danger_level_m": 8.2},
    "kushiyara":            {"width": 90,  "coeff": 0.040, "danger_level_m": 9.0},
    "brahmaputra_kurigram": {"width": 800, "coeff": 0.035, "danger_level_m": 19.5},
    "jamuna_sirajganj":     {"width": 600, "coeff": 0.033, "danger_level_m": 14.8},
    "padma_rajshahi":       {"width": 500, "coeff": 0.035, "danger_level_m": 18.5},
    "padma_faridpur":       {"width": 450, "coeff": 0.036, "danger_level_m": 12.0},
    "meghna_bhola":         {"width": 200, "coeff": 0.038, "danger_level_m": 5.5},
    "karnaphuli":           {"width": 150, "coeff": 0.040, "danger_level_m": 6.8},
    "teesta_rangpur":       {"width": 180, "coeff": 0.038, "danger_level_m": 11.2},
    "buriganga":            {"width": 80,  "coeff": 0.045, "danger_level_m": 6.0},
    "turag":                {"width": 60,  "coeff": 0.045, "danger_level_m": 10.0},
    "manu_river":           {"width": 70,  "coeff": 0.042, "danger_level_m": 7.5},
    "khowai_river":         {"width": 65,  "coeff": 0.042, "danger_level_m": 7.0},
    "feni_river":           {"width": 80,  "coeff": 0.040, "danger_level_m": 6.5},
    "matamuhuri":           {"width": 90,  "coeff": 0.040, "danger_level_m": 7.0},
    "meghna_noakhali":      {"width": 180, "coeff": 0.038, "danger_level_m": 5.0},
    "rupsha":               {"width": 100, "coeff": 0.040, "danger_level_m": 5.5},
    "bhairab":              {"width": 80,  "coeff": 0.042, "danger_level_m": 5.0},
    "ichamati":             {"width": 60,  "coeff": 0.045, "danger_level_m": 4.5},
    "kirtankhola":          {"width": 90,  "coeff": 0.040, "danger_level_m": 5.0},
    "payra_river":          {"width": 120, "coeff": 0.038, "danger_level_m": 4.5},
    "tetulia":              {"width": 200, "coeff": 0.036, "danger_level_m": 5.0},
    "old_brahmaputra":      {"width": 150, "coeff": 0.040, "danger_level_m": 8.0},
    "padma_munshiganj":     {"width": 400, "coeff": 0.035, "danger_level_m": 10.0},
    "padma_manikganj":      {"width": 420, "coeff": 0.035, "danger_level_m": 11.0},
    "buriganga":            {"width": 80,  "coeff": 0.045, "danger_level_m": 6.0},
}


def discharge_to_level(discharge_m3s: float, station_id: str) -> float:
    """
    Konversi debit sungai (m³/s) ke level air (m).
    
    Menggunakan pendekatan Manning's equation:
    Q = (1/n) * A * R^(2/3) * S^(1/2)
    
    Simplified untuk rectangular channel:
    h ≈ (Q * n / (w * S^0.5)) ^ (3/5)
    
    Untuk estimasi praktis, kita gunakan power law:
    h = a * Q^b  dimana a,b dikalibrasi per sungai
    """
    params = RIVER_PARAMS.get(station_id, {"width": 100, "coeff": 0.040, "danger_level_m": 10.0})
    w = params["width"]
    n = params["coeff"]  # Manning's n
    
    if discharge_m3s <= 0:
        return 0.5
    
    # Simplified Manning: h = (Q*n / w)^(3/5) * correction
    # Asumsi slope S ≈ 0.0001 (sungai dataran rendah Bangladesh)
    S = 0.0001
    
    # h = (Q * n / (w * sqrt(S))) ^ (3/5)
    h = (discharge_m3s * n / (w * math.sqrt(S))) ** 0.6
    
    # Clamp ke range yang masuk akal
    return max(0.3, min(h, params["danger_level_m"] * 1.5))


async def fetch_glofas_discharge(
    lat: float,
    lon: float,
    past_days: int = 30,
    forecast_days: int = 92,
) -> Optional[Dict]:
    """
    Ambil data debit sungai dari Open-Meteo Flood API (GloFAS v4).
    
    Returns dict dengan:
    - times: list tanggal
    - discharge: list debit (m³/s) historis
    - forecast_discharge: list debit forecast
    - forecast_p25, forecast_p75: percentile ensemble
    """
    params = {
        "latitude":      lat,
        "longitude":     lon,
        "daily":         "river_discharge,river_discharge_mean,river_discharge_p25,river_discharge_p75",
        "past_days":     past_days,
        "forecast_days": forecast_days,
        "timeformat":    "iso8601",
    }

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.get(FLOOD_API_URL, params=params)
            resp.raise_for_status()
            data = resp.json()

        daily = data.get("daily", {})
        times = daily.get("time", [])
        discharge = daily.get("river_discharge", [])
        discharge_mean = daily.get("river_discharge_mean", discharge)
        discharge_p25 = daily.get("river_discharge_p25", [])
        discharge_p75 = daily.get("river_discharge_p75", [])

        if not times or not discharge:
            return None

        # Pisahkan historis dan forecast
        today = datetime.utcnow().date().isoformat()
        hist_times, hist_q = [], []
        fc_times, fc_q, fc_p25, fc_p75 = [], [], [], []

        for i, t in enumerate(times):
            q = discharge[i] if i < len(discharge) else None
            if q is None:
                continue
            if t <= today:
                hist_times.append(t)
                hist_q.append(q)
            else:
                fc_times.append(t)
                fc_q.append(discharge_mean[i] if i < len(discharge_mean) and discharge_mean[i] else q)
                fc_p25.append(discharge_p25[i] if i < len(discharge_p25) and discharge_p25[i] else q * 0.8)
                fc_p75.append(discharge_p75[i] if i < len(discharge_p75) and discharge_p75[i] else q * 1.2)

        return {
            "lat": data.get("latitude"),
            "lon": data.get("longitude"),
            "hist_times":    hist_times,
            "hist_discharge": hist_q,
            "fc_times":      fc_times,
            "fc_discharge":  fc_q,
            "fc_p25":        fc_p25,
            "fc_p75":        fc_p75,
        }

    except Exception as e:
        logger.warning(f"GloFAS error ({lat},{lon}): {e}")
        return None


async def collect_river_for_station(station_id: str, zone_id: str) -> bool:
    """Kumpulkan data level sungai untuk satu stasiun dari GloFAS."""
    station_info = RIVER_STATIONS.get(station_id, {})
    lat = station_info.get("lat")
    lon = station_info.get("lon")

    if not lat or not lon:
        logger.warning(f"Koordinat tidak ditemukan untuk {station_id}")
        return False

    # Ambil data GloFAS
    glofas = await fetch_glofas_discharge(lat, lon, past_days=7, forecast_days=30)

    if not glofas or not glofas["hist_discharge"]:
        logger.warning(f"GloFAS tidak ada data untuk {station_id}, pakai fallback simulasi")
        return await _collect_simulated(station_id, zone_id)

    # Ambil nilai terbaru
    current_q = glofas["hist_discharge"][-1]
    prev_q = glofas["hist_discharge"][-7] if len(glofas["hist_discharge"]) >= 7 else current_q

    # Konversi debit → level
    current_level = discharge_to_level(current_q, station_id)
    prev_level = discharge_to_level(prev_q, station_id)
    change_6h = (current_level - prev_level) / 4  # 7 hari → estimasi 6 jam

    danger_level = RIVER_PARAMS.get(station_id, {}).get("danger_level_m", 10.0)

    # Simpan ke database
    async with AsyncSessionLocal() as db:
        reading = RiverReading(
            station_id      = station_id,
            zone_id         = zone_id,
            timestamp       = datetime.utcnow(),
            water_level_m   = round(current_level, 3),
            flow_rate_m3s   = round(current_q, 2),
            change_6h_m     = round(change_6h, 3),
            danger_level_m  = danger_level,
            source          = "glofas_v4",
        )
        db.add(reading)
        await db.commit()

    logger.debug(
        f"🌊 GloFAS {station_id}: Q={current_q:.1f}m³/s → "
        f"h={current_level:.2f}m (danger={danger_level}m)"
    )
    return True


async def _collect_simulated(station_id: str, zone_id: str) -> bool:
    """Fallback ke simulasi jika GloFAS tidak tersedia."""
    from datetime import datetime
    import random, math

    station_info = RIVER_STATIONS.get(station_id, {})
    danger_level = station_info.get("danger_level_m", 10.0)

    # Seasonal simulation
    day_of_year = datetime.utcnow().timetuple().tm_yday
    peak_day = 225
    seasonal = 0.5 + 0.5 * math.sin(2 * math.pi * (day_of_year - peak_day) / 365 - math.pi / 2)
    seasonal = max(0.1, min(1.0, seasonal))
    base_level = danger_level * (0.30 + 0.55 * seasonal)
    level = max(0.5, base_level + random.gauss(0, 0.05))

    async with AsyncSessionLocal() as db:
        reading = RiverReading(
            station_id     = station_id,
            zone_id        = zone_id,
            timestamp      = datetime.utcnow(),
            water_level_m  = round(level, 3),
            flow_rate_m3s  = round((level / danger_level) ** 2 * 5000, 1),
            change_6h_m    = round(random.gauss(0, 0.03), 3),
            danger_level_m = danger_level,
            source         = "simulated_seasonal",
        )
        db.add(reading)
        await db.commit()
    return True


async def collect_all_rivers():
    """Kumpulkan data semua stasiun sungai secara paralel."""
    station_zone_map = {}
    for zone_id, zone in BANGLADESH_ZONES.items():
        for station_id in zone.river_stations:
            station_zone_map[station_id] = zone_id

    logger.info(f"🌊 Mengumpulkan data {len(station_zone_map)} stasiun sungai (GloFAS)...")

    tasks = [
        collect_river_for_station(sid, zid)
        for sid, zid in station_zone_map.items()
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    success = sum(1 for r in results if r is True)
    logger.info(f"✅ Data sungai: {success}/{len(station_zone_map)} stasiun berhasil")
    return success


async def get_glofas_forecast_series(station_id: str) -> Optional[Dict]:
    """
    Ambil series forecast GloFAS untuk digunakan oleh model ML.
    Returns data 90 hari ke depan dengan percentile ensemble.
    """
    station_info = RIVER_STATIONS.get(station_id, {})
    lat = station_info.get("lat")
    lon = station_info.get("lon")
    if not lat or not lon:
        return None

    return await fetch_glofas_discharge(lat, lon, past_days=90, forecast_days=90)
