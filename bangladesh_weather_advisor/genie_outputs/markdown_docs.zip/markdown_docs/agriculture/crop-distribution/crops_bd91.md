# Crop Distribution: Sylhet District

**Location:** Sylhet (BD91)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 73747.20 | 5.30 | Rabi (Dec-May) |
| rice_aman | 61514.20 | 4.06 | Kharif-2 (Jul-Dec) |
| rice_aus | 11842.40 | 2.77 | Kharif-1 (Mar-Aug) |
| vegetables | 6761.00 | 11.61 | Rabi (Oct-Apr) |
| pulses | 6306.20 | 1.12 | Rabi (Oct-Mar) |
| oilseeds | 4631.60 | 0.87 | Rabi (Oct-Mar) |
| spices | 4074.90 | 4.86 | Rabi/Kharif |
| jute | 3232.30 | 2.26 | Kharif-1 (Mar-Aug) |
| potato | 2575.60 | 22.68 | Rabi (Nov-Mar) |
| maize | 2463.70 | 7.43 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
