# Crop Distribution: Barguna District

**Location:** Barguna (BD10)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 101511.60 | 4.43 | Kharif-2 (Jul-Dec) |
| rice_boro | 72250.30 | 5.12 | Rabi (Dec-May) |
| rice_aus | 24223.30 | 2.86 | Kharif-1 (Mar-Aug) |
| vegetables | 8181.70 | 12.73 | Rabi (Oct-Apr) |
| pulses | 6992.60 | 1.09 | Rabi (Oct-Mar) |
| oilseeds | 5900.70 | 1.03 | Rabi (Oct-Mar) |
| spices | 4039.60 | 5.00 | Rabi/Kharif |
| jute | 3535.10 | 2.27 | Kharif-1 (Mar-Aug) |
| potato | 2107.90 | 21.93 | Rabi (Nov-Mar) |
| maize | 1833.00 | 9.43 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
