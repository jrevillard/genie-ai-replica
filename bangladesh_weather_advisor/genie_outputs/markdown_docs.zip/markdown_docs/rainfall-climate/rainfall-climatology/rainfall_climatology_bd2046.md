# Rainfall Climatology: District BD2046

## Climatology Summary
- **Mean daily climatological rainfall:** 8.65 mm
- **Median (P50) rainfall benchmark:** 5.19 mm
- **Upper percentile (P90) benchmark:** 19.73 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
