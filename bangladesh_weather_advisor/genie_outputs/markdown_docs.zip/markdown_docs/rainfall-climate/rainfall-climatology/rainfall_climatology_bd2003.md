# Rainfall Climatology: District BD2003

## Climatology Summary
- **Mean daily climatological rainfall:** 8.83 mm
- **Median (P50) rainfall benchmark:** 5.26 mm
- **Upper percentile (P90) benchmark:** 20.19 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
