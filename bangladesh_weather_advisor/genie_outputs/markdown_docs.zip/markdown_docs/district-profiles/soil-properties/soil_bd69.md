# Soil Profile: Meherpur District

**Location:** Meherpur (BD69)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.56
- **Clay content:** 37.50%
- **Sand content:** 22.60%
- **Silt content:** 40.40%
- **Soil organic carbon:** 9.99 g/kg
- **CEC:** 21.20 cmol/kg
- **Nitrogen:** 0.99 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
