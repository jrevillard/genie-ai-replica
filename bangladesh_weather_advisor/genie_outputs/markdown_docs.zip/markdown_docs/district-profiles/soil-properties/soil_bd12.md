# Soil Profile: Bogura District

**Location:** Bogura (BD12)

## Soil Characteristics
- **Soil region:** Barind_Tract
- **Soil pH:** 5.92
- **Clay content:** 45.20%
- **Sand content:** 17.40%
- **Silt content:** 37.40%
- **Soil organic carbon:** 7.34 g/kg
- **CEC:** 20.30 cmol/kg
- **Nitrogen:** 0.76 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
