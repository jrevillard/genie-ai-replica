"""
Pengumpul data cuaca dari dua sumber gratis:
1. Open-Meteo API — gratis, tanpa API key, sangat lengkap
2. OpenWeatherMap — gratis tier 1000 calls/day (fallback)

Open-Meteo diprioritaskan karena tidak butuh API key.
"""

import asyncio
from datetime import datetime
from typing import Dict, Optional
import httpx
from loguru import logger

from config import OPENWEATHER_API_KEY, BANGLADESH_ZONES
from data.storage.database import AsyncSessionLocal, WeatherReading


# ─────────────────────────────────────────────
# Open-Meteo (GRATIS, tanpa API key)
# ─────────────────────────────────────────────

OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

async def fetch_openmeteo(lat: float, lon: float) -> Optional[Dict]:
    """
    Ambil data cuaca dari Open-Meteo.
    Mengembalikan data current + hourly forecast 24 jam.
    """
    params = {
        "latitude": lat,
        "longitude": lon,
        "current": [
            "temperature_2m", "relative_humidity_2m", "surface_pressure",
            "wind_speed_10m", "wind_direction_10m", "precipitation",
            "cloud_cover", "visibility", "weather_code"
        ],
        "hourly": [
            "precipitation", "temperature_2m", "wind_speed_10m",
            "relative_humidity_2m"
        ],
        "forecast_days": 2,
        "timezone": "Asia/Dhaka",
        "wind_speed_unit": "kmh",
    }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(OPEN_METEO_URL, params=params)
            resp.raise_for_status()
            data = resp.json()

        current = data.get("current", {})
        hourly  = data.get("hourly", {})

        # Hitung curah hujan 6 jam terakhir dari data hourly
        rain_6h = 0.0
        if "precipitation" in hourly and hourly["precipitation"]:
            rain_6h = sum(hourly["precipitation"][:6])

        return {
            "temperature":  current.get("temperature_2m"),
            "humidity":     current.get("relative_humidity_2m"),
            "pressure":     current.get("surface_pressure"),
            "wind_speed":   current.get("wind_speed_10m"),
            "wind_dir":     current.get("wind_direction_10m"),
            "rainfall_1h":  current.get("precipitation", 0),
            "rainfall_6h":  rain_6h,
            "cloud_cover":  current.get("cloud_cover"),
            "visibility":   current.get("visibility"),
            "weather_desc": _wmo_to_desc(current.get("weather_code", 0)),
            "source":       "open-meteo",
            # Simpan hourly untuk forecast
            "hourly_precip": hourly.get("precipitation", []),
            "hourly_temp":   hourly.get("temperature_2m", []),
            "hourly_wind":   hourly.get("wind_speed_10m", []),
            "hourly_times":  hourly.get("time", []),
        }

    except Exception as e:
        logger.warning(f"Open-Meteo error ({lat},{lon}): {e}")
        return None


def _wmo_to_desc(code: int) -> str:
    """Konversi WMO weather code ke deskripsi teks."""
    wmo_map = {
        0: "Cerah", 1: "Sebagian berawan", 2: "Berawan", 3: "Mendung",
        45: "Berkabut", 48: "Kabut beku",
        51: "Gerimis ringan", 53: "Gerimis sedang", 55: "Gerimis lebat",
        61: "Hujan ringan", 63: "Hujan sedang", 65: "Hujan lebat",
        71: "Salju ringan", 73: "Salju sedang", 75: "Salju lebat",
        80: "Hujan lokal ringan", 81: "Hujan lokal sedang", 82: "Hujan lokal lebat",
        95: "Badai petir", 96: "Badai petir dengan hujan es",
        99: "Badai petir berat",
    }
    return wmo_map.get(code, f"Kode cuaca {code}")


# ─────────────────────────────────────────────
# OpenWeatherMap (fallback, butuh API key)
# ─────────────────────────────────────────────

OWM_URL = "https://api.openweathermap.org/data/2.5/weather"

async def fetch_openweathermap(lat: float, lon: float) -> Optional[Dict]:
    """Fallback ke OpenWeatherMap jika Open-Meteo gagal."""
    if not OPENWEATHER_API_KEY:
        return None

    params = {
        "lat": lat, "lon": lon,
        "appid": OPENWEATHER_API_KEY,
        "units": "metric",
        "lang": "id",
    }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(OWM_URL, params=params)
            resp.raise_for_status()
            d = resp.json()

        rain = d.get("rain", {})
        return {
            "temperature":  d["main"]["temp"],
            "humidity":     d["main"]["humidity"],
            "pressure":     d["main"]["pressure"],
            "wind_speed":   d["wind"]["speed"] * 3.6,  # m/s → km/h
            "wind_dir":     d["wind"].get("deg", 0),
            "rainfall_1h":  rain.get("1h", 0),
            "rainfall_6h":  rain.get("3h", 0) * 2,    # estimasi 6h dari 3h
            "cloud_cover":  d["clouds"]["all"],
            "visibility":   d.get("visibility", 10000),
            "weather_desc": d["weather"][0]["description"],
            "source":       "openweathermap",
        }

    except Exception as e:
        logger.warning(f"OpenWeatherMap error ({lat},{lon}): {e}")
        return None


# ─────────────────────────────────────────────
# Collector Utama
# ─────────────────────────────────────────────

async def collect_weather_for_zone(zone_id: str) -> bool:
    """
    Kumpulkan data cuaca untuk satu zona dan simpan ke database.
    Coba Open-Meteo dulu, fallback ke OpenWeatherMap.
    """
    from config import BANGLADESH_ZONES
    zone = BANGLADESH_ZONES.get(zone_id)
    if not zone:
        logger.error(f"Zone {zone_id} tidak ditemukan")
        return False

    # Coba Open-Meteo dulu
    data = await fetch_openmeteo(zone.lat, zone.lon)

    # Fallback ke OpenWeatherMap
    if data is None:
        data = await fetch_openweathermap(zone.lat, zone.lon)

    if data is None:
        logger.error(f"Gagal mengambil data cuaca untuk zona {zone_id}")
        return False

    # Simpan ke database
    async with AsyncSessionLocal() as db:
        reading = WeatherReading(
            zone_id     = zone_id,
            timestamp   = datetime.utcnow(),
            temperature = data.get("temperature"),
            humidity    = data.get("humidity"),
            pressure    = data.get("pressure"),
            wind_speed  = data.get("wind_speed"),
            wind_dir    = data.get("wind_dir"),
            rainfall_1h = data.get("rainfall_1h", 0),
            rainfall_6h = data.get("rainfall_6h", 0),
            cloud_cover = data.get("cloud_cover"),
            visibility  = data.get("visibility"),
            weather_desc= data.get("weather_desc"),
            source      = data.get("source"),
        )
        db.add(reading)
        await db.commit()

    logger.debug(f"✅ Cuaca {zone_id}: {data.get('temperature')}°C, "
                 f"hujan {data.get('rainfall_1h')}mm/h, angin {data.get('wind_speed')}km/h")
    return True


async def collect_all_zones():
    """Kumpulkan data cuaca untuk semua zona secara paralel."""
    from config import BANGLADESH_ZONES
    logger.info(f"🌤️  Mengumpulkan data cuaca untuk {len(BANGLADESH_ZONES)} zona...")

    tasks = [collect_weather_for_zone(zone_id) for zone_id in BANGLADESH_ZONES]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    success = sum(1 for r in results if r is True)
    logger.info(f"✅ Cuaca terkumpul: {success}/{len(BANGLADESH_ZONES)} zona berhasil")
    return success
