# Crop Distribution: Bhola District

**Location:** Bhola (BD09)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 92169.80 | 3.50 | Kharif-2 (Jul-Dec) |
| rice_boro | 76315.20 | 4.85 | Rabi (Dec-May) |
| rice_aus | 21573.80 | 3.10 | Kharif-1 (Mar-Aug) |
| vegetables | 7270.20 | 12.06 | Rabi (Oct-Apr) |
| pulses | 5507.90 | 1.21 | Rabi (Oct-Mar) |
| oilseeds | 4721.90 | 1.09 | Rabi (Oct-Mar) |
| jute | 3709.60 | 2.68 | Kharif-1 (Mar-Aug) |
| spices | 3546.50 | 3.90 | Rabi/Kharif |
| potato | 1914.70 | 19.38 | Rabi (Nov-Mar) |
| sugarcane | 1586.90 | 42.90 | Perennial |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
