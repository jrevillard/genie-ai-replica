# Soil Profile: Kishoreganj District

**Location:** Kishoreganj (BD48)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 5.95
- **Clay content:** 31.30%
- **Sand content:** 29.20%
- **Silt content:** 40.30%
- **Soil organic carbon:** 11.45 g/kg
- **CEC:** 18.50 cmol/kg
- **Nitrogen:** 1.23 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
