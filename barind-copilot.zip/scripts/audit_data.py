"""Audit akurasi semua data yang ditampilkan di dashboard."""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import httpx

ZONES_TO_CHECK = ["SYL-01", "DHA-01", "CTG-02", "RAN-02"]

async def main():
    async with httpx.AsyncClient(timeout=15) as c:
        for zone_id in ZONES_TO_CHECK:
            r = await c.get(f"http://localhost:8000/api/zone/{zone_id}")
            d = r.json()
            w = d.get("weather", {})
            rivers = d.get("rivers", [])
            fc = d.get("forecasts", {})

            print(f"\n{'='*55}")
            print(f"ZONE: {d['name_en']} ({zone_id})")
            print(f"{'='*55}")

            # Weather
            print(f"\n[WEATHER] source=OpenWeatherMap+Open-Meteo (REAL)")
            print(f"  Temp     : {w.get('temperature')} °C")
            print(f"  Humidity : {w.get('humidity')} %")
            print(f"  Pressure : {w.get('pressure')} hPa")
            print(f"  Wind     : {w.get('wind_speed')} km/h")
            print(f"  Rain 1h  : {w.get('rainfall_1h')} mm")
            print(f"  Rain 6h  : {w.get('rainfall_6h')} mm")
            print(f"  Desc     : {w.get('description')}")
            print(f"  Updated  : {w.get('timestamp')}")

            # Rivers
            print(f"\n[RIVERS]")
            for rv in rivers:
                sid = rv.get("station_id", "?")
                level = rv.get("water_level_m")
                danger = rv.get("danger_level_m")
                pct = rv.get("level_pct", 0)
                chg = rv.get("change_6h_m")
                print(f"  {sid}: {level}m / {danger}m ({pct:.0%}) chg={chg}m")

            # Forecasts
            print(f"\n[FORECASTS]")
            for h, fcd in fc.items():
                rain = fcd.get("rainfall_mm")
                prob = fcd.get("flood_prob")
                conf = fcd.get("confidence")
                print(f"  {h}: rain={rain}mm  flood_prob={prob}  conf={conf}")

            # Alert
            alert = d.get("alert", {})
            print(f"\n[ALERT] level={alert.get('level')}  risk={alert.get('risk_score')}")

asyncio.run(main())
