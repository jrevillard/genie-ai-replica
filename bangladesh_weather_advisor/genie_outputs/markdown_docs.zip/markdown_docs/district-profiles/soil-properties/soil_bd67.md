# Soil Profile: Munshiganj District

**Location:** Munshiganj (BD67)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.67
- **Clay content:** 30.20%
- **Sand content:** 28.80%
- **Silt content:** 40.30%
- **Soil organic carbon:** 10.31 g/kg
- **CEC:** 15.70 cmol/kg
- **Nitrogen:** 1.04 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
