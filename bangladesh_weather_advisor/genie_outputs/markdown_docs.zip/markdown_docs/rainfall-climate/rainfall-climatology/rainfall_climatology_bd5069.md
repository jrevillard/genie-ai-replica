# Rainfall Climatology: District BD5069

## Climatology Summary
- **Mean daily climatological rainfall:** 4.41 mm
- **Median (P50) rainfall benchmark:** 2.57 mm
- **Upper percentile (P90) benchmark:** 10.27 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
