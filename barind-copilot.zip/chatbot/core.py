"""
Core chatbot engine — menangani semua percakapan dari berbagai platform.
Platform-agnostic: WhatsApp, Telegram, dan Web menggunakan engine yang sama.

AI Pipeline:
1. Rule-based intent classifier (cepat, deterministik) — untuk command eksplisit
2. DeepSeek AI (jika tersedia) — untuk pertanyaan bebas & bahasa natural
3. Fallback rule-based response — jika DeepSeek tidak tersedia/timeout
"""

import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from loguru import logger

from config import BANGLADESH_ZONES, AlertLevel
from chatbot.nlp.intent_classifier import IntentClassifier, Intent
from chatbot.nlp.genie_ai_client import genie_ai_client

from notifications.templates.messages import (
    format_chatbot_status_response,
    format_evacuation_response,
    format_forecast_response,
    format_welcome_message,
    format_registration_success,
    format_field_report_ack,
    format_escalation_message,
    resolve_lang,
    detect_language,
    t,
)
from data.storage.database import (
    AsyncSessionLocal, ChatSession, ChatMessage, RegisteredUser,
    FieldReport, get_latest_weather, get_active_alert
)
from sqlalchemy.future import select


class ChatbotEngine:
    """
    Engine percakapan utama.
    Mengelola sesi, memproses intent, dan menghasilkan respons.
    """

    def __init__(self):
        self.classifier = IntentClassifier()
        # Cache sesi aktif (session_id → zone_id)
        self._session_cache: Dict[str, Dict] = {}

    async def process_message(
        self,
        user_id: str,
        message: str,
        platform: str = "web",
        location_lat: Optional[float] = None,
        location_lon: Optional[float] = None,
        lang: str = "auto",
    ) -> Tuple[str, bool]:
        """
        Process incoming message and generate response.
        Pipeline:
          1. Escalation check (korban/darurat)
          2. Resolve language (auto-detect)
          3. Extract location from message if any
          4. Explicit commands (INFO, FORECAST, dll) → rule-based (cepat)
          5. Everything else → Groq AI (natural conversation)
          6. Fallback rule-based jika Groq gagal
        """
        actual_lang = resolve_lang(lang, message)

        # Get/create session
        session = await self._get_or_create_session(user_id, platform)
        session_id = session["session_id"]
        zone_id = session.get("zone_id")

        # Save user message
        await self._save_message(session_id, "user", message)

        # ── 1. Escalation check ──
        if self.classifier.needs_escalation(message):
            response = format_escalation_message(lang=actual_lang)
            await self._save_message(session_id, "assistant", response)
            await self._log_field_report(user_id, zone_id, message, needs_escalation=True)
            return response, True

        # ── 2. Classify intent ──
        intent = self.classifier.classify(message)
        logger.debug(
            f"💬 [{platform}] {user_id}: '{message[:50]}' "
            f"→ intent={intent.name} ({intent.confidence:.2f}) lang={actual_lang}"
        )

        # ── 3. Update zone from GPS ──
        if location_lat and location_lon:
            zone_id = self._find_nearest_zone(location_lat, location_lon)
            await self._update_session_zone(session_id, zone_id)
            session["zone_id"] = zone_id

        # ── 4. Extract zone from message text ──
        extracted_zone = intent.extracted_location or self.classifier._extract_location(message.lower())
        if extracted_zone:
            if not zone_id or extracted_zone != zone_id:
                zone_id = extracted_zone
                await self._update_session_zone(session_id, zone_id)
                session["zone_id"] = zone_id
            # If user just typed a district name → show status
            if intent.name == "unknown":
                intent.name = "status_query"

        # ── 5. Explicit commands → rule-based (always fast, no AI needed) ──
        EXPLICIT_COMMANDS = {
            "status_query", "forecast_query", "river_query",
            "evacuation_query", "register", "unregister",
        }
        if intent.name in EXPLICIT_COMMANDS and intent.confidence >= 0.8:
            response = await self._generate_response(intent, zone_id, user_id, message, actual_lang)
            await self._save_message(session_id, "assistant", response)
            return response, False

        # ── 6. Everything else → Genie AI (primary) or Groq (fallback) ──
        if genie_ai_client.available or groq_client.available:
            context_data = await self._build_context_data(zone_id) if zone_id else {}
            history = await self._get_conversation_history(session_id)

            # Try Genie AI first (Llama 3.1 on GPU server)
            ai_response = None
            if genie_ai_client.available:
                ai_response = await genie_ai_client.generate_response(
                    user_message=message,
                    conversation_history=history,
                    context_data=context_data,
                    lang=actual_lang,
                    zone_id=zone_id,
                )

            # Fallback to Groq if Genie AI fails
            if False:
                ai_response = await groq_client.generate_response(
                    user_message=message,
                    conversation_history=history,
                    context_data=context_data,
                    lang=actual_lang,
                    zone_id=zone_id,
                )

            if ai_response:
                new_zone = self.classifier._extract_location(ai_response.lower())
                if new_zone and not zone_id:
                    zone_id = new_zone
                    await self._update_session_zone(session_id, zone_id)
                    session["zone_id"] = zone_id
                await self._save_message(session_id, "assistant", ai_response)
                return ai_response, False

        # ── 7. Fallback rule-based ──
        response = await self._generate_response(intent, zone_id, user_id, message, actual_lang)
        await self._save_message(session_id, "assistant", response)
        return response, False

    async def _generate_response(
        self,
        intent: Intent,
        zone_id: Optional[str],
        user_id: str,
        original_message: str,
        lang: str = "en",
    ) -> str:
        """Generate response based on intent, zone, and language."""

        # If no zone yet, ask for location
        if not zone_id and intent.name not in ["greeting", "help_query", "register"]:
            return t("ask_location", lang)

        zone = BANGLADESH_ZONES.get(zone_id) if zone_id else None

        if intent.name == "greeting":
            return format_welcome_message(lang=lang)

        elif intent.name == "status_query":
            return await self._handle_status_query(zone_id, zone, lang)

        elif intent.name == "forecast_query":
            return await self._handle_forecast_query(zone_id, zone, lang)

        elif intent.name == "river_query":
            return await self._handle_river_query(zone_id, zone, lang)

        elif intent.name == "evacuation_query":
            if zone:
                return format_evacuation_response(zone_id, zone.name_en, zone.name_bn, lang=lang)
            return format_evacuation_response("", "Your area", "আপনার এলাকা", lang=lang)

        elif intent.name == "help_query":
            from config import EMERGENCY_CONTACTS, EVACUATION_CENTERS
            emergency = t("emergency", lang)
            centers_info = ""
            if zone_id and zone_id in EVACUATION_CENTERS:
                centers = EVACUATION_CENTERS[zone_id]
                centers_info = "\n\n🏠 Nearest shelters:\n" if lang == "en" else "\n\n🏠 নিকটতম আশ্রয়কেন্দ্র:\n"
                for c in centers[:2]:
                    name = c["name"] if lang == "en" else c["name_bn"]
                    centers_info += f"• {name} (cap: {c['capacity']:,})\n"
            return t("help_response", lang, emergency=emergency, centers=centers_info)

        elif intent.name == "register":
            return await self._handle_registration(user_id, zone_id, zone, lang)

        elif intent.name == "unregister":
            return await self._handle_unregistration(user_id, lang)

        elif intent.name == "field_report":
            await self._log_field_report(
                user_id, zone_id, original_message,
                depth_cm=intent.extracted_depth
            )
            return format_field_report_ack(lang=lang)

        else:
            return t("unknown_intent", lang)

    async def _handle_status_query(self, zone_id: str, zone, lang: str = "en") -> str:
        """Handle current status query."""
        if not zone:
            return t("no_data", lang)

        async with AsyncSessionLocal() as db:
            weather = await get_latest_weather(zone_id, db)
            alert = await get_active_alert(zone_id, db)

        # Ambil forecast terbaru dari cache/database
        forecast_6h = {"flood_prob": 0.1, "rainfall_mm": 5}
        forecast_24h = {"flood_prob": 0.15, "rainfall_mm": 10}

        try:
            from sqlalchemy.future import select
            from data.storage.database import ForecastRecord
            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    select(ForecastRecord)
                    .where(
                        ForecastRecord.zone_id == zone_id,
                        ForecastRecord.horizon_hours == 6
                    )
                    .order_by(ForecastRecord.created_at.desc())
                    .limit(1)
                )
                fc6 = result.scalar_one_or_none()
                if fc6:
                    forecast_6h = {
                        "flood_prob": fc6.flood_probability or 0,
                        "rainfall_mm": fc6.predicted_rainfall_mm or 0,
                    }

                result = await db.execute(
                    select(ForecastRecord)
                    .where(
                        ForecastRecord.zone_id == zone_id,
                        ForecastRecord.horizon_hours == 24
                    )
                    .order_by(ForecastRecord.created_at.desc())
                    .limit(1)
                )
                fc24 = result.scalar_one_or_none()
                if fc24:
                    forecast_24h = {
                        "flood_prob": fc24.flood_probability or 0,
                        "rainfall_mm": fc24.predicted_rainfall_mm or 0,
                    }
        except Exception:
            pass

        alert_level = alert.level if alert else AlertLevel.GREEN
        risk_score = alert.risk_score if alert else 0.1
        reasons_bn = []
        if alert and alert.reason:
            reasons_bn = [r.strip() for r in alert.reason.split(";") if r.strip()][:3]

        return format_chatbot_status_response(
            zone_name=zone.name_en,
            zone_name_bn=zone.name_bn,
            alert_level=alert_level,
            risk_score=risk_score,
            reasons=reasons_bn,       # English reasons (same list, already in English from risk engine)
            reasons_bn=reasons_bn,
            rainfall_mm=weather.rainfall_6h if weather else 0,
            wind_kmh=weather.wind_speed if weather else 0,
            river_level_pct=0.6,
            flood_prob_6h=forecast_6h.get("flood_prob", 0),
            flood_prob_24h=forecast_24h.get("flood_prob", 0),
            weather_desc=weather.weather_desc if weather else "No data",
            lang=lang,
        )

    async def _handle_forecast_query(self, zone_id: str, zone, lang: str = "en") -> str:
        """Handle forecast query."""
        if not zone:
            return t("no_data", lang)

        try:
            from data.storage.database import ForecastRecord
            forecasts = {}
            async with AsyncSessionLocal() as db:
                for h in [6, 12, 24]:
                    result = await db.execute(
                        select(ForecastRecord)
                        .where(
                            ForecastRecord.zone_id == zone_id,
                            ForecastRecord.horizon_hours == h
                        )
                        .order_by(ForecastRecord.created_at.desc())
                        .limit(1)
                    )
                    fc = result.scalar_one_or_none()
                    forecasts[h] = {
                        "flood_prob": fc.flood_probability if fc else 0.1,
                        "rainfall_mm": fc.predicted_rainfall_mm if fc else 5,
                    }

            return format_forecast_response(
                zone_name=zone.name_en,
                zone_name_bn=zone.name_bn,
                forecast_6h=forecasts[6],
                forecast_12h=forecasts[12],
                forecast_24h=forecasts[24],
                lang=lang,
            )
        except Exception as e:
            logger.error(f"Error forecast query: {e}")
            return t("connection_error", lang)

    async def _handle_river_query(self, zone_id: str, zone, lang: str = "en") -> str:
        """Handle river level query."""
        if not zone:
            return t("no_data", lang)

        from data.storage.database import RiverReading
        from config import RIVER_STATIONS

        title = f"🌊 *{zone.name_en if lang == 'en' else zone.name_bn} — River Water Levels*\n" if lang == "en" \
            else f"🌊 *{zone.name_bn} — নদীর পানির স্তর*\n"
        lines = [title]

        async with AsyncSessionLocal() as db:
            for station_id in zone.river_stations:
                result = await db.execute(
                    select(RiverReading)
                    .where(RiverReading.station_id == station_id)
                    .order_by(RiverReading.timestamp.desc())
                    .limit(1)
                )
                reading = result.scalar_one_or_none()
                station_info = RIVER_STATIONS.get(station_id, {})
                name = station_info.get("name", station_id)

                if reading:
                    danger = reading.danger_level_m or 10
                    pct = reading.water_level_m / danger
                    change = reading.change_6h_m or 0
                    trend = "↑" if change > 0.1 else ("↓" if change < -0.1 else "→")

                    if pct >= 1.0:
                        status = "⛔ Above danger level" if lang == "en" else "⛔ বিপদসীমার উপরে"
                    elif pct >= 0.85:
                        status = "🔴 Near danger level" if lang == "en" else "🔴 বিপদসীমার কাছে"
                    elif pct >= 0.70:
                        status = "🟡 Elevated" if lang == "en" else "🟡 সতর্ক স্তরে"
                    else:
                        status = "🟢 Normal" if lang == "en" else "🟢 স্বাভাবিক"

                    lines.append(
                        f"*{name}*\n"
                        f"  Level: {reading.water_level_m:.2f}m / {danger:.1f}m ({pct:.0%}) {trend}\n"
                        f"  Status: {status}\n"
                        f"  6h change: {change:+.2f}m\n"
                    )
                else:
                    lines.append(f"*{name}*: No data available\n" if lang == "en" else f"*{name}*: তথ্য পাওয়া যায়নি\n")

        footer = "\n_Data updated every 15 minutes_" if lang == "en" else "\n_তথ্য প্রতি ১৫ মিনিটে আপডেট হয়_"
        lines.append(footer)
        return "\n".join(lines)

    async def _handle_registration(self, user_id: str, zone_id: Optional[str], zone, lang: str = "en") -> str:
        """Register user for automatic notifications."""
        if not zone_id or not zone:
            return t("register_need_location", lang)

        async with AsyncSessionLocal() as db:
            # Cek apakah sudah terdaftar
            result = await db.execute(
                select(RegisteredUser).where(RegisteredUser.phone == user_id)
            )
            existing = result.scalar_one_or_none()

            if existing:
                existing.zone_id = zone_id
                existing.is_active = True
            else:
                new_user = RegisteredUser(
                    phone=user_id,
                    zone_id=zone_id,
                    district=zone.district,
                    language="bn",
                    channel="both",
                    is_active=True,
                )
                db.add(new_user)
            await db.commit()

        return format_registration_success(zone.name_en, zone.name_bn, lang=lang)

    async def _handle_unregistration(self, user_id: str, lang: str = "en") -> str:
        """Cancel user registration."""
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(RegisteredUser).where(RegisteredUser.phone == user_id)
            )
            user = result.scalar_one_or_none()
            if user:
                user.is_active = False
                await db.commit()
                return t("unregister_success", lang)
            else:
                return t("not_registered", lang)

    async def _log_field_report(self, user_id: str, zone_id: Optional[str],
                                  message: str, depth_cm: Optional[float] = None,
                                  needs_escalation: bool = False):
        """Simpan laporan lapangan ke database."""
        async with AsyncSessionLocal() as db:
            report = FieldReport(
                zone_id=zone_id or "UNKNOWN",
                reporter_phone=user_id,
                reported_at=datetime.utcnow(),
                description=message,
                flood_depth_cm=depth_cm,
                has_casualties=needs_escalation,
            )
            db.add(report)
            await db.commit()

    def _find_nearest_zone(self, lat: float, lon: float) -> str:
        """Temukan zona terdekat berdasarkan koordinat GPS."""
        import math
        min_dist = float("inf")
        nearest = "DHA-01"  # default Dhaka

        for zone_id, zone in BANGLADESH_ZONES.items():
            dist = math.sqrt((zone.lat - lat) ** 2 + (zone.lon - lon) ** 2)
            if dist < min_dist:
                min_dist = dist
                nearest = zone_id

        return nearest

    async def _get_or_create_session(self, user_id: str, platform: str) -> Dict:
        """Dapatkan atau buat sesi percakapan."""
        # Cek cache dulu
        cache_key = f"{platform}:{user_id}"
        if cache_key in self._session_cache:
            cached = self._session_cache[cache_key]
            # Sesi valid jika aktif dalam 2 jam terakhir
            if (datetime.utcnow() - cached["last_active"]).seconds < 7200:
                cached["last_active"] = datetime.utcnow()
                return cached

        # Cek database
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(ChatSession)
                .where(
                    ChatSession.user_id == user_id,
                    ChatSession.platform == platform,
                    ChatSession.last_active >= datetime.utcnow() - timedelta(hours=2)
                )
                .order_by(ChatSession.last_active.desc())
                .limit(1)
            )
            session_db = result.scalar_one_or_none()

            if session_db:
                session_db.last_active = datetime.utcnow()
                await db.commit()
                session_data = {
                    "session_id": session_db.session_id,
                    "zone_id": session_db.zone_id,
                    "last_active": datetime.utcnow(),
                }
            else:
                # Buat sesi baru
                session_id = str(uuid.uuid4())
                new_session = ChatSession(
                    session_id=session_id,
                    user_id=user_id,
                    platform=platform,
                    started_at=datetime.utcnow(),
                    last_active=datetime.utcnow(),
                )
                db.add(new_session)
                await db.commit()
                session_data = {
                    "session_id": session_id,
                    "zone_id": None,
                    "last_active": datetime.utcnow(),
                }

        self._session_cache[cache_key] = session_data
        return session_data

    async def _update_session_zone(self, session_id: str, zone_id: str):
        """Update zona dalam sesi."""
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(ChatSession).where(ChatSession.session_id == session_id)
            )
            session = result.scalar_one_or_none()
            if session:
                session.zone_id = zone_id
                await db.commit()

    async def _save_message(self, session_id: str, role: str, content: str):
        """Simpan pesan ke database."""
        async with AsyncSessionLocal() as db:
            msg = ChatMessage(
                session_id=session_id,
                timestamp=datetime.utcnow(),
                role=role,
                content=content,
            )
            db.add(msg)
            await db.commit()

    async def _get_conversation_history(self, session_id: str, limit: int = 8) -> list:
        """Ambil riwayat percakapan untuk dikirim ke DeepSeek."""
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(ChatMessage)
                .where(ChatMessage.session_id == session_id)
                .order_by(ChatMessage.timestamp.desc())
                .limit(limit)
            )
            messages = result.scalars().all()

        # Balik urutan (terlama dulu) dan format untuk API
        return [
            {"role": m.role, "content": m.content}
            for m in reversed(messages)
        ]

    async def _build_context_data(self, zone_id: str) -> dict:
        """
        Kumpulkan semua data real-time zona untuk dikirim ke DeepSeek.
        Ini yang membuat AI bisa menjawab dengan data aktual.
        """
        from config import BANGLADESH_ZONES, RIVER_STATIONS
        from data.storage.database import RiverReading, ForecastRecord

        zone = BANGLADESH_ZONES.get(zone_id)
        if not zone:
            return {}

        context = {
            "zone_id":      zone_id,
            "zone_name_en": zone.name_en,
            "zone_name_bn": zone.name_bn,
            "district":     zone.district,
            "division":     zone.division,
        }

        async with AsyncSessionLocal() as db:
            # Alert & risk
            alert = await get_active_alert(zone_id, db)
            context["alert_level"] = alert.level if alert else "green"
            context["risk_score"]  = alert.risk_score if alert else 0.0
            context["reasons"]     = [r.strip() for r in (alert.reason or "").split(";") if r.strip()] if alert else []

            # Weather
            weather = await get_latest_weather(zone_id, db)
            if weather:
                context["weather"] = {
                    "temperature":  weather.temperature,
                    "humidity":     weather.humidity,
                    "pressure":     weather.pressure,
                    "wind_speed":   weather.wind_speed,
                    "rainfall_1h":  weather.rainfall_1h,
                    "rainfall_6h":  weather.rainfall_6h,
                    "weather_desc": weather.weather_desc,
                    "timestamp":    weather.timestamp.strftime("%Y-%m-%d %H:%M UTC"),
                }

            # River data
            river_list = []
            for station_id in zone.river_stations:
                result = await db.execute(
                    select(RiverReading)
                    .where(RiverReading.station_id == station_id)
                    .order_by(RiverReading.timestamp.desc())
                    .limit(1)
                )
                r = result.scalar_one_or_none()
                if r:
                    station_info = RIVER_STATIONS.get(station_id, {})
                    river_list.append({
                        "station_id":    station_id,
                        "name":          station_info.get("name", station_id),
                        "water_level_m": r.water_level_m,
                        "danger_level_m": r.danger_level_m,
                        "level_pct":     r.water_level_m / (r.danger_level_m or 10),
                        "change_6h_m":   r.change_6h_m,
                    })
            context["river_data"] = river_list

            # Forecast
            forecast_horizons = {}
            for h in [6, 12, 24]:
                result = await db.execute(
                    select(ForecastRecord)
                    .where(ForecastRecord.zone_id == zone_id,
                           ForecastRecord.horizon_hours == h)
                    .order_by(ForecastRecord.created_at.desc())
                    .limit(1)
                )
                fc = result.scalar_one_or_none()
                if fc:
                    forecast_horizons[h] = {
                        "rainfall_mm": fc.predicted_rainfall_mm or 0,
                        "flood_prob":  fc.flood_probability or 0,
                    }
            if forecast_horizons:
                context["forecast"] = {"horizons": forecast_horizons}

        return context
