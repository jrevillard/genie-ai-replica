# ERA5 Climatology: District BD1004

## Baseline Summary
- **Mean temperature climatology:** 25.99 °C
- **Mean evaporation climatology:** -3.06 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
