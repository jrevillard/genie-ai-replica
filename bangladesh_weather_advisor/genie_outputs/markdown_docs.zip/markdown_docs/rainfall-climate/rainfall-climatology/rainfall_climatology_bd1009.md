# Rainfall Climatology: District BD1009

## Climatology Summary
- **Mean daily climatological rainfall:** 7.56 mm
- **Median (P50) rainfall benchmark:** 4.76 mm
- **Upper percentile (P90) benchmark:** 16.96 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
