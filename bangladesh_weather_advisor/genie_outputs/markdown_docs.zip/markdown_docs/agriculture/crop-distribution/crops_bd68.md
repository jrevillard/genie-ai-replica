# Crop Distribution: Narayanganj District

**Location:** Narayanganj (BD68)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 81653.90 | 3.53 | Kharif-2 (Jul-Dec) |
| rice_boro | 72655.30 | 4.93 | Rabi (Dec-May) |
| rice_aus | 16867.70 | 3.09 | Kharif-1 (Mar-Aug) |
| jute | 14539.80 | 2.17 | Kharif-1 (Mar-Aug) |
| maize | 8450.20 | 7.77 | Rabi (Oct-Apr) |
| vegetables | 8308.50 | 11.99 | Rabi (Oct-Apr) |
| potato | 6219.10 | 19.39 | Rabi (Nov-Mar) |
| oilseeds | 6033.70 | 0.84 | Rabi (Oct-Mar) |
| pulses | 4850.00 | 0.94 | Rabi (Oct-Mar) |
| wheat | 4581.90 | 2.82 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
