# Soil Profile: Chuadanga District

**Location:** Chuadanga (BD18)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.28
- **Clay content:** 36.60%
- **Sand content:** 22.70%
- **Silt content:** 40.40%
- **Soil organic carbon:** 9.84 g/kg
- **CEC:** 21.70 cmol/kg
- **Nitrogen:** 0.98 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
