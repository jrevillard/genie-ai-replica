# ERA5 Climatology: District BD5552

## Baseline Summary
- **Mean temperature climatology:** 24.46 °C
- **Mean evaporation climatology:** -2.64 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
