# Rainfall Climatology: District BD5585

## Climatology Summary
- **Mean daily climatological rainfall:** 6.11 mm
- **Median (P50) rainfall benchmark:** 3.56 mm
- **Upper percentile (P90) benchmark:** 14.18 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
