# Soil Profile: Patuakhali District

**Location:** Patuakhali (BD78)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.66
- **Clay content:** 42.60%
- **Sand content:** 14.40%
- **Silt content:** 42.70%
- **Soil organic carbon:** 13.41 g/kg
- **CEC:** 24.00 cmol/kg
- **Nitrogen:** 1.39 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
