# ERA5 Climatology: District BD2015

## Baseline Summary
- **Mean temperature climatology:** 25.52 °C
- **Mean evaporation climatology:** -3.17 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
