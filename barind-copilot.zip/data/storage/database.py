"""
Database layer — SQLAlchemy async dengan SQLite (dev) / PostgreSQL (prod).
Menyimpan semua data historis, alert, dan registrasi pengguna.
"""

from datetime import datetime
from typing import Optional, List
from sqlalchemy import (
    Column, String, Float, Integer, DateTime, Boolean,
    Text, ForeignKey, Index, create_engine
)
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, relationship
from sqlalchemy.future import select
from loguru import logger

from config import DATABASE_URL


class Base(DeclarativeBase):
    pass


# ─────────────────────────────────────────────
# Models
# ─────────────────────────────────────────────

class WeatherReading(Base):
    """Data cuaca dari OpenWeatherMap / Open-Meteo."""
    __tablename__ = "weather_readings"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    zone_id     = Column(String(10), nullable=False, index=True)
    timestamp   = Column(DateTime, default=datetime.utcnow, index=True)
    temperature = Column(Float)          # °C
    humidity    = Column(Float)          # %
    pressure    = Column(Float)          # hPa
    wind_speed  = Column(Float)          # km/h
    wind_dir    = Column(Float)          # derajat
    rainfall_1h = Column(Float, default=0)  # mm/jam
    rainfall_6h = Column(Float, default=0)  # mm/6jam
    cloud_cover = Column(Float)          # %
    visibility  = Column(Float)          # meter
    weather_desc= Column(String(100))
    source      = Column(String(50), default="openweather")

    __table_args__ = (
        Index("ix_weather_zone_time", "zone_id", "timestamp"),
    )


class RiverReading(Base):
    """Data level sungai dari BWDB / simulasi."""
    __tablename__ = "river_readings"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    station_id      = Column(String(50), nullable=False, index=True)
    zone_id         = Column(String(10), nullable=False, index=True)
    timestamp       = Column(DateTime, default=datetime.utcnow, index=True)
    water_level_m   = Column(Float, nullable=False)   # meter dari datum
    flow_rate_m3s   = Column(Float)                   # m³/s
    change_6h_m     = Column(Float, default=0)        # perubahan 6 jam terakhir
    danger_level_m  = Column(Float)                   # level bahaya stasiun ini
    source          = Column(String(50), default="simulated")

    __table_args__ = (
        Index("ix_river_station_time", "station_id", "timestamp"),
    )


class ForecastRecord(Base):
    """Hasil prediksi model ML."""
    __tablename__ = "forecast_records"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    zone_id         = Column(String(10), nullable=False, index=True)
    created_at      = Column(DateTime, default=datetime.utcnow)
    forecast_for    = Column(DateTime, nullable=False)   # waktu yang diprediksi
    horizon_hours   = Column(Integer)                    # 6, 12, atau 24
    predicted_rainfall_mm = Column(Float)
    predicted_river_level_m = Column(Float)
    flood_probability = Column(Float)                    # 0.0 – 1.0
    confidence      = Column(Float)                      # 0.0 – 1.0
    model_used      = Column(String(50))                 # "prophet", "lstm", "ensemble"

    __table_args__ = (
        Index("ix_forecast_zone_time", "zone_id", "forecast_for"),
    )


class AlertRecord(Base):
    """Riwayat semua peringatan yang diterbitkan."""
    __tablename__ = "alert_records"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    zone_id     = Column(String(10), nullable=False, index=True)
    issued_at   = Column(DateTime, default=datetime.utcnow, index=True)
    level       = Column(String(10), nullable=False)   # green/yellow/red
    prev_level  = Column(String(10))
    risk_score  = Column(Float)
    reason      = Column(Text)                         # penjelasan singkat
    confirmed_by= Column(String(100))                  # nama petugas BMD jika dikonfirmasi
    is_active   = Column(Boolean, default=True)
    resolved_at = Column(DateTime)

    __table_args__ = (
        Index("ix_alert_zone_time", "zone_id", "issued_at"),
    )


class RegisteredUser(Base):
    """Pengguna terdaftar untuk menerima peringatan otomatis."""
    __tablename__ = "registered_users"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    phone       = Column(String(20), unique=True, nullable=False, index=True)
    telegram_id = Column(String(50), unique=True)
    name        = Column(String(100))
    zone_id     = Column(String(10), nullable=False, index=True)
    district    = Column(String(100))
    language    = Column(String(5), default="bn")      # bn = Bengali, en = English
    channel     = Column(String(20), default="both")   # whatsapp/sms/telegram/both
    is_active   = Column(Boolean, default=True)
    registered_at = Column(DateTime, default=datetime.utcnow)
    last_alert_sent = Column(DateTime)


class ChatSession(Base):
    """Sesi percakapan chatbot."""
    __tablename__ = "chat_sessions"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    session_id  = Column(String(100), unique=True, nullable=False, index=True)
    user_id     = Column(String(50), index=True)       # phone atau telegram_id
    platform    = Column(String(20))                   # whatsapp/telegram/web
    zone_id     = Column(String(10))
    started_at  = Column(DateTime, default=datetime.utcnow)
    last_active = Column(DateTime, default=datetime.utcnow)
    messages    = relationship("ChatMessage", back_populates="session",
                               cascade="all, delete-orphan")


class ChatMessage(Base):
    """Pesan individual dalam sesi chatbot."""
    __tablename__ = "chat_messages"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    session_id  = Column(String(100), ForeignKey("chat_sessions.session_id"), index=True)
    timestamp   = Column(DateTime, default=datetime.utcnow)
    role        = Column(String(10))                   # user / assistant
    content     = Column(Text, nullable=False)
    is_escalated= Column(Boolean, default=False)
    session     = relationship("ChatSession", back_populates="messages")


class FieldReport(Base):
    """Laporan kondisi lapangan dari warga."""
    __tablename__ = "field_reports"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    zone_id     = Column(String(10), nullable=False, index=True)
    reporter_phone = Column(String(20))
    reported_at = Column(DateTime, default=datetime.utcnow, index=True)
    description = Column(Text)
    flood_depth_cm = Column(Float)                     # kedalaman banjir jika dilaporkan
    has_casualties = Column(Boolean, default=False)
    media_url   = Column(String(500))                  # URL foto/video
    is_verified = Column(Boolean, default=False)
    handled_by  = Column(String(100))


# ─────────────────────────────────────────────
# Engine & Session Factory
# ─────────────────────────────────────────────
engine = create_async_engine(DATABASE_URL, echo=False, future=True)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_db():
    """Buat semua tabel jika belum ada."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ Database initialized")


async def get_db():
    """Dependency injection untuk FastAPI."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ─────────────────────────────────────────────
# Helper Queries
# ─────────────────────────────────────────────

async def get_latest_weather(zone_id: str, db: AsyncSession) -> Optional[WeatherReading]:
    result = await db.execute(
        select(WeatherReading)
        .where(WeatherReading.zone_id == zone_id)
        .order_by(WeatherReading.timestamp.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def get_latest_river(station_id: str, db: AsyncSession) -> Optional[RiverReading]:
    result = await db.execute(
        select(RiverReading)
        .where(RiverReading.station_id == station_id)
        .order_by(RiverReading.timestamp.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def get_active_alert(zone_id: str, db: AsyncSession) -> Optional[AlertRecord]:
    result = await db.execute(
        select(AlertRecord)
        .where(AlertRecord.zone_id == zone_id, AlertRecord.is_active == True)
        .order_by(AlertRecord.issued_at.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def get_weather_history(zone_id: str, hours: int, db: AsyncSession) -> List[WeatherReading]:
    from datetime import timedelta
    cutoff = datetime.utcnow() - timedelta(hours=hours)
    result = await db.execute(
        select(WeatherReading)
        .where(WeatherReading.zone_id == zone_id, WeatherReading.timestamp >= cutoff)
        .order_by(WeatherReading.timestamp.asc())
    )
    return result.scalars().all()


async def get_river_history(station_id: str, hours: int, db: AsyncSession) -> List[RiverReading]:
    from datetime import timedelta
    cutoff = datetime.utcnow() - timedelta(hours=hours)
    result = await db.execute(
        select(RiverReading)
        .where(RiverReading.station_id == station_id, RiverReading.timestamp >= cutoff)
        .order_by(RiverReading.timestamp.asc())
    )
    return result.scalars().all()
