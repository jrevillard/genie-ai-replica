# Soil Profile: Naogaon District

**Location:** Naogaon (BD70)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 6.95
- **Clay content:** 39.70%
- **Sand content:** 22.70%
- **Silt content:** 41.40%
- **Soil organic carbon:** 9.43 g/kg
- **CEC:** 22.20 cmol/kg
- **Nitrogen:** 0.95 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
