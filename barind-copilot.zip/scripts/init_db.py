"""
Script inisialisasi database dan data awal.
Jalankan sekali sebelum memulai sistem.
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from loguru import logger
from data.storage.database import init_db, AsyncSessionLocal, RegisteredUser
from config import BANGLADESH_ZONES


async def seed_demo_users():
    """
    Tambahkan beberapa pengguna demo untuk testing.
    Nomor ini adalah nomor dummy — ganti dengan nomor nyata untuk produksi.
    """
    demo_users = [
        # Format: (phone, zone_id, name, channel)
        ("+8801711000001", "SYL-01", "Demo User Sylhet", "both"),
        ("+8801711000002", "CTG-02", "Demo User Cox's Bazar", "sms"),
        ("+8801711000003", "BAR-02", "Demo User Bhola", "both"),
        ("+8801711000004", "RAN-02", "Demo User Kurigram", "both"),
        ("+8801711000005", "DHA-01", "Demo User Dhaka", "whatsapp"),
    ]

    async with AsyncSessionLocal() as db:
        for phone, zone_id, name, channel in demo_users:
            zone = BANGLADESH_ZONES.get(zone_id)
            if not zone:
                continue

            user = RegisteredUser(
                phone=phone,
                zone_id=zone_id,
                name=name,
                district=zone.district,
                language="bn",
                channel=channel,
                is_active=True,
            )
            db.add(user)

        await db.commit()
        logger.info(f"✅ {len(demo_users)} pengguna demo ditambahkan")


async def main():
    logger.info("🔧 Inisialisasi database BFEWS...")

    # Buat semua tabel
    await init_db()

    # Tambah data demo
    await seed_demo_users()

    logger.info("✅ Database siap!")
    logger.info("")
    logger.info("Langkah selanjutnya:")
    logger.info("  1. Salin .env.example ke .env dan isi API keys")
    logger.info("  2. Jalankan: python main.py")
    logger.info("  3. Buka: http://localhost:8000")


if __name__ == "__main__":
    asyncio.run(main())
