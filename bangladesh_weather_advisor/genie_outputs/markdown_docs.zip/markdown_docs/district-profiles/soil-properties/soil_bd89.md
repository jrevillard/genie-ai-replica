# Soil Profile: Sherpur District

**Location:** Sherpur (BD89)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 6.14
- **Clay content:** 32.50%
- **Sand content:** 27.70%
- **Silt content:** 39.00%
- **Soil organic carbon:** 11.02 g/kg
- **CEC:** 17.60 cmol/kg
- **Nitrogen:** 1.17 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
