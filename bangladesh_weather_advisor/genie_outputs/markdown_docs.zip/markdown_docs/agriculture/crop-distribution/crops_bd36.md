# Crop Distribution: Gopalganj District

**Location:** Gopalganj (BD36)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 76980.70 | 4.82 | Rabi (Dec-May) |
| rice_aman | 71433.20 | 3.81 | Kharif-2 (Jul-Dec) |
| rice_aus | 13106.10 | 2.86 | Kharif-1 (Mar-Aug) |
| jute | 10676.00 | 2.45 | Kharif-1 (Mar-Aug) |
| vegetables | 8324.40 | 11.91 | Rabi (Oct-Apr) |
| maize | 7914.40 | 7.84 | Rabi (Oct-Apr) |
| potato | 6792.50 | 19.38 | Rabi (Nov-Mar) |
| pulses | 6770.10 | 1.22 | Rabi (Oct-Mar) |
| wheat | 5162.10 | 3.42 | Rabi (Nov-Mar) |
| oilseeds | 4904.50 | 1.12 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
