# Soil Profile: Gopalganj District

**Location:** Gopalganj (BD36)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.13
- **Clay content:** 36.80%
- **Sand content:** 23.00%
- **Silt content:** 38.40%
- **Soil organic carbon:** 9.92 g/kg
- **CEC:** 21.90 cmol/kg
- **Nitrogen:** 0.99 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
