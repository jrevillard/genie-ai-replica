# Rainfall Climatology: District BD2012

## Climatology Summary
- **Mean daily climatological rainfall:** 6.11 mm
- **Median (P50) rainfall benchmark:** 3.85 mm
- **Upper percentile (P90) benchmark:** 13.75 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
