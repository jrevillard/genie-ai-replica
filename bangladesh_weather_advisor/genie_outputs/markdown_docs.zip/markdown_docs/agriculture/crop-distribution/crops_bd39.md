# Crop Distribution: Jamalpur District

**Location:** Jamalpur (BD39)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 99880.80 | 3.53 | Kharif-2 (Jul-Dec) |
| rice_boro | 60463.70 | 5.76 | Rabi (Dec-May) |
| rice_aus | 14399.30 | 2.85 | Kharif-1 (Mar-Aug) |
| jute | 11462.80 | 2.42 | Kharif-1 (Mar-Aug) |
| vegetables | 7596.50 | 11.10 | Rabi (Oct-Apr) |
| pulses | 6708.60 | 1.05 | Rabi (Oct-Mar) |
| potato | 5879.80 | 18.07 | Rabi (Nov-Mar) |
| oilseeds | 5687.50 | 0.92 | Rabi (Oct-Mar) |
| maize | 5091.70 | 7.87 | Rabi (Oct-Apr) |
| spices | 3884.20 | 4.17 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
