# Rainfall Climatology: District BD3067

## Climatology Summary
- **Mean daily climatological rainfall:** 5.80 mm
- **Median (P50) rainfall benchmark:** 3.40 mm
- **Upper percentile (P90) benchmark:** 13.45 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
