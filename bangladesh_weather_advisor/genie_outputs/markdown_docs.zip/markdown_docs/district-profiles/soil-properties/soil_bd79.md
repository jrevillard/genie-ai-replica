# Soil Profile: Pirojpur District

**Location:** Pirojpur (BD79)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.67
- **Clay content:** 41.70%
- **Sand content:** 15.60%
- **Silt content:** 44.90%
- **Soil organic carbon:** 13.50 g/kg
- **CEC:** 24.30 cmol/kg
- **Nitrogen:** 1.35 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
