# Crop Distribution: Gazipur District

**Location:** Gazipur (BD33)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 73891.70 | 3.43 | Kharif-2 (Jul-Dec) |
| rice_boro | 56437.80 | 5.61 | Rabi (Dec-May) |
| rice_aus | 17464.80 | 2.59 | Kharif-1 (Mar-Aug) |
| jute | 11088.20 | 2.33 | Kharif-1 (Mar-Aug) |
| vegetables | 7895.00 | 12.83 | Rabi (Oct-Apr) |
| maize | 7876.00 | 9.19 | Rabi (Oct-Apr) |
| pulses | 6825.00 | 1.26 | Rabi (Oct-Mar) |
| potato | 5817.90 | 21.42 | Rabi (Nov-Mar) |
| oilseeds | 5033.40 | 1.04 | Rabi (Oct-Mar) |
| wheat | 4885.30 | 3.48 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
