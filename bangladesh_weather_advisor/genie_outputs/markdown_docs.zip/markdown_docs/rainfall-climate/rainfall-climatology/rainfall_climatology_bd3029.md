# Rainfall Climatology: District BD3029

## Climatology Summary
- **Mean daily climatological rainfall:** 5.08 mm
- **Median (P50) rainfall benchmark:** 3.00 mm
- **Upper percentile (P90) benchmark:** 11.65 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
