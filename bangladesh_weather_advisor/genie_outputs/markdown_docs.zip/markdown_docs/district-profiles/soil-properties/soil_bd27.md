# Soil Profile: Dhaka District

**Location:** Dhaka (BD27)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.29
- **Clay content:** 31.00%
- **Sand content:** 29.50%
- **Silt content:** 40.20%
- **Soil organic carbon:** 10.08 g/kg
- **CEC:** 16.00 cmol/kg
- **Nitrogen:** 0.95 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
