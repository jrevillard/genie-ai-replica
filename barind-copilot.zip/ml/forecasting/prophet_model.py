"""
Model Forecast menggunakan Facebook Prophet.
Prophet sangat cocok untuk data time series dengan:
- Pola musiman kuat (monsun Bangladesh)
- Missing data (sensor kadang mati)
- Trend jangka panjang

Prediksi: curah hujan dan level sungai 6, 12, 24 jam ke depan.
"""

import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from loguru import logger

try:
    from prophet import Prophet
    PROPHET_AVAILABLE = True
except ImportError:
    PROPHET_AVAILABLE = False
    logger.warning("Prophet tidak tersedia, menggunakan fallback model")

from data.storage.database import AsyncSessionLocal, WeatherReading, RiverReading, ForecastRecord
from sqlalchemy.future import select


# ─────────────────────────────────────────────
# Prophet Rainfall Forecaster
# ─────────────────────────────────────────────

class RainfallForecaster:
    """
    Prediksi curah hujan menggunakan Prophet.
    Input: riwayat curah hujan 30 hari terakhir
    Output: prediksi 6, 12, 24 jam ke depan
    """

    def __init__(self):
        self.models: Dict[str, Prophet] = {}  # cache model per zona

    def _build_model(self) -> "Prophet":
        """Buat model Prophet dengan konfigurasi untuk iklim Bangladesh."""
        model = Prophet(
            changepoint_prior_scale=0.05,    # perubahan trend lambat
            seasonality_prior_scale=10.0,    # musiman kuat
            holidays_prior_scale=10.0,
            seasonality_mode="multiplicative",  # curah hujan bersifat multiplikatif
            interval_width=0.80,
            daily_seasonality=True,
            weekly_seasonality=False,
            yearly_seasonality=True,
        )
        # Tambah musiman monsun Bangladesh (periode ~180 hari)
        model.add_seasonality(
            name="monsoon",
            period=180,
            fourier_order=5,
            prior_scale=15.0,
        )
        return model

    def _prepare_dataframe(self, readings: List[WeatherReading]) -> pd.DataFrame:
        """Konversi list WeatherReading ke DataFrame format Prophet (ds, y)."""
        if not readings:
            return pd.DataFrame(columns=["ds", "y"])

        data = []
        for r in readings:
            if r.rainfall_1h is not None:
                data.append({
                    "ds": pd.Timestamp(r.timestamp),
                    "y": max(0.0, r.rainfall_1h),  # curah hujan tidak negatif
                })

        df = pd.DataFrame(data)
        if df.empty:
            return df

        # Resample ke interval 1 jam, isi missing dengan 0
        df = df.set_index("ds").resample("1h").mean().fillna(0).reset_index()
        df.columns = ["ds", "y"]
        return df

    async def forecast(self, zone_id: str,
                       horizons: List[int] = [6, 12, 24]) -> Dict[int, Dict]:
        """
        Jalankan forecast untuk zona tertentu.
        Returns: {6: {rainfall_mm, confidence}, 12: {...}, 24: {...}}
        """
        # Ambil data historis 30 hari
        async with AsyncSessionLocal() as db:
            cutoff = datetime.utcnow() - timedelta(days=30)
            result = await db.execute(
                select(WeatherReading)
                .where(
                    WeatherReading.zone_id == zone_id,
                    WeatherReading.timestamp >= cutoff
                )
                .order_by(WeatherReading.timestamp.asc())
            )
            readings = result.scalars().all()

        df = self._prepare_dataframe(readings)

        if len(df) < 24:  # butuh minimal 24 data points
            logger.warning(f"Data tidak cukup untuk Prophet forecast zona {zone_id} "
                           f"({len(df)} points), menggunakan fallback")
            return self._fallback_forecast(zone_id, horizons)

        try:
            # Fit model (jalankan di thread pool agar tidak block event loop)
            model = self._build_model()
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, model.fit, df)

            # Buat future dataframe
            max_horizon = max(horizons)
            future = model.make_future_dataframe(periods=max_horizon, freq="h")

            # Predict
            forecast_df = await loop.run_in_executor(None, model.predict, future)

            # Ambil nilai untuk setiap horizon
            results = {}
            now = pd.Timestamp(datetime.utcnow())

            for h in horizons:
                target_time = now + pd.Timedelta(hours=h)
                # Cari baris terdekat dengan target_time
                idx = (forecast_df["ds"] - target_time).abs().idxmin()
                row = forecast_df.iloc[idx]

                predicted = max(0.0, float(row["yhat"]))
                lower = max(0.0, float(row["yhat_lower"]))
                upper = max(0.0, float(row["yhat_upper"]))

                # Confidence: semakin sempit interval, semakin tinggi confidence
                interval_width = upper - lower
                confidence = max(0.3, min(0.95, 1.0 - (interval_width / (predicted + 1))))

                results[h] = {
                    "rainfall_mm": round(predicted, 2),
                    "lower_mm":    round(lower, 2),
                    "upper_mm":    round(upper, 2),
                    "confidence":  round(confidence, 3),
                    "model":       "prophet",
                }

            logger.debug(f"📈 Prophet forecast {zone_id}: "
                         f"6h={results[6]['rainfall_mm']}mm, "
                         f"24h={results[24]['rainfall_mm']}mm")
            return results

        except Exception as e:
            logger.error(f"Prophet error untuk {zone_id}: {e}")
            return self._fallback_forecast(zone_id, horizons)

    def _fallback_forecast(self, zone_id: str, horizons: List[int]) -> Dict[int, Dict]:
        """
        Fallback sederhana jika Prophet gagal:
        Gunakan rata-rata bergerak dari data terkini.
        """
        return {
            h: {
                "rainfall_mm": 5.0,   # estimasi konservatif
                "lower_mm":    0.0,
                "upper_mm":    20.0,
                "confidence":  0.4,
                "model":       "fallback_mean",
            }
            for h in horizons
        }


# ─────────────────────────────────────────────
# River Level Forecaster (LSTM-style dengan numpy)
# ─────────────────────────────────────────────

class RiverLevelForecaster:
    """
    Prediksi level sungai menggunakan model ARIMA sederhana + korelasi curah hujan.
    
    Pendekatan:
    1. Ambil riwayat level sungai 48 jam terakhir
    2. Hitung trend linear (slope)
    3. Tambahkan efek curah hujan yang diprediksi (lag 3-6 jam)
    4. Hasilkan prediksi dengan interval kepercayaan
    """

    def _linear_trend(self, values: List[float]) -> Tuple[float, float]:
        """
        Hitung trend linear dari series data.
        Returns: (slope per jam, intercept)
        """
        if len(values) < 2:
            return 0.0, values[0] if values else 0.0

        n = len(values)
        x = np.arange(n, dtype=float)
        y = np.array(values, dtype=float)

        # Least squares
        x_mean = x.mean()
        y_mean = y.mean()
        slope = np.sum((x - x_mean) * (y - y_mean)) / np.sum((x - x_mean) ** 2)
        intercept = y_mean - slope * x_mean

        return float(slope), float(intercept)

    def _exponential_smoothing(self, values: List[float], alpha: float = 0.3) -> List[float]:
        """Exponential smoothing untuk mengurangi noise."""
        if not values:
            return []
        smoothed = [values[0]]
        for v in values[1:]:
            smoothed.append(alpha * v + (1 - alpha) * smoothed[-1])
        return smoothed

    async def forecast(self, station_id: str, zone_id: str,
                       rainfall_forecasts: Dict[int, Dict],
                       horizons: List[int] = [6, 12, 24]) -> Dict[int, Dict]:
        """
        Prediksi level sungai untuk horizon tertentu.
        
        Args:
            station_id: ID stasiun sungai
            zone_id: ID zona
            rainfall_forecasts: hasil dari RainfallForecaster
            horizons: jam ke depan yang diprediksi
        """
        # Ambil data historis 48 jam
        async with AsyncSessionLocal() as db:
            cutoff = datetime.utcnow() - timedelta(hours=48)
            result = await db.execute(
                select(RiverReading)
                .where(
                    RiverReading.station_id == station_id,
                    RiverReading.timestamp >= cutoff
                )
                .order_by(RiverReading.timestamp.asc())
            )
            readings = result.scalars().all()

        if not readings:
            logger.warning(f"Tidak ada data sungai untuk {station_id}")
            return {h: {"level_m": 5.0, "confidence": 0.3, "model": "no_data"} for h in horizons}

        # Ekstrak level dan smoothing
        levels = [r.water_level_m for r in readings]
        smoothed = self._exponential_smoothing(levels, alpha=0.4)
        current_level = smoothed[-1]
        danger_level = readings[-1].danger_level_m or 10.0

        # Hitung trend dari 12 jam terakhir
        recent_levels = smoothed[-12:] if len(smoothed) >= 12 else smoothed
        slope, _ = self._linear_trend(recent_levels)

        # Hitung standar deviasi untuk interval kepercayaan
        std_dev = np.std(levels[-24:]) if len(levels) >= 24 else np.std(levels)

        results = {}
        for h in horizons:
            # Komponen 1: trend linear
            trend_contribution = slope * h

            # Komponen 2: efek curah hujan (lag 3-6 jam, efek kumulatif)
            rain_data = rainfall_forecasts.get(h, {})
            predicted_rain = rain_data.get("rainfall_mm", 0)
            # Setiap 10mm hujan → naik ~0.25m (tergantung DAS, ini estimasi konservatif)
            rain_contribution = (predicted_rain / 10.0) * 0.25

            # Komponen 3: mean reversion (level cenderung kembali ke rata-rata musiman)
            seasonal_mean = current_level  # simplified
            reversion = (seasonal_mean - current_level) * 0.05 * h

            # Level prediksi
            predicted_level = current_level + trend_contribution + rain_contribution + reversion
            predicted_level = max(0.5, predicted_level)

            # Interval kepercayaan (melebar seiring horizon)
            uncertainty = std_dev * math.sqrt(h / 6.0)
            lower = max(0.0, predicted_level - 1.96 * uncertainty)
            upper = predicted_level + 1.96 * uncertainty

            # Confidence menurun seiring horizon
            confidence = max(0.3, 0.9 - (h / 24.0) * 0.4)

            # Probabilitas banjir: P(level > danger_level)
            if uncertainty > 0:
                z_score = (danger_level - predicted_level) / uncertainty
                flood_prob = max(0.0, min(1.0, 1.0 - _normal_cdf(z_score)))
            else:
                flood_prob = 1.0 if predicted_level >= danger_level else 0.0

            results[h] = {
                "level_m":        round(predicted_level, 3),
                "lower_m":        round(lower, 3),
                "upper_m":        round(upper, 3),
                "danger_level_m": danger_level,
                "flood_prob":     round(flood_prob, 3),
                "confidence":     round(confidence, 3),
                "model":          "linear_trend_rain",
                "components": {
                    "current":    round(current_level, 3),
                    "trend":      round(trend_contribution, 3),
                    "rain":       round(rain_contribution, 3),
                    "reversion":  round(reversion, 3),
                }
            }

        logger.debug(f"🌊 River forecast {station_id}: "
                     f"6h={results[6]['level_m']}m (flood_prob={results[6]['flood_prob']:.1%}), "
                     f"24h={results[24]['level_m']}m")
        return results


def _normal_cdf(x: float) -> float:
    """Approximasi CDF distribusi normal standar."""
    import math
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


# ─────────────────────────────────────────────
# Ensemble Forecaster (gabungan Prophet + River)
# ─────────────────────────────────────────────

class EnsembleForecaster:
    """
    Menggabungkan prediksi curah hujan dan level sungai
    untuk menghasilkan satu skor risiko banjir per zona.
    """

    def __init__(self):
        self.rainfall_forecaster = RainfallForecaster()
        self.river_forecaster = RiverLevelForecaster()

    async def forecast_zone(self, zone_id: str) -> Dict:
        """
        Jalankan forecast lengkap untuk satu zona.
        Returns dict dengan prediksi 6, 12, 24 jam.
        """
        from config import BANGLADESH_ZONES
        zone = BANGLADESH_ZONES.get(zone_id)
        if not zone:
            return {}

        horizons = [6, 12, 24]

        # Forecast curah hujan
        rainfall_fc = await self.rainfall_forecaster.forecast(zone_id, horizons)

        # Forecast level sungai untuk setiap stasiun di zona ini
        river_forecasts = {}
        for station_id in zone.river_stations:
            river_fc = await self.river_forecaster.forecast(
                station_id, zone_id, rainfall_fc, horizons
            )
            river_forecasts[station_id] = river_fc

        # Gabungkan: ambil worst-case dari semua stasiun
        combined = {}
        for h in horizons:
            rain_data = rainfall_fc.get(h, {})

            # Ambil flood probability tertinggi dari semua stasiun
            max_flood_prob = 0.0
            max_level_pct = 0.0
            for station_id, river_fc in river_forecasts.items():
                r = river_fc.get(h, {})
                flood_prob = r.get("flood_prob", 0)
                level = r.get("level_m", 0)
                danger = r.get("danger_level_m", 10)
                level_pct = level / danger if danger > 0 else 0

                if flood_prob > max_flood_prob:
                    max_flood_prob = flood_prob
                if level_pct > max_level_pct:
                    max_level_pct = level_pct

            combined[h] = {
                "rainfall_mm":    rain_data.get("rainfall_mm", 0),
                "flood_prob":     round(max_flood_prob, 3),
                "river_level_pct": round(max_level_pct, 3),  # % dari danger level
                "confidence":     rain_data.get("confidence", 0.5),
                "river_details":  {
                    sid: river_forecasts[sid].get(h, {})
                    for sid in zone.river_stations
                },
            }

        return {
            "zone_id":   zone_id,
            "generated_at": datetime.utcnow().isoformat(),
            "horizons":  combined,
            "rainfall":  rainfall_fc,
        }

    async def save_forecasts(self, zone_id: str, forecast_data: Dict):
        """Simpan hasil forecast ke database."""
        async with AsyncSessionLocal() as db:
            now = datetime.utcnow()
            for h, data in forecast_data.get("horizons", {}).items():
                record = ForecastRecord(
                    zone_id              = zone_id,
                    created_at           = now,
                    forecast_for         = now + timedelta(hours=h),
                    horizon_hours        = h,
                    predicted_rainfall_mm = data.get("rainfall_mm"),
                    predicted_river_level_m = None,  # aggregate
                    flood_probability    = data.get("flood_prob"),
                    confidence           = data.get("confidence"),
                    model_used           = "ensemble_prophet_linear",
                )
                db.add(record)
            await db.commit()


import math  # diperlukan untuk sqrt di river forecaster
