# ERA5 Climatology: District BD1009

## Baseline Summary
- **Mean temperature climatology:** 26.05 °C
- **Mean evaporation climatology:** -3.01 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
