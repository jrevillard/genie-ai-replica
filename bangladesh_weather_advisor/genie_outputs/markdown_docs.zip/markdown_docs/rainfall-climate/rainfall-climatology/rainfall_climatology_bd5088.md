# Rainfall Climatology: District BD5088

## Climatology Summary
- **Mean daily climatological rainfall:** 4.85 mm
- **Median (P50) rainfall benchmark:** 2.84 mm
- **Upper percentile (P90) benchmark:** 11.24 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
