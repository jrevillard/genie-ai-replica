# Crop Distribution: Chuadanga District

**Location:** Chuadanga (BD18)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 73841.10 | 3.53 | Kharif-2 (Jul-Dec) |
| rice_boro | 71171.60 | 4.80 | Rabi (Dec-May) |
| rice_aus | 18348.60 | 2.95 | Kharif-1 (Mar-Aug) |
| vegetables | 8751.80 | 10.92 | Rabi (Oct-Apr) |
| jute | 8510.80 | 2.13 | Kharif-1 (Mar-Aug) |
| oilseeds | 6195.30 | 0.98 | Rabi (Oct-Mar) |
| pulses | 4905.20 | 1.04 | Rabi (Oct-Mar) |
| potato | 3377.70 | 19.07 | Rabi (Nov-Mar) |
| spices | 3190.00 | 4.03 | Rabi/Kharif |
| wheat | 2407.00 | 3.44 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
