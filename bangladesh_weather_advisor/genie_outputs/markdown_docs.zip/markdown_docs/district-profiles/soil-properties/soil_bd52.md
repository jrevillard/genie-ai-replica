# Soil Profile: Lalmonirhat District

**Location:** Lalmonirhat (BD52)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 5.96
- **Clay content:** 24.30%
- **Sand content:** 34.40%
- **Silt content:** 41.80%
- **Soil organic carbon:** 10.36 g/kg
- **CEC:** 14.40 cmol/kg
- **Nitrogen:** 1.12 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
