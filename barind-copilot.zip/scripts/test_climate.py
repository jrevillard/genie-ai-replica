"""Test climate change analysis endpoint."""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import httpx

async def main():
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get("http://localhost:8000/api/climate/SYL-01?days=7")
        d = r.json()
        print(f"Status: {r.status_code}")
        print(f"Zone: {d.get('zone_name')}")
        print(f"Readings: {d.get('total_readings')}")
        print(f"Confidence: {d.get('confidence')}")
        print(f"Summary: {d.get('summary','')[:200]}")
        print(f"Risk signals: {d.get('risk_signals', [])}")
        print(f"Variables: {list(d.get('trends', {}).keys())}")
        print()
        for var, t in list(d.get("trends", {}).items()):
            tr = t.get("trend", {})
            mk = t.get("mann_kendall", {})
            st = t.get("statistics", {})
            print(f"  {var}:")
            print(f"    mean={st.get('mean')} {t.get('unit')}")
            print(f"    slope={tr.get('slope_per_year')}/yr  direction={tr.get('direction')}  strength={tr.get('strength')}")
            print(f"    MK significant={mk.get('significant')}  tau={mk.get('tau')}")
            print(f"    climate_signal={t.get('climate_signal')}")
            print(f"    interpretation: {t.get('interpretation','')[:100]}")
            print()

asyncio.run(main())
