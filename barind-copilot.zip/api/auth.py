"""
Authentication & Authorization untuk Admin Panel.
Menggunakan JWT token sederhana — tidak butuh library tambahan besar.
"""

import os
import hmac
import hashlib
import base64
import json
from datetime import datetime, timedelta
from typing import Optional
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from loguru import logger

# Secret key — ambil dari env atau generate random
SECRET_KEY = os.getenv("ADMIN_SECRET_KEY", "bfews-secret-change-in-production-2026")

# Admin credentials dari env
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "bfews2026!")

# Roles
ROLE_ADMIN    = "admin"
ROLE_OPERATOR = "operator"
ROLE_VIEWER   = "viewer"

security = HTTPBearer(auto_error=False)


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def create_token(username: str, role: str, expires_hours: int = 24) -> str:
    """Buat JWT-like token sederhana."""
    payload = {
        "sub":  username,
        "role": role,
        "exp":  (datetime.utcnow() + timedelta(hours=expires_hours)).isoformat(),
        "iat":  datetime.utcnow().isoformat(),
    }
    payload_b64 = base64.urlsafe_b64encode(
        json.dumps(payload).encode()
    ).decode()

    sig = hmac.new(
        SECRET_KEY.encode(),
        payload_b64.encode(),
        hashlib.sha256
    ).hexdigest()

    return f"{payload_b64}.{sig}"


def verify_token(token: str) -> Optional[dict]:
    """Verifikasi token dan return payload jika valid."""
    try:
        parts = token.split(".")
        if len(parts) != 2:
            return None

        payload_b64, sig = parts

        # Verify signature
        expected_sig = hmac.new(
            SECRET_KEY.encode(),
            payload_b64.encode(),
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(sig, expected_sig):
            return None

        # Decode payload
        payload = json.loads(base64.urlsafe_b64decode(payload_b64 + "=="))

        # Check expiry
        exp = datetime.fromisoformat(payload["exp"])
        if datetime.utcnow() > exp:
            return None

        return payload

    except Exception:
        return None


def authenticate_user(username: str, password: str) -> Optional[dict]:
    """Verifikasi username dan password."""
    # Admin dari env
    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        return {"username": username, "role": ROLE_ADMIN}

    # Operator dari env (opsional)
    op_user = os.getenv("OPERATOR_USERNAME", "")
    op_pass = os.getenv("OPERATOR_PASSWORD", "")
    if op_user and username == op_user and password == op_pass:
        return {"username": username, "role": ROLE_OPERATOR}

    return None


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(security)
) -> dict:
    """Dependency untuk endpoint yang butuh auth."""
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")

    payload = verify_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    return payload


async def require_admin(user: dict = Depends(get_current_user)) -> dict:
    """Dependency untuk endpoint admin only."""
    if user.get("role") not in [ROLE_ADMIN]:
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def require_operator(user: dict = Depends(get_current_user)) -> dict:
    """Dependency untuk endpoint operator+."""
    if user.get("role") not in [ROLE_ADMIN, ROLE_OPERATOR]:
        raise HTTPException(status_code=403, detail="Operator access required")
    return user


def optional_auth(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(security)
) -> Optional[dict]:
    """Auth opsional — return None jika tidak ada token."""
    if not credentials:
        return None
    return verify_token(credentials.credentials)
