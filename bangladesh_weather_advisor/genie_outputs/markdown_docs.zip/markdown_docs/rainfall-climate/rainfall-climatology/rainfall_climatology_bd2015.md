# Rainfall Climatology: District BD2015

## Climatology Summary
- **Mean daily climatological rainfall:** 8.71 mm
- **Median (P50) rainfall benchmark:** 5.47 mm
- **Upper percentile (P90) benchmark:** 19.61 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
