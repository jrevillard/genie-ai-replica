# Crop Distribution: Lalmonirhat District

**Location:** Lalmonirhat (BD52)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 71460.80 | 3.41 | Kharif-2 (Jul-Dec) |
| rice_boro | 61580.90 | 4.37 | Rabi (Dec-May) |
| rice_aus | 18200.30 | 2.61 | Kharif-1 (Mar-Aug) |
| potato | 16295.80 | 20.95 | Rabi (Nov-Mar) |
| vegetables | 9280.70 | 11.83 | Rabi (Oct-Apr) |
| maize | 8874.60 | 7.76 | Rabi (Oct-Apr) |
| wheat | 7472.70 | 2.90 | Rabi (Nov-Mar) |
| jute | 6357.90 | 2.49 | Kharif-1 (Mar-Aug) |
| oilseeds | 4963.40 | 1.07 | Rabi (Oct-Mar) |
| pulses | 4942.50 | 1.01 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
