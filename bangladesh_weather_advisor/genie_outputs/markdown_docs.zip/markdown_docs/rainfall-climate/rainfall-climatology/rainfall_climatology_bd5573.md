# Rainfall Climatology: District BD5573

## Climatology Summary
- **Mean daily climatological rainfall:** 7.47 mm
- **Median (P50) rainfall benchmark:** 4.15 mm
- **Upper percentile (P90) benchmark:** 17.49 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
