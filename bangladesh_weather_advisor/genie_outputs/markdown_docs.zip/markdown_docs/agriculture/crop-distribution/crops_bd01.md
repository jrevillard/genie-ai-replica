# Crop Distribution: Bagerhat District

**Location:** Bagerhat (BD01)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 95860.50 | 3.56 | Kharif-2 (Jul-Dec) |
| rice_boro | 84429.70 | 4.72 | Rabi (Dec-May) |
| rice_aus | 15410.40 | 2.53 | Kharif-1 (Mar-Aug) |
| jute | 9053.90 | 2.58 | Kharif-1 (Mar-Aug) |
| vegetables | 8023.60 | 12.68 | Rabi (Oct-Apr) |
| pulses | 5557.20 | 1.17 | Rabi (Oct-Mar) |
| oilseeds | 4726.70 | 1.07 | Rabi (Oct-Mar) |
| potato | 4040.90 | 20.26 | Rabi (Nov-Mar) |
| spices | 3619.00 | 4.51 | Rabi/Kharif |
| maize | 2660.90 | 8.42 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
