# Rainfall Climatology: District BD3035

## Climatology Summary
- **Mean daily climatological rainfall:** 5.11 mm
- **Median (P50) rainfall benchmark:** 2.86 mm
- **Upper percentile (P90) benchmark:** 11.89 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
