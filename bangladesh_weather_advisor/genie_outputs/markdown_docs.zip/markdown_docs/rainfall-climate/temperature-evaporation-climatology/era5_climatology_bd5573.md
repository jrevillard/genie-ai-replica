# ERA5 Climatology: District BD5573

## Baseline Summary
- **Mean temperature climatology:** 24.39 °C
- **Mean evaporation climatology:** -2.62 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
