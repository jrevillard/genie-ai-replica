# Rainfall Climatology: District BD5594

## Climatology Summary
- **Mean daily climatological rainfall:** 6.77 mm
- **Median (P50) rainfall benchmark:** 3.93 mm
- **Upper percentile (P90) benchmark:** 15.72 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
