"""
Ensemble Flood Forecasting — 3 Algoritma + Weighted Ensemble

Algoritma yang digunakan:
1. Prophet (Facebook) — menangkap musiman + tren jangka panjang
2. LSTM-style (Exponential Smoothing + Holt-Winters) — pola jangka pendek
3. GloFAS Direct — forecast langsung dari model hidrologi global

Ensemble: weighted average berdasarkan akurasi historis masing-masing model.

Output: prediksi debit (m³/s) dan level air (m) untuk 6h, 12h, 24h, 48h, 72h
"""

import asyncio
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from loguru import logger

from data.storage.database import (
    AsyncSessionLocal, RiverReading, WeatherReading, ForecastRecord
)
from data.ingestion.river_collector import (
    discharge_to_level, get_glofas_forecast_series, RIVER_PARAMS
)
from sqlalchemy.future import select


@dataclass
class ForecastPoint:
    horizon_hours: int
    discharge_m3s: float
    water_level_m: float
    lower_m: float
    upper_m: float
    flood_probability: float
    confidence: float
    model_used: str


# ─────────────────────────────────────────────
# Model 1: Prophet-based (via statsmodels ETS)
# ─────────────────────────────────────────────

class HoltWintersForecaster:
    """
    Holt-Winters Exponential Smoothing — menangkap:
    - Tren (naik/turun)
    - Musiman tahunan (monsun Bangladesh)
    - Smoothing noise sensor
    
    Lebih ringan dari Prophet tapi akurat untuk data pendek.
    """

    def __init__(self, alpha: float = 0.3, beta: float = 0.1, gamma: float = 0.2):
        self.alpha = alpha  # level smoothing
        self.beta = beta    # trend smoothing
        self.gamma = gamma  # seasonal smoothing

    def _double_exponential_smooth(
        self, data: List[float], horizon: int
    ) -> Tuple[List[float], float]:
        """
        Double exponential smoothing (Holt's method) untuk tren.
        Returns: (forecasts, confidence)
        """
        if len(data) < 3:
            return [data[-1]] * horizon, 0.3

        # Initialize
        s = [data[0]]  # level
        b = [data[1] - data[0]]  # trend

        for i in range(1, len(data)):
            s_new = self.alpha * data[i] + (1 - self.alpha) * (s[-1] + b[-1])
            b_new = self.beta * (s_new - s[-1]) + (1 - self.beta) * b[-1]
            s.append(s_new)
            b.append(b_new)

        # Forecast
        forecasts = []
        max_val = max(data) * 3  # hard cap
        for h in range(1, horizon + 1):
            f = s[-1] + h * b[-1]
            # Dampen trend for longer horizons to prevent divergence
            dampen = 0.98 ** h
            f = s[-1] + (h * b[-1]) * dampen
            forecasts.append(max(0, min(f, max_val)))

        # Confidence based on recent variance
        recent = data[-min(14, len(data)):]
        cv = np.std(recent) / (np.mean(recent) + 1e-6)
        confidence = max(0.3, min(0.9, 1.0 - cv))

        return forecasts, confidence

    def forecast(
        self, historical: List[float], horizons: List[int]
    ) -> Dict[int, Dict]:
        """
        Forecast untuk horizon tertentu (dalam hari, karena data GloFAS harian).
        """
        if len(historical) < 5:
            mean_val = np.mean(historical) if historical else 100.0
            return {h: {"value": mean_val, "confidence": 0.2} for h in horizons}

        max_h = max(horizons)
        forecasts, confidence = self._double_exponential_smooth(historical, max_h)

        # Uncertainty grows with horizon
        std = np.std(historical[-14:]) if len(historical) >= 14 else np.std(historical)

        results = {}
        for h in horizons:
            idx = min(h - 1, len(forecasts) - 1)
            val = forecasts[idx]
            uncertainty = std * math.sqrt(h / 7.0)  # grows with sqrt(time)
            results[h] = {
                "value":      max(0, val),
                "lower":      max(0, val - 1.96 * uncertainty),
                "upper":      val + 1.96 * uncertainty,
                "confidence": confidence * max(0.3, 1.0 - h / (max_h * 2)),
            }
        return results


# ─────────────────────────────────────────────
# Model 2: ARIMA-style (AutoRegressive)
# ─────────────────────────────────────────────

class ARIMAForecaster:
    """
    Simplified AR(p) model — AutoRegressive.
    Menggunakan p lag terakhir untuk prediksi.
    
    Cocok untuk: data dengan autokorelasi kuat (level sungai sangat autokorelasi)
    """

    def __init__(self, p: int = 7):
        self.p = p  # AR order — gunakan 7 hari terakhir

    def _fit_ar(self, data: np.ndarray) -> Tuple[np.ndarray, float]:
        """Fit AR(p) menggunakan OLS."""
        n = len(data)
        if n <= self.p:
            return np.array([1.0 / self.p] * self.p), 0.0

        # Build design matrix
        X = np.zeros((n - self.p, self.p))
        y = data[self.p:]
        for i in range(n - self.p):
            X[i] = data[i:i + self.p]

        # OLS: coefficients = (X'X)^-1 X'y
        try:
            XtX = X.T @ X
            Xty = X.T @ y
            # Add small regularization
            XtX += np.eye(self.p) * 1e-6
            coeffs = np.linalg.solve(XtX, Xty)
        except np.linalg.LinAlgError:
            coeffs = np.ones(self.p) / self.p

        # R-squared
        y_pred = X @ coeffs
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r2 = 1 - ss_res / (ss_tot + 1e-10)

        return coeffs, max(0.0, r2)

    def forecast(
        self, historical: List[float], horizons: List[int]
    ) -> Dict[int, Dict]:
        """Multi-step AR forecast."""
        if len(historical) < self.p + 2:
            mean_val = np.mean(historical) if historical else 100.0
            return {h: {"value": mean_val, "confidence": 0.2} for h in horizons}

        data = np.array(historical, dtype=float)
        coeffs, r2 = self._fit_ar(data)

        # Clamp coefficients sum to prevent divergence
        coeff_sum = np.sum(np.abs(coeffs))
        if coeff_sum > 0.99:
            coeffs = coeffs * 0.95 / coeff_sum

        # Iterative multi-step forecast
        history = list(data[-self.p:])
        all_forecasts = []
        max_h = max(horizons)
        max_val = float(np.max(data)) * 3  # hard cap at 3x historical max

        for _ in range(max_h):
            next_val = float(np.dot(coeffs, history[-self.p:]))
            next_val = max(0, min(next_val, max_val))  # clamp
            all_forecasts.append(next_val)
            history.append(next_val)

        # Prediction intervals
        residuals = data[self.p:] - np.array([
            np.dot(coeffs, data[i:i+self.p]) for i in range(len(data)-self.p)
        ])
        rmse = float(np.sqrt(np.mean(residuals**2)))

        results = {}
        for h in horizons:
            val = all_forecasts[h - 1]
            uncertainty = rmse * math.sqrt(h)
            confidence = max(0.2, r2 * max(0.3, 1.0 - h / (max_h * 1.5)))
            results[h] = {
                "value":      val,
                "lower":      max(0, val - 1.96 * uncertainty),
                "upper":      min(max_val, val + 1.96 * uncertainty),
                "confidence": confidence,
            }
        return results


# ─────────────────────────────────────────────
# Model 3: GloFAS Direct Forecast
# ─────────────────────────────────────────────

class GloFASForecaster:
    """
    Menggunakan forecast langsung dari GloFAS ensemble.
    Ini adalah model hidrologi fisik yang paling akurat untuk
    prediksi jangka menengah (7-30 hari).
    
    Kelebihan: berbasis model fisik, bukan statistik
    Kekurangan: resolusi harian, tidak sub-harian
    """

    async def forecast(
        self, station_id: str, horizons: List[int]
    ) -> Dict[int, Dict]:
        """
        Ambil forecast GloFAS dan konversi ke format standar.
        horizons dalam jam → konversi ke hari untuk GloFAS.
        """
        glofas_data = await get_glofas_forecast_series(station_id)

        if not glofas_data or not glofas_data.get("fc_discharge"):
            return {}

        fc_q = glofas_data["fc_discharge"]
        fc_p25 = glofas_data.get("fc_p25", [])
        fc_p75 = glofas_data.get("fc_p75", [])

        results = {}
        for h in horizons:
            # Konversi jam ke indeks hari GloFAS
            day_idx = max(0, min(h // 24, len(fc_q) - 1))
            if day_idx == 0 and h < 24:
                day_idx = 0  # gunakan hari pertama untuk <24h

            q = fc_q[day_idx] if day_idx < len(fc_q) else fc_q[-1]
            q_low = fc_p25[day_idx] if day_idx < len(fc_p25) else q * 0.8
            q_high = fc_p75[day_idx] if day_idx < len(fc_p75) else q * 1.2

            # Confidence tinggi untuk GloFAS (model fisik)
            confidence = max(0.5, 0.85 - (h / 24) * 0.02)

            results[h] = {
                "value":      max(0, q),
                "lower":      max(0, q_low),
                "upper":      max(0, q_high),
                "confidence": confidence,
                "source":     "glofas_v4",
            }

        return results


# ─────────────────────────────────────────────
# Ensemble Combiner
# ─────────────────────────────────────────────

class EnsembleFloodForecaster:
    """
    Menggabungkan 3 model dengan weighted average.
    
    Bobot default:
    - GloFAS: 0.50 (model fisik, paling akurat jangka menengah)
    - AR(7):  0.30 (autokorelasi kuat untuk jangka pendek)
    - HW:     0.20 (tren dan musiman)
    
    Bobot disesuaikan berdasarkan confidence masing-masing model.
    """

    # Bobot dasar per model
    BASE_WEIGHTS = {
        "glofas":    0.50,
        "ar":        0.30,
        "holt_winters": 0.20,
    }

    def __init__(self):
        self.hw_model = HoltWintersForecaster()
        self.ar_model = ARIMAForecaster(p=7)
        self.glofas_model = GloFASForecaster()

    def _flood_probability(
        self, level_m: float, danger_level_m: float,
        upper_m: float, confidence: float
    ) -> float:
        """
        Hitung probabilitas banjir berdasarkan:
        - Level prediksi vs danger level
        - Interval ketidakpastian
        - Confidence model
        
        Skala:
        < 60% danger → prob rendah (0-15%)
        60-75% danger → prob sedang (15-35%)
        75-90% danger → prob tinggi (35-65%)
        90-100% danger → prob sangat tinggi (65-90%)
        > 100% danger → prob kritis (90-99%)
        """
        if danger_level_m <= 0:
            return 0.0

        ratio = level_m / danger_level_m

        if ratio >= 1.0:
            base_prob = 0.90 + min(0.09, (ratio - 1.0) * 0.5)
        elif ratio >= 0.90:
            base_prob = 0.65 + (ratio - 0.90) * 2.5
        elif ratio >= 0.75:
            base_prob = 0.35 + (ratio - 0.75) * 2.0
        elif ratio >= 0.60:
            base_prob = 0.15 + (ratio - 0.60) * 1.33
        else:
            base_prob = ratio * 0.25

        # Slight upward adjustment if upper bound crosses danger
        upper_ratio = upper_m / danger_level_m
        if upper_ratio >= 1.0 and ratio < 1.0:
            base_prob = min(0.85, base_prob + 0.10)

        # Scale dengan confidence (model yang tidak yakin → prob lebih rendah)
        adjusted = base_prob * (0.6 + 0.4 * confidence)

        return round(min(0.99, max(0.0, adjusted)), 3)

    async def forecast_station(
        self,
        station_id: str,
        zone_id: str,
        horizons: List[int] = [6, 12, 24, 48, 72],
    ) -> Dict[int, ForecastPoint]:
        """
        Jalankan semua model dan gabungkan hasilnya.
        """
        # Ambil data historis dari database
        async with AsyncSessionLocal() as db:
            cutoff = datetime.utcnow() - timedelta(days=90)
            result = await db.execute(
                select(RiverReading)
                .where(
                    RiverReading.station_id == station_id,
                    RiverReading.timestamp >= cutoff
                )
                .order_by(RiverReading.timestamp.asc())
            )
            readings = result.scalars().all()

        if not readings:
            logger.warning(f"Tidak ada data historis untuk {station_id}")
            return {}

        # Ekstrak debit historis (gunakan flow_rate jika ada, else estimasi dari level)
        hist_discharge = []
        for r in readings:
            if r.flow_rate_m3s and r.flow_rate_m3s > 0:
                hist_discharge.append(r.flow_rate_m3s)
            else:
                # Estimasi balik dari level
                params = RIVER_PARAMS.get(station_id, {"width": 100, "coeff": 0.040})
                w = params["width"]
                n = params["coeff"]
                S = 0.0001
                q_est = (r.water_level_m ** (5/3)) * w * math.sqrt(S) / n
                hist_discharge.append(max(0, q_est))

        danger_level = readings[-1].danger_level_m or 10.0

        # Jalankan 3 model secara paralel
        hw_fc = self.hw_model.forecast(hist_discharge, horizons)
        ar_fc = self.ar_model.forecast(hist_discharge, horizons)
        glofas_fc = await self.glofas_model.forecast(station_id, horizons)

        # Gabungkan dengan weighted ensemble
        results = {}
        for h in horizons:
            hw = hw_fc.get(h, {})
            ar = ar_fc.get(h, {})
            gf = glofas_fc.get(h, {})

            # Kumpulkan prediksi yang tersedia
            predictions = []
            if hw.get("value") is not None:
                predictions.append(("holt_winters", hw["value"], hw.get("confidence", 0.3),
                                    hw.get("lower", 0), hw.get("upper", hw["value"] * 1.5)))
            if ar.get("value") is not None:
                predictions.append(("ar", ar["value"], ar.get("confidence", 0.3),
                                    ar.get("lower", 0), ar.get("upper", ar["value"] * 1.5)))
            if gf.get("value") is not None:
                predictions.append(("glofas", gf["value"], gf.get("confidence", 0.5),
                                    gf.get("lower", 0), gf.get("upper", gf["value"] * 1.5)))

            if not predictions:
                continue

            # Weighted average berdasarkan confidence × base_weight
            total_weight = 0.0
            weighted_val = 0.0
            weighted_lower = 0.0
            weighted_upper = 0.0
            models_used = []

            for model_name, val, conf, lower, upper in predictions:
                w = self.BASE_WEIGHTS.get(model_name, 0.2) * conf
                total_weight += w
                weighted_val += w * val
                weighted_lower += w * lower
                weighted_upper += w * upper
                models_used.append(f"{model_name}({conf:.2f})")

            if total_weight == 0:
                continue

            final_q = weighted_val / total_weight
            final_lower_q = weighted_lower / total_weight
            final_upper_q = weighted_upper / total_weight
            avg_confidence = total_weight / sum(
                self.BASE_WEIGHTS.get(m, 0.2) for m, _, _, _, _ in predictions
            )

            # Konversi debit → level
            final_level = discharge_to_level(final_q, station_id)
            lower_level = discharge_to_level(final_lower_q, station_id)
            upper_level = discharge_to_level(final_upper_q, station_id)

            # Flood probability
            flood_prob = self._flood_probability(
                final_level, danger_level, upper_level, avg_confidence
            )

            results[h] = ForecastPoint(
                horizon_hours    = h,
                discharge_m3s    = round(final_q, 2),
                water_level_m    = round(final_level, 3),
                lower_m          = round(lower_level, 3),
                upper_m          = round(upper_level, 3),
                flood_probability = flood_prob,
                confidence       = round(min(0.95, avg_confidence), 3),
                model_used       = "ensemble[" + ", ".join(models_used) + "]",
            )

        return results

    async def forecast_zone(self, zone_id: str) -> Dict:
        """Forecast untuk semua stasiun di satu zona."""
        from config import BANGLADESH_ZONES
        zone = BANGLADESH_ZONES.get(zone_id)
        if not zone:
            return {}

        horizons = [6, 12, 24, 48, 72]
        zone_results = {}

        for station_id in zone.river_stations:
            try:
                fc = await self.forecast_station(station_id, zone_id, horizons)
                if fc:
                    zone_results[station_id] = fc
            except Exception as e:
                logger.error(f"Forecast error {station_id}: {e}")

        return {
            "zone_id":    zone_id,
            "generated":  datetime.utcnow().isoformat(),
            "stations":   {
                sid: {
                    h: {
                        "discharge_m3s":    fp.discharge_m3s,
                        "water_level_m":    fp.water_level_m,
                        "lower_m":          fp.lower_m,
                        "upper_m":          fp.upper_m,
                        "flood_probability": fp.flood_probability,
                        "confidence":       fp.confidence,
                        "model":            fp.model_used,
                    }
                    for h, fp in station_fc.items()
                }
                for sid, station_fc in zone_results.items()
            },
        }

    async def save_forecasts(self, zone_id: str, zone_forecast: Dict):
        """Simpan hasil forecast ke database."""
        async with AsyncSessionLocal() as db:
            now = datetime.utcnow()
            for station_id, station_fc in zone_forecast.get("stations", {}).items():
                for h, fc_data in station_fc.items():
                    # Estimasi rainfall dari perubahan debit
                    level = fc_data.get("water_level_m", 0)
                    flood_prob = fc_data.get("flood_probability", 0)
                    # Estimasi rainfall dari flood probability (proxy)
                    est_rainfall = flood_prob * 50  # rough estimate

                    record = ForecastRecord(
                        zone_id               = zone_id,
                        created_at            = now,
                        forecast_for          = now + timedelta(hours=h),
                        horizon_hours         = h,
                        predicted_rainfall_mm = round(est_rainfall, 1),
                        predicted_river_level_m = fc_data.get("water_level_m"),
                        flood_probability     = fc_data.get("flood_probability"),
                        confidence            = fc_data.get("confidence"),
                        model_used            = fc_data.get("model", "ensemble"),
                    )
                    db.add(record)
            await db.commit()


# Singleton
ensemble_forecaster = EnsembleFloodForecaster()
