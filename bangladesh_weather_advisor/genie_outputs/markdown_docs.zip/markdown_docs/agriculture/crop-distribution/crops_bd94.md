# Crop Distribution: Thakurgaon District

**Location:** Thakurgaon (BD94)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 84433.50 | 4.33 | Kharif-2 (Jul-Dec) |
| rice_boro | 78701.30 | 4.90 | Rabi (Dec-May) |
| rice_aus | 12998.60 | 2.31 | Kharif-1 (Mar-Aug) |
| potato | 12118.30 | 17.62 | Rabi (Nov-Mar) |
| maize | 10004.00 | 9.13 | Rabi (Oct-Apr) |
| wheat | 9759.70 | 3.67 | Rabi (Nov-Mar) |
| vegetables | 7303.10 | 13.18 | Rabi (Oct-Apr) |
| pulses | 5891.40 | 1.13 | Rabi (Oct-Mar) |
| oilseeds | 5233.60 | 0.97 | Rabi (Oct-Mar) |
| jute | 4679.70 | 2.61 | Kharif-1 (Mar-Aug) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
