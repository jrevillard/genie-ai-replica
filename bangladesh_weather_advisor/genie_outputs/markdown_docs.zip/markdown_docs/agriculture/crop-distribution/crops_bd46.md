# Crop Distribution: Khagrachhari District

**Location:** Khagrachhari (BD46)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 61016.30 | 4.25 | Kharif-2 (Jul-Dec) |
| rice_boro | 56136.70 | 4.87 | Rabi (Dec-May) |
| rice_aus | 14631.10 | 2.52 | Kharif-1 (Mar-Aug) |
| vegetables | 7331.00 | 11.54 | Rabi (Oct-Apr) |
| jute | 7112.20 | 2.62 | Kharif-1 (Mar-Aug) |
| pulses | 6989.00 | 1.15 | Rabi (Oct-Mar) |
| oilseeds | 5806.70 | 0.91 | Rabi (Oct-Mar) |
| maize | 3893.90 | 7.88 | Rabi (Oct-Apr) |
| spices | 3636.00 | 4.73 | Rabi/Kharif |
| potato | 2998.00 | 19.51 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
