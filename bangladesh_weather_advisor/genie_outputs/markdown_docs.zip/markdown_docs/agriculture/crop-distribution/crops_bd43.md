# Crop Distribution: Joypurhat District

**Location:** Joypurhat (BD43)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 70582.50 | 3.39 | Kharif-2 (Jul-Dec) |
| rice_boro | 64992.70 | 5.39 | Rabi (Dec-May) |
| rice_aus | 14458.50 | 2.37 | Kharif-1 (Mar-Aug) |
| maize | 13578.70 | 8.43 | Rabi (Oct-Apr) |
| potato | 9922.00 | 21.50 | Rabi (Nov-Mar) |
| wheat | 9000.00 | 3.55 | Rabi (Nov-Mar) |
| vegetables | 8196.80 | 12.47 | Rabi (Oct-Apr) |
| oilseeds | 5800.50 | 0.94 | Rabi (Oct-Mar) |
| pulses | 5691.10 | 1.19 | Rabi (Oct-Mar) |
| jute | 5424.60 | 2.57 | Kharif-1 (Mar-Aug) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
