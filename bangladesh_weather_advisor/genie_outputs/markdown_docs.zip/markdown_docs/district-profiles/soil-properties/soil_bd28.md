# Soil Profile: Dinajpur District

**Location:** Dinajpur (BD28)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 5.56
- **Clay content:** 25.30%
- **Sand content:** 34.50%
- **Silt content:** 40.30%
- **Soil organic carbon:** 9.89 g/kg
- **CEC:** 14.20 cmol/kg
- **Nitrogen:** 1.07 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
