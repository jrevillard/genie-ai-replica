# Crop Distribution: Chandpur District

**Location:** Chandpur (BD22)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 80619.00 | 3.73 | Kharif-2 (Jul-Dec) |
| rice_boro | 50234.50 | 5.71 | Rabi (Dec-May) |
| rice_aus | 11860.40 | 2.50 | Kharif-1 (Mar-Aug) |
| vegetables | 8963.40 | 12.82 | Rabi (Oct-Apr) |
| jute | 7155.90 | 2.14 | Kharif-1 (Mar-Aug) |
| pulses | 6206.90 | 0.99 | Rabi (Oct-Mar) |
| oilseeds | 5892.40 | 0.90 | Rabi (Oct-Mar) |
| maize | 4472.40 | 9.65 | Rabi (Oct-Apr) |
| spices | 4011.00 | 4.82 | Rabi/Kharif |
| potato | 2669.50 | 19.71 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
