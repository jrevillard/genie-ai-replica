"""
Deteksi anomali pada data sensor menggunakan:
1. Isolation Forest — deteksi outlier multivariat
2. Rule-based threshold — deteksi cepat berbasis aturan
3. Rate-of-change detector — deteksi perubahan mendadak

Anomali yang dideteksi:
- Level sungai naik drastis (>1.5m dalam 3 jam)
- Tekanan udara turun tajam (tanda siklon)
- Curah hujan ekstrem mendadak
- Kombinasi beberapa faktor sekaligus
"""

import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from loguru import logger

try:
    from sklearn.ensemble import IsolationForest
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn tidak tersedia")

from data.storage.database import AsyncSessionLocal, WeatherReading, RiverReading
from sqlalchemy.future import select


@dataclass
class AnomalyEvent:
    """Representasi satu kejadian anomali."""
    zone_id:     str
    station_id:  Optional[str]
    detected_at: datetime
    anomaly_type: str          # "river_surge", "pressure_drop", "extreme_rain", "multivariate"
    severity:    float         # 0.0 – 1.0
    description: str
    description_bn: str        # dalam Bahasa Bengali
    values:      Dict          # nilai-nilai yang memicu anomali


# ─────────────────────────────────────────────
# Rule-Based Detector (cepat, deterministik)
# ─────────────────────────────────────────────

class RuleBasedDetector:
    """
    Deteksi anomali berbasis aturan threshold.
    Ini adalah lapis pertama — cepat dan dapat diprediksi.
    """

    def check_river_surge(self, current_level: float, prev_level: float,
                           hours: float, danger_level: float,
                           zone_id: str, station_id: str) -> Optional[AnomalyEvent]:
        """Deteksi kenaikan level sungai mendadak."""
        change = current_level - prev_level
        change_rate = change / hours if hours > 0 else change

        severity = 0.0
        desc_en = ""
        desc_bn = ""

        if change_rate >= 0.8:  # naik >0.8m/jam = sangat berbahaya
            severity = 0.9
            desc_en = f"CRITICAL: River rising {change:.2f}m in {hours:.0f}h ({change_rate:.2f}m/h)"
            desc_bn = f"বিপজ্জনক: নদীর পানি {hours:.0f} ঘণ্টায় {change:.2f} মিটার বেড়েছে"
        elif change_rate >= 0.5:  # naik >0.5m/jam = berbahaya
            severity = 0.7
            desc_en = f"WARNING: River rising {change:.2f}m in {hours:.0f}h"
            desc_bn = f"সতর্কতা: নদীর পানি {hours:.0f} ঘণ্টায় {change:.2f} মিটার বেড়েছে"
        elif change_rate >= 0.25:  # naik >0.25m/jam = waspada
            severity = 0.4
            desc_en = f"WATCH: River rising {change:.2f}m in {hours:.0f}h"
            desc_bn = f"সাবধান: নদীর পানি {hours:.0f} ঘণ্টায় {change:.2f} মিটার বেড়েছে"

        # Tambah severity jika sudah dekat danger level
        level_pct = current_level / danger_level if danger_level > 0 else 0
        if level_pct > 0.9:
            severity = min(1.0, severity + 0.2)
        elif level_pct > 0.75:
            severity = min(1.0, severity + 0.1)

        if severity > 0:
            return AnomalyEvent(
                zone_id=zone_id, station_id=station_id,
                detected_at=datetime.utcnow(),
                anomaly_type="river_surge",
                severity=severity,
                description=desc_en, description_bn=desc_bn,
                values={
                    "current_level": current_level,
                    "prev_level": prev_level,
                    "change_m": change,
                    "change_rate_m_per_h": change_rate,
                    "danger_level": danger_level,
                    "level_pct": level_pct,
                }
            )
        return None

    def check_pressure_drop(self, current_pressure: float, prev_pressure: float,
                             hours: float, zone_id: str) -> Optional[AnomalyEvent]:
        """Deteksi penurunan tekanan udara mendadak (tanda siklon)."""
        change = current_pressure - prev_pressure  # negatif = turun
        change_rate = change / hours if hours > 0 else change

        severity = 0.0
        desc_en = ""
        desc_bn = ""

        if change_rate <= -3.0:  # turun >3 hPa/jam = siklon sangat kuat
            severity = 0.95
            desc_en = f"CYCLONE ALERT: Pressure dropping {abs(change):.1f}hPa in {hours:.0f}h"
            desc_bn = f"ঘূর্ণিঝড় সতর্কতা: {hours:.0f} ঘণ্টায় বায়ুচাপ {abs(change):.1f} hPa কমেছে"
        elif change_rate <= -1.5:  # turun >1.5 hPa/jam = potensi siklon
            severity = 0.7
            desc_en = f"CYCLONE WATCH: Pressure dropping {abs(change):.1f}hPa in {hours:.0f}h"
            desc_bn = f"ঘূর্ণিঝড় সাবধান: {hours:.0f} ঘণ্টায় বায়ুচাপ {abs(change):.1f} hPa কমেছে"
        elif change_rate <= -0.8:
            severity = 0.4
            desc_en = f"WATCH: Pressure dropping {abs(change):.1f}hPa in {hours:.0f}h"
            desc_bn = f"সাবধান: বায়ুচাপ কমছে"

        if severity > 0:
            return AnomalyEvent(
                zone_id=zone_id, station_id=None,
                detected_at=datetime.utcnow(),
                anomaly_type="pressure_drop",
                severity=severity,
                description=desc_en, description_bn=desc_bn,
                values={
                    "current_pressure": current_pressure,
                    "prev_pressure": prev_pressure,
                    "change_hpa": change,
                    "change_rate": change_rate,
                }
            )
        return None

    def check_extreme_rainfall(self, rainfall_1h: float, rainfall_6h: float,
                                zone_id: str) -> Optional[AnomalyEvent]:
        """Deteksi curah hujan ekstrem."""
        severity = 0.0
        desc_en = ""
        desc_bn = ""

        if rainfall_1h >= 50:  # >50mm/jam = sangat ekstrem
            severity = 0.9
            desc_en = f"EXTREME RAIN: {rainfall_1h:.1f}mm/hour"
            desc_bn = f"অতি ভারী বৃষ্টি: ঘণ্টায় {rainfall_1h:.1f} মিমি"
        elif rainfall_1h >= 25:  # >25mm/jam = ekstrem
            severity = 0.7
            desc_en = f"HEAVY RAIN: {rainfall_1h:.1f}mm/hour"
            desc_bn = f"ভারী বৃষ্টি: ঘণ্টায় {rainfall_1h:.1f} মিমি"
        elif rainfall_6h >= 100:  # >100mm/6jam = sangat berbahaya
            severity = 0.85
            desc_en = f"EXTREME RAIN: {rainfall_6h:.1f}mm in 6 hours"
            desc_bn = f"অতি ভারী বৃষ্টি: ৬ ঘণ্টায় {rainfall_6h:.1f} মিমি"
        elif rainfall_6h >= 50:
            severity = 0.6
            desc_en = f"HEAVY RAIN: {rainfall_6h:.1f}mm in 6 hours"
            desc_bn = f"ভারী বৃষ্টি: ৬ ঘণ্টায় {rainfall_6h:.1f} মিমি"

        if severity > 0:
            return AnomalyEvent(
                zone_id=zone_id, station_id=None,
                detected_at=datetime.utcnow(),
                anomaly_type="extreme_rain",
                severity=severity,
                description=desc_en, description_bn=desc_bn,
                values={"rainfall_1h": rainfall_1h, "rainfall_6h": rainfall_6h}
            )
        return None

    def check_extreme_wind(self, wind_speed: float, zone_id: str) -> Optional[AnomalyEvent]:
        """Deteksi angin kencang ekstrem."""
        severity = 0.0
        desc_en = ""
        desc_bn = ""

        if wind_speed >= 120:  # >120 km/h = siklon kategori tinggi
            severity = 0.95
            desc_en = f"SEVERE CYCLONE: Wind {wind_speed:.0f}km/h"
            desc_bn = f"প্রচণ্ড ঘূর্ণিঝড়: বাতাসের গতি {wind_speed:.0f} কিমি/ঘণ্টা"
        elif wind_speed >= 90:
            severity = 0.8
            desc_en = f"CYCLONE: Wind {wind_speed:.0f}km/h"
            desc_bn = f"ঘূর্ণিঝড়: বাতাসের গতি {wind_speed:.0f} কিমি/ঘণ্টা"
        elif wind_speed >= 60:
            severity = 0.5
            desc_en = f"STRONG WIND: {wind_speed:.0f}km/h"
            desc_bn = f"তীব্র বাতাস: {wind_speed:.0f} কিমি/ঘণ্টা"

        if severity > 0:
            return AnomalyEvent(
                zone_id=zone_id, station_id=None,
                detected_at=datetime.utcnow(),
                anomaly_type="extreme_wind",
                severity=severity,
                description=desc_en, description_bn=desc_bn,
                values={"wind_speed": wind_speed}
            )
        return None


# ─────────────────────────────────────────────
# Isolation Forest Detector (ML-based)
# ─────────────────────────────────────────────

class IsolationForestDetector:
    """
    Deteksi anomali multivariat menggunakan Isolation Forest.
    Mendeteksi kombinasi kondisi yang tidak normal secara bersamaan.
    """

    def __init__(self, contamination: float = 0.05):
        self.contamination = contamination
        self.models: Dict[str, IsolationForest] = {}
        self.scalers: Dict[str, StandardScaler] = {}

    def _extract_features(self, weather_readings: List[WeatherReading]) -> np.ndarray:
        """Ekstrak fitur dari data cuaca untuk Isolation Forest."""
        features = []
        for r in weather_readings:
            features.append([
                r.temperature or 25.0,
                r.humidity or 70.0,
                r.pressure or 1010.0,
                r.wind_speed or 0.0,
                r.rainfall_1h or 0.0,
                r.rainfall_6h or 0.0,
                r.cloud_cover or 50.0,
            ])
        return np.array(features)

    def train(self, zone_id: str, features: np.ndarray):
        """Latih model Isolation Forest untuk zona tertentu."""
        if not SKLEARN_AVAILABLE or len(features) < 50:
            return

        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)

        model = IsolationForest(
            contamination=self.contamination,
            n_estimators=100,
            random_state=42,
            n_jobs=-1,
        )
        model.fit(features_scaled)

        self.models[zone_id] = model
        self.scalers[zone_id] = scaler
        logger.debug(f"🤖 Isolation Forest trained untuk zona {zone_id} "
                     f"({len(features)} samples)")

    def predict(self, zone_id: str, current_features: np.ndarray) -> Tuple[bool, float]:
        """
        Prediksi apakah kondisi saat ini anomali.
        Returns: (is_anomaly, anomaly_score)
        """
        if not SKLEARN_AVAILABLE:
            return False, 0.0

        if zone_id not in self.models:
            return False, 0.0

        model = self.models[zone_id]
        scaler = self.scalers[zone_id]

        features_scaled = scaler.transform(current_features.reshape(1, -1))
        prediction = model.predict(features_scaled)[0]  # -1 = anomali, 1 = normal
        score = model.score_samples(features_scaled)[0]  # lebih negatif = lebih anomali

        # Konversi score ke 0-1 (0 = normal, 1 = sangat anomali)
        anomaly_score = max(0.0, min(1.0, (-score - 0.1) / 0.5))

        return prediction == -1, anomaly_score


# ─────────────────────────────────────────────
# Main Anomaly Detection Engine
# ─────────────────────────────────────────────

class AnomalyDetectionEngine:
    """
    Mesin deteksi anomali utama yang menggabungkan
    rule-based dan ML-based detection.
    """

    def __init__(self):
        self.rule_detector = RuleBasedDetector()
        self.ml_detector = IsolationForestDetector()

    async def detect_zone_anomalies(self, zone_id: str) -> List[AnomalyEvent]:
        """
        Jalankan semua deteksi anomali untuk satu zona.
        Returns list anomali yang terdeteksi.
        """
        anomalies = []

        async with AsyncSessionLocal() as db:
            # Ambil data cuaca terkini dan 6 jam lalu
            now = datetime.utcnow()
            cutoff_6h = now - timedelta(hours=6)
            cutoff_1h = now - timedelta(hours=1)

            # Data terkini
            result = await db.execute(
                select(WeatherReading)
                .where(WeatherReading.zone_id == zone_id)
                .order_by(WeatherReading.timestamp.desc())
                .limit(1)
            )
            current_weather = result.scalar_one_or_none()

            # Data 6 jam lalu
            result = await db.execute(
                select(WeatherReading)
                .where(
                    WeatherReading.zone_id == zone_id,
                    WeatherReading.timestamp >= cutoff_6h,
                    WeatherReading.timestamp <= cutoff_6h + timedelta(minutes=30)
                )
                .order_by(WeatherReading.timestamp.asc())
                .limit(1)
            )
            old_weather = result.scalar_one_or_none()

        if current_weather:
            # Cek curah hujan ekstrem
            rain_anomaly = self.rule_detector.check_extreme_rainfall(
                current_weather.rainfall_1h or 0,
                current_weather.rainfall_6h or 0,
                zone_id
            )
            if rain_anomaly:
                anomalies.append(rain_anomaly)

            # Cek angin kencang
            wind_anomaly = self.rule_detector.check_extreme_wind(
                current_weather.wind_speed or 0,
                zone_id
            )
            if wind_anomaly:
                anomalies.append(wind_anomaly)

            # Cek penurunan tekanan (jika ada data lama)
            if old_weather and current_weather.pressure and old_weather.pressure:
                pressure_anomaly = self.rule_detector.check_pressure_drop(
                    current_weather.pressure,
                    old_weather.pressure,
                    6.0, zone_id
                )
                if pressure_anomaly:
                    anomalies.append(pressure_anomaly)

        # Cek level sungai untuk setiap stasiun di zona
        from config import BANGLADESH_ZONES
        zone = BANGLADESH_ZONES.get(zone_id)
        if zone:
            for station_id in zone.river_stations:
                river_anomaly = await self._check_river_station(station_id, zone_id)
                if river_anomaly:
                    anomalies.append(river_anomaly)

        if anomalies:
            logger.info(f"⚠️  {len(anomalies)} anomali terdeteksi di zona {zone_id}: "
                        f"{[a.anomaly_type for a in anomalies]}")

        return anomalies

    async def _check_river_station(self, station_id: str, zone_id: str) -> Optional[AnomalyEvent]:
        """Cek anomali level sungai untuk satu stasiun."""
        async with AsyncSessionLocal() as db:
            # Ambil 2 data terbaru
            result = await db.execute(
                select(RiverReading)
                .where(RiverReading.station_id == station_id)
                .order_by(RiverReading.timestamp.desc())
                .limit(2)
            )
            readings = result.scalars().all()

        if len(readings) < 2:
            return None

        current = readings[0]
        prev = readings[1]

        time_diff = (current.timestamp - prev.timestamp).total_seconds() / 3600.0
        if time_diff <= 0:
            return None

        return self.rule_detector.check_river_surge(
            current.water_level_m,
            prev.water_level_m,
            time_diff,
            current.danger_level_m or 10.0,
            zone_id, station_id
        )

    async def detect_all_zones(self) -> Dict[str, List[AnomalyEvent]]:
        """Jalankan deteksi anomali untuk semua zona."""
        from config import BANGLADESH_ZONES
        import asyncio

        results = {}
        tasks = {
            zone_id: self.detect_zone_anomalies(zone_id)
            for zone_id in BANGLADESH_ZONES
        }

        for zone_id, task in tasks.items():
            try:
                anomalies = await task
                if anomalies:
                    results[zone_id] = anomalies
            except Exception as e:
                logger.error(f"Error deteksi anomali zona {zone_id}: {e}")

        total = sum(len(v) for v in results.values())
        if total > 0:
            logger.info(f"🔍 Total anomali terdeteksi: {total} di {len(results)} zona")

        return results
