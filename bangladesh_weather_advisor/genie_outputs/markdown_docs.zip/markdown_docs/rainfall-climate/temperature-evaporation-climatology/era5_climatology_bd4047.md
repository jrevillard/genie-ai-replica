# ERA5 Climatology: District BD4047

## Baseline Summary
- **Mean temperature climatology:** 26.07 °C
- **Mean evaporation climatology:** -3.24 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
