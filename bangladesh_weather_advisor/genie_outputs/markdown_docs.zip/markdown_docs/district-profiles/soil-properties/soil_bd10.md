# Soil Profile: Barguna District

**Location:** Barguna (BD10)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.93
- **Clay content:** 41.10%
- **Sand content:** 14.60%
- **Silt content:** 43.20%
- **Soil organic carbon:** 13.80 g/kg
- **CEC:** 23.80 cmol/kg
- **Nitrogen:** 1.47 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
