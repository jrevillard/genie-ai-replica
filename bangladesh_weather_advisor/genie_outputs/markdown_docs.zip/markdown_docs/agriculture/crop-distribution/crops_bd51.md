# Crop Distribution: Lakshmipur District

**Location:** Lakshmipur (BD51)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 65422.90 | 5.71 | Rabi (Dec-May) |
| rice_aman | 59124.70 | 4.47 | Kharif-2 (Jul-Dec) |
| rice_aus | 16251.80 | 2.89 | Kharif-1 (Mar-Aug) |
| vegetables | 9336.40 | 10.34 | Rabi (Oct-Apr) |
| jute | 6904.80 | 2.53 | Kharif-1 (Mar-Aug) |
| oilseeds | 6455.00 | 0.88 | Rabi (Oct-Mar) |
| pulses | 6193.40 | 1.10 | Rabi (Oct-Mar) |
| spices | 4387.30 | 4.85 | Rabi/Kharif |
| maize | 3842.40 | 9.72 | Rabi (Oct-Apr) |
| potato | 3497.80 | 19.17 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
