# Soil Profile: Gopalganj District

**Location:** Gopalganj (BD35)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.46
- **Clay content:** 39.80%
- **Sand content:** 21.10%
- **Silt content:** 39.70%
- **Soil organic carbon:** 9.51 g/kg
- **CEC:** 21.90 cmol/kg
- **Nitrogen:** 1.00 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
