# Rainfall Climatology: District BD2030

## Climatology Summary
- **Mean daily climatological rainfall:** 8.01 mm
- **Median (P50) rainfall benchmark:** 4.65 mm
- **Upper percentile (P90) benchmark:** 18.68 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
