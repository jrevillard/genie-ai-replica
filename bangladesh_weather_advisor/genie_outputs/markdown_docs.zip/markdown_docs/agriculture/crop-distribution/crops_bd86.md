# Crop Distribution: Shariatpur District

**Location:** Shariatpur (BD86)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 83295.20 | 4.39 | Kharif-2 (Jul-Dec) |
| rice_boro | 78966.70 | 5.68 | Rabi (Dec-May) |
| rice_aus | 15091.10 | 2.36 | Kharif-1 (Mar-Aug) |
| jute | 11102.90 | 2.48 | Kharif-1 (Mar-Aug) |
| vegetables | 9296.20 | 12.54 | Rabi (Oct-Apr) |
| maize | 7475.80 | 8.34 | Rabi (Oct-Apr) |
| oilseeds | 5869.70 | 0.96 | Rabi (Oct-Mar) |
| potato | 5600.40 | 19.39 | Rabi (Nov-Mar) |
| pulses | 5268.40 | 1.25 | Rabi (Oct-Mar) |
| wheat | 4735.90 | 2.80 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
