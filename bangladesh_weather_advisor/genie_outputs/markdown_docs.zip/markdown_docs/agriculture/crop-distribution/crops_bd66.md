# Crop Distribution: Mymensingh District

**Location:** Mymensingh (BD66)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 103047.40 | 3.95 | Kharif-2 (Jul-Dec) |
| rice_boro | 72845.50 | 5.81 | Rabi (Dec-May) |
| rice_aus | 14239.40 | 2.55 | Kharif-1 (Mar-Aug) |
| jute | 12660.80 | 2.61 | Kharif-1 (Mar-Aug) |
| vegetables | 8178.60 | 12.74 | Rabi (Oct-Apr) |
| maize | 6783.40 | 9.51 | Rabi (Oct-Apr) |
| pulses | 6360.30 | 1.12 | Rabi (Oct-Mar) |
| oilseeds | 5895.30 | 1.09 | Rabi (Oct-Mar) |
| potato | 5570.80 | 18.43 | Rabi (Nov-Mar) |
| spices | 3570.10 | 4.24 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
