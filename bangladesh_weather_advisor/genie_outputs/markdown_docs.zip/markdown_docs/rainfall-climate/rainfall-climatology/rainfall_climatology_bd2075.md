# Rainfall Climatology: District BD2075

## Climatology Summary
- **Mean daily climatological rainfall:** 8.23 mm
- **Median (P50) rainfall benchmark:** 5.35 mm
- **Upper percentile (P90) benchmark:** 18.15 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
