# Crop Distribution: Sherpur District

**Location:** Sherpur (BD89)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 82578.90 | 3.44 | Kharif-2 (Jul-Dec) |
| rice_boro | 68833.50 | 4.92 | Rabi (Dec-May) |
| rice_aus | 19349.50 | 2.52 | Kharif-1 (Mar-Aug) |
| jute | 9837.10 | 2.58 | Kharif-1 (Mar-Aug) |
| pulses | 6643.90 | 1.15 | Rabi (Oct-Mar) |
| vegetables | 6364.60 | 12.85 | Rabi (Oct-Apr) |
| potato | 5716.80 | 22.13 | Rabi (Nov-Mar) |
| oilseeds | 5426.10 | 0.86 | Rabi (Oct-Mar) |
| maize | 5267.90 | 8.37 | Rabi (Oct-Apr) |
| wheat | 3820.60 | 3.51 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
