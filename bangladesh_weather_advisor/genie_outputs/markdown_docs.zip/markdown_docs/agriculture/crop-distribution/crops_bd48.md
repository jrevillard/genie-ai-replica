# Crop Distribution: Kishoreganj District

**Location:** Kishoreganj (BD48)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 68037.90 | 3.89 | Kharif-2 (Jul-Dec) |
| rice_boro | 55100.90 | 5.24 | Rabi (Dec-May) |
| rice_aus | 17139.30 | 2.47 | Kharif-1 (Mar-Aug) |
| jute | 14789.60 | 2.23 | Kharif-1 (Mar-Aug) |
| maize | 7974.70 | 8.66 | Rabi (Oct-Apr) |
| vegetables | 7022.20 | 10.77 | Rabi (Oct-Apr) |
| potato | 5882.00 | 17.68 | Rabi (Nov-Mar) |
| pulses | 5750.70 | 1.18 | Rabi (Oct-Mar) |
| oilseeds | 5131.60 | 1.02 | Rabi (Oct-Mar) |
| spices | 4601.00 | 4.75 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
