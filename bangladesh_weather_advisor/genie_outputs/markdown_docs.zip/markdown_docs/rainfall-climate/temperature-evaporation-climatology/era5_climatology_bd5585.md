# ERA5 Climatology: District BD5585

## Baseline Summary
- **Mean temperature climatology:** 24.69 °C
- **Mean evaporation climatology:** -2.70 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
