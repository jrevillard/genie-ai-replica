# Soil Profile: Bagerhat District

**Location:** Bagerhat (BD01)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.38
- **Clay content:** 29.70%
- **Sand content:** 31.10%
- **Silt content:** 39.00%
- **Soil organic carbon:** 9.98 g/kg
- **CEC:** 16.80 cmol/kg
- **Nitrogen:** 1.00 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
