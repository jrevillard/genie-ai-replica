# Crop Distribution: Dinajpur District

**Location:** Dinajpur (BD28)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 75459.90 | 5.10 | Rabi (Dec-May) |
| rice_aman | 74204.00 | 3.91 | Kharif-2 (Jul-Dec) |
| rice_aus | 18192.70 | 2.76 | Kharif-1 (Mar-Aug) |
| potato | 14239.90 | 18.62 | Rabi (Nov-Mar) |
| maize | 11673.90 | 9.57 | Rabi (Oct-Apr) |
| vegetables | 9279.40 | 11.13 | Rabi (Oct-Apr) |
| wheat | 6711.60 | 2.99 | Rabi (Nov-Mar) |
| jute | 6010.40 | 2.40 | Kharif-1 (Mar-Aug) |
| oilseeds | 5874.70 | 0.96 | Rabi (Oct-Mar) |
| pulses | 4956.60 | 1.07 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
