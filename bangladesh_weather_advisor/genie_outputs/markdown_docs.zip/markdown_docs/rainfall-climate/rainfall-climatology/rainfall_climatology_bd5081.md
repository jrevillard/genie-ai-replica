# Rainfall Climatology: District BD5081

## Climatology Summary
- **Mean daily climatological rainfall:** 4.11 mm
- **Median (P50) rainfall benchmark:** 2.40 mm
- **Upper percentile (P90) benchmark:** 9.57 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
