# Rainfall Climatology: District BD4589

## Climatology Summary
- **Mean daily climatological rainfall:** 6.54 mm
- **Median (P50) rainfall benchmark:** 3.94 mm
- **Upper percentile (P90) benchmark:** 15.11 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
