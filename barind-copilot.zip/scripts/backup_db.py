"""
Backup database otomatis.
Jalankan via cron atau scheduler:
  0 2 * * * /var/www/bfews/venv/bin/python /var/www/bfews/scripts/backup_db.py

Backup disimpan di /var/www/bfews/backups/ dengan nama tanggal.
Otomatis hapus backup lebih dari 30 hari.
"""

import os
import sys
import shutil
import gzip
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

DB_PATH     = Path("bfews.db")
BACKUP_DIR  = Path("backups")
KEEP_DAYS   = 30


def backup():
    if not DB_PATH.exists():
        print(f"Database not found: {DB_PATH}")
        return False

    BACKUP_DIR.mkdir(exist_ok=True)

    # Nama file backup dengan timestamp
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup_file = BACKUP_DIR / f"bfews_{ts}.db.gz"

    # Compress dan simpan
    with open(DB_PATH, "rb") as f_in:
        with gzip.open(backup_file, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)

    size_kb = backup_file.stat().st_size / 1024
    print(f"✅ Backup created: {backup_file} ({size_kb:.1f} KB)")

    # Hapus backup lama
    cutoff = datetime.utcnow() - timedelta(days=KEEP_DAYS)
    deleted = 0
    for old_file in BACKUP_DIR.glob("bfews_*.db.gz"):
        try:
            ts_str = old_file.stem.replace("bfews_", "").replace(".db", "")
            file_date = datetime.strptime(ts_str, "%Y%m%d_%H%M%S")
            if file_date < cutoff:
                old_file.unlink()
                deleted += 1
        except Exception:
            pass

    if deleted:
        print(f"🗑️  Deleted {deleted} old backup(s)")

    # List semua backup
    backups = sorted(BACKUP_DIR.glob("bfews_*.db.gz"))
    print(f"📦 Total backups: {len(backups)}")
    return True


if __name__ == "__main__":
    success = backup()
    sys.exit(0 if success else 1)
