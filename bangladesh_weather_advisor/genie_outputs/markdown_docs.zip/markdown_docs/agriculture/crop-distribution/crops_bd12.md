# Crop Distribution: Bogura District

**Location:** Bogura (BD12)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 71417.30 | 3.45 | Kharif-2 (Jul-Dec) |
| rice_boro | 53587.50 | 5.35 | Rabi (Dec-May) |
| rice_aus | 11956.30 | 2.33 | Kharif-1 (Mar-Aug) |
| wheat | 10812.60 | 3.28 | Rabi (Nov-Mar) |
| maize | 10025.80 | 8.86 | Rabi (Oct-Apr) |
| potato | 10009.70 | 22.98 | Rabi (Nov-Mar) |
| vegetables | 7115.10 | 12.33 | Rabi (Oct-Apr) |
| pulses | 6849.00 | 1.24 | Rabi (Oct-Mar) |
| oilseeds | 6330.80 | 0.90 | Rabi (Oct-Mar) |
| jute | 5576.30 | 2.57 | Kharif-1 (Mar-Aug) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
