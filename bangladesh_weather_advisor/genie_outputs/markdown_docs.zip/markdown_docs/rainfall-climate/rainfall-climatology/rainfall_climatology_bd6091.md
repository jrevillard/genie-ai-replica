# Rainfall Climatology: District BD6091

## Climatology Summary
- **Mean daily climatological rainfall:** 11.70 mm
- **Median (P50) rainfall benchmark:** 7.80 mm
- **Upper percentile (P90) benchmark:** 25.90 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
