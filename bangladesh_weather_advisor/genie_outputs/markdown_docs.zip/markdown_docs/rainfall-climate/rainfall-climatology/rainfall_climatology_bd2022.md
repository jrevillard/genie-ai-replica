# Rainfall Climatology: District BD2022

## Climatology Summary
- **Mean daily climatological rainfall:** 9.93 mm
- **Median (P50) rainfall benchmark:** 6.06 mm
- **Upper percentile (P90) benchmark:** 22.55 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
