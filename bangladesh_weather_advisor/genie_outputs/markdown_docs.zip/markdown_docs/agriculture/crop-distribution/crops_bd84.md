# Crop Distribution: Rangamati District

**Location:** Rangamati (BD84)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 63408.80 | 4.46 | Rabi (Dec-May) |
| rice_aman | 57157.40 | 4.27 | Kharif-2 (Jul-Dec) |
| rice_aus | 13307.80 | 2.50 | Kharif-1 (Mar-Aug) |
| vegetables | 7620.70 | 12.81 | Rabi (Oct-Apr) |
| jute | 7569.20 | 2.34 | Kharif-1 (Mar-Aug) |
| oilseeds | 5293.20 | 1.02 | Rabi (Oct-Mar) |
| pulses | 5273.70 | 1.00 | Rabi (Oct-Mar) |
| spices | 4402.90 | 3.99 | Rabi/Kharif |
| maize | 4114.70 | 7.84 | Rabi (Oct-Apr) |
| potato | 2415.70 | 20.98 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
