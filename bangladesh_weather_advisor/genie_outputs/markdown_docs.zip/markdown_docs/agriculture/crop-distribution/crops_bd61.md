# Crop Distribution: Moulvibazar District

**Location:** Moulvibazar (BD61)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 76391.50 | 3.82 | Kharif-2 (Jul-Dec) |
| rice_boro | 57762.70 | 4.71 | Rabi (Dec-May) |
| rice_aus | 15536.70 | 2.43 | Kharif-1 (Mar-Aug) |
| vegetables | 7641.60 | 12.05 | Rabi (Oct-Apr) |
| pulses | 6860.80 | 1.25 | Rabi (Oct-Mar) |
| oilseeds | 6389.40 | 1.01 | Rabi (Oct-Mar) |
| spices | 3719.10 | 4.36 | Rabi/Kharif |
| jute | 3140.10 | 2.63 | Kharif-1 (Mar-Aug) |
| maize | 2347.00 | 8.99 | Rabi (Oct-Apr) |
| potato | 2160.70 | 20.36 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
