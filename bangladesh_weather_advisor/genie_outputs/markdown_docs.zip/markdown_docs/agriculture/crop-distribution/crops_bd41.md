# Crop Distribution: Jessore District

**Location:** Jessore (BD41)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 77984.20 | 3.93 | Kharif-2 (Jul-Dec) |
| rice_boro | 65118.00 | 4.39 | Rabi (Dec-May) |
| rice_aus | 18725.60 | 3.03 | Kharif-1 (Mar-Aug) |
| jute | 7993.20 | 2.30 | Kharif-1 (Mar-Aug) |
| vegetables | 6773.40 | 10.58 | Rabi (Oct-Apr) |
| pulses | 6031.30 | 1.20 | Rabi (Oct-Mar) |
| spices | 4666.60 | 5.13 | Rabi/Kharif |
| oilseeds | 4389.00 | 0.92 | Rabi (Oct-Mar) |
| potato | 3272.40 | 22.45 | Rabi (Nov-Mar) |
| maize | 1927.90 | 9.43 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
