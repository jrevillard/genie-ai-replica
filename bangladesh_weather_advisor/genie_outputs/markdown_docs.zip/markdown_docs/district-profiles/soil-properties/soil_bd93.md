# Soil Profile: Tangail District

**Location:** Tangail (BD93)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 5.91
- **Clay content:** 32.80%
- **Sand content:** 27.90%
- **Silt content:** 38.50%
- **Soil organic carbon:** 11.55 g/kg
- **CEC:** 17.20 cmol/kg
- **Nitrogen:** 1.22 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
