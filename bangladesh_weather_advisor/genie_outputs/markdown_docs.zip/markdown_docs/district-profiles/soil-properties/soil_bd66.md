# Soil Profile: Mymensingh District

**Location:** Mymensingh (BD66)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 6.27
- **Clay content:** 31.60%
- **Sand content:** 28.30%
- **Silt content:** 38.80%
- **Soil organic carbon:** 11.11 g/kg
- **CEC:** 17.80 cmol/kg
- **Nitrogen:** 1.24 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
