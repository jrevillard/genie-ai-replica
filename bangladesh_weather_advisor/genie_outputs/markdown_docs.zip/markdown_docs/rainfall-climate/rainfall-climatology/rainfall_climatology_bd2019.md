# Rainfall Climatology: District BD2019

## Climatology Summary
- **Mean daily climatological rainfall:** 6.43 mm
- **Median (P50) rainfall benchmark:** 3.88 mm
- **Upper percentile (P90) benchmark:** 14.67 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
