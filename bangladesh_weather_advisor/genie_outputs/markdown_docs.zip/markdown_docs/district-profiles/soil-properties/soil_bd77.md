# Soil Profile: Nawabganj District

**Location:** Nawabganj (BD77)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.25
- **Clay content:** 37.00%
- **Sand content:** 22.20%
- **Silt content:** 40.60%
- **Soil organic carbon:** 9.60 g/kg
- **CEC:** 21.80 cmol/kg
- **Nitrogen:** 0.99 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
