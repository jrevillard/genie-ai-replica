# Soil Profile: Rajbari District

**Location:** Rajbari (BD82)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 6.99
- **Clay content:** 39.20%
- **Sand content:** 21.90%
- **Silt content:** 41.20%
- **Soil organic carbon:** 9.32 g/kg
- **CEC:** 22.10 cmol/kg
- **Nitrogen:** 1.04 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
