"""
Mesin Penilaian Risiko — menghitung skor risiko per zona
dan menetapkan level peringatan (hijau/kuning/merah).

Skor risiko dihitung dari:
1. Kondisi cuaca saat ini (30%)
2. Level sungai saat ini (30%)
3. Prediksi 24 jam ke depan (25%)
4. Anomali yang terdeteksi (15%)
5. Multiplier zona (faktor historis kerawanan)
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from loguru import logger

from config import (
    AlertLevel, BANGLADESH_ZONES,
    RIVER_RISE_WARNING_M, RIVER_RISE_DANGER_M,
    RAINFALL_WARNING_MM, RAINFALL_DANGER_MM,
    WIND_WARNING_KMH, WIND_DANGER_KMH,
)
from data.storage.database import (
    AsyncSessionLocal, AlertRecord,
    get_latest_weather, get_latest_river, get_active_alert
)
from ml.anomaly.detector import AnomalyEvent
from sqlalchemy.future import select


@dataclass
class RiskAssessment:
    """Hasil penilaian risiko untuk satu zona."""
    zone_id:        str
    assessed_at:    datetime
    risk_score:     float          # 0.0 – 1.0
    alert_level:    str            # green/yellow/red
    prev_level:     Optional[str]
    level_changed:  bool

    # Komponen skor
    weather_score:  float
    river_score:    float
    forecast_score: float
    anomaly_score:  float

    # Detail
    reasons:        List[str]      # alasan dalam Bahasa Inggris
    reasons_bn:     List[str]      # alasan dalam Bahasa Bengali
    top_anomalies:  List[AnomalyEvent]

    # Data mentah untuk referensi
    current_rainfall_mm: float
    current_wind_kmh:    float
    max_river_level_pct: float     # % dari danger level
    flood_prob_24h:      float


class RiskEngine:
    """
    Mesin penilaian risiko utama.
    Menggabungkan semua sinyal untuk menghasilkan skor risiko final.
    """

    # Bobot komponen
    WEIGHT_WEATHER  = 0.25
    WEIGHT_RIVER    = 0.30
    WEIGHT_FORECAST = 0.30
    WEIGHT_ANOMALY  = 0.15

    # Threshold level peringatan
    YELLOW_THRESHOLD = 0.35
    RED_THRESHOLD    = 0.65

    def _score_weather(self, rainfall_1h: float, rainfall_6h: float,
                       wind_speed: float, pressure: float) -> Tuple[float, List[str], List[str]]:
        """
        Hitung skor risiko dari kondisi cuaca.
        Returns: (score 0-1, reasons_en, reasons_bn)
        """
        score = 0.0
        reasons_en = []
        reasons_bn = []

        # Curah hujan 1 jam
        if rainfall_1h >= 50:
            score = max(score, 0.9)
            reasons_en.append(f"Extreme rainfall: {rainfall_1h:.0f}mm/h")
            reasons_bn.append(f"অতি ভারী বৃষ্টি: ঘণ্টায় {rainfall_1h:.0f} মিমি")
        elif rainfall_1h >= 25:
            score = max(score, 0.7)
            reasons_en.append(f"Heavy rainfall: {rainfall_1h:.0f}mm/h")
            reasons_bn.append(f"ভারী বৃষ্টি: ঘণ্টায় {rainfall_1h:.0f} মিমি")
        elif rainfall_1h >= 10:
            score = max(score, 0.4)
            reasons_en.append(f"Moderate rainfall: {rainfall_1h:.0f}mm/h")
            reasons_bn.append(f"মাঝারি বৃষ্টি: ঘণ্টায় {rainfall_1h:.0f} মিমি")

        # Curah hujan 6 jam
        if rainfall_6h >= RAINFALL_DANGER_MM:
            score = max(score, 0.85)
            reasons_en.append(f"Dangerous 6h rainfall: {rainfall_6h:.0f}mm")
            reasons_bn.append(f"বিপজ্জনক ৬ ঘণ্টার বৃষ্টি: {rainfall_6h:.0f} মিমি")
        elif rainfall_6h >= RAINFALL_WARNING_MM:
            score = max(score, 0.55)
            reasons_en.append(f"High 6h rainfall: {rainfall_6h:.0f}mm")
            reasons_bn.append(f"বেশি ৬ ঘণ্টার বৃষ্টি: {rainfall_6h:.0f} মিমি")

        # Kecepatan angin
        if wind_speed >= WIND_DANGER_KMH:
            score = max(score, 0.85)
            reasons_en.append(f"Dangerous wind: {wind_speed:.0f}km/h")
            reasons_bn.append(f"বিপজ্জনক বাতাস: {wind_speed:.0f} কিমি/ঘণ্টা")
        elif wind_speed >= WIND_WARNING_KMH:
            score = max(score, 0.5)
            reasons_en.append(f"Strong wind: {wind_speed:.0f}km/h")
            reasons_bn.append(f"তীব্র বাতাস: {wind_speed:.0f} কিমি/ঘণ্টা")

        # Tekanan rendah (tanda siklon)
        if pressure and pressure < 980:
            score = max(score, 0.8)
            reasons_en.append(f"Very low pressure: {pressure:.0f}hPa (cyclone risk)")
            reasons_bn.append(f"অতি কম বায়ুচাপ: {pressure:.0f} hPa (ঘূর্ণিঝড়ের ঝুঁকি)")
        elif pressure and pressure < 995:
            score = max(score, 0.5)
            reasons_en.append(f"Low pressure: {pressure:.0f}hPa")
            reasons_bn.append(f"কম বায়ুচাপ: {pressure:.0f} hPa")

        return score, reasons_en, reasons_bn

    def _score_river(self, river_readings: List) -> Tuple[float, float, List[str], List[str]]:
        """
        Hitung skor risiko dari level sungai.
        Returns: (score, max_level_pct, reasons_en, reasons_bn)
        """
        if not river_readings:
            return 0.0, 0.0, [], []

        score = 0.0
        max_level_pct = 0.0
        reasons_en = []
        reasons_bn = []

        for reading in river_readings:
            if not reading or not reading.water_level_m:
                continue

            danger = reading.danger_level_m or 10.0
            level_pct = reading.water_level_m / danger
            max_level_pct = max(max_level_pct, level_pct)

            change = reading.change_6h_m or 0

            # Skor berdasarkan % dari danger level
            if level_pct >= 1.0:
                score = max(score, 1.0)
                reasons_en.append(f"River ABOVE danger level ({level_pct:.0%})")
                reasons_bn.append(f"নদী বিপদসীমার উপরে ({level_pct:.0%})")
            elif level_pct >= 0.85:
                score = max(score, 0.8)
                reasons_en.append(f"River near danger level ({level_pct:.0%})")
                reasons_bn.append(f"নদী বিপদসীমার কাছে ({level_pct:.0%})")
            elif level_pct >= 0.70:
                score = max(score, 0.5)
                reasons_en.append(f"River level elevated ({level_pct:.0%})")
                reasons_bn.append(f"নদীর পানি বেশি ({level_pct:.0%})")

            # Skor berdasarkan laju kenaikan
            if change >= RIVER_RISE_DANGER_M:
                score = max(score, 0.85)
                reasons_en.append(f"Rapid river rise: +{change:.2f}m in 6h")
                reasons_bn.append(f"দ্রুত পানি বৃদ্ধি: ৬ ঘণ্টায় +{change:.2f} মিটার")
            elif change >= RIVER_RISE_WARNING_M:
                score = max(score, 0.55)
                reasons_en.append(f"River rising: +{change:.2f}m in 6h")
                reasons_bn.append(f"পানি বাড়ছে: ৬ ঘণ্টায় +{change:.2f} মিটার")

        return score, max_level_pct, reasons_en, reasons_bn

    def _score_forecast(self, forecast_data: Optional[Dict]) -> Tuple[float, float, List[str], List[str]]:
        """
        Hitung skor risiko dari prediksi 24 jam ke depan.
        Returns: (score, flood_prob_24h, reasons_en, reasons_bn)
        """
        if not forecast_data:
            return 0.0, 0.0, [], []

        score = 0.0
        reasons_en = []
        reasons_bn = []

        horizons = forecast_data.get("horizons", {})
        flood_prob_24h = 0.0

        for h, data in horizons.items():
            flood_prob = data.get("flood_prob", 0)
            rainfall = data.get("rainfall_mm", 0)
            flood_prob_24h = max(flood_prob_24h, flood_prob)

            if flood_prob >= 0.7:
                score = max(score, 0.8)
                reasons_en.append(f"High flood probability in {h}h: {flood_prob:.0%}")
                reasons_bn.append(f"{h} ঘণ্টায় বন্যার সম্ভাবনা বেশি: {flood_prob:.0%}")
            elif flood_prob >= 0.4:
                score = max(score, 0.5)
                reasons_en.append(f"Moderate flood probability in {h}h: {flood_prob:.0%}")
                reasons_bn.append(f"{h} ঘণ্টায় বন্যার মাঝারি সম্ভাবনা: {flood_prob:.0%}")

            if rainfall >= 80:
                score = max(score, 0.7)
                reasons_en.append(f"Heavy rain forecast in {h}h: {rainfall:.0f}mm")
                reasons_bn.append(f"{h} ঘণ্টায় ভারী বৃষ্টির পূর্বাভাস: {rainfall:.0f} মিমি")

        return score, flood_prob_24h, reasons_en, reasons_bn

    def _score_anomalies(self, anomalies: List[AnomalyEvent]) -> Tuple[float, List[str], List[str]]:
        """Hitung skor dari anomali yang terdeteksi."""
        if not anomalies:
            return 0.0, [], []

        max_severity = max(a.severity for a in anomalies)
        reasons_en = [a.description for a in anomalies[:3]]
        reasons_bn = [a.description_bn for a in anomalies[:3]]

        return max_severity, reasons_en, reasons_bn

    def _determine_level(self, score: float) -> str:
        """Tentukan level peringatan berdasarkan skor."""
        if score >= self.RED_THRESHOLD:
            return AlertLevel.RED
        elif score >= self.YELLOW_THRESHOLD:
            return AlertLevel.YELLOW
        else:
            return AlertLevel.GREEN

    async def assess_zone(self, zone_id: str,
                          forecast_data: Optional[Dict] = None,
                          anomalies: Optional[List[AnomalyEvent]] = None) -> RiskAssessment:
        """
        Lakukan penilaian risiko lengkap untuk satu zona.
        """
        zone = BANGLADESH_ZONES.get(zone_id)
        if not zone:
            raise ValueError(f"Zone {zone_id} tidak ditemukan")

        now = datetime.utcnow()
        all_reasons_en = []
        all_reasons_bn = []

        async with AsyncSessionLocal() as db:
            # Ambil data cuaca terkini
            weather = await get_latest_weather(zone_id, db)

            # Ambil data sungai terkini untuk semua stasiun
            river_readings = []
            for station_id in zone.river_stations:
                reading = await get_latest_river(station_id, db)
                if reading:
                    river_readings.append(reading)

            # Ambil level peringatan sebelumnya
            prev_alert = await get_active_alert(zone_id, db)
            prev_level = prev_alert.level if prev_alert else AlertLevel.GREEN

            # Ambil forecast terbaru dari database jika tidak dikirim
            if forecast_data is None:
                from data.storage.database import ForecastRecord
                from sqlalchemy.future import select as sa_select
                fc_horizons = {}
                for h in [6, 12, 24]:
                    result = await db.execute(
                        sa_select(ForecastRecord)
                        .where(ForecastRecord.zone_id == zone_id,
                               ForecastRecord.horizon_hours == h)
                        .order_by(ForecastRecord.created_at.desc())
                        .limit(1)
                    )
                    fc = result.scalar_one_or_none()
                    if fc:
                        fc_horizons[h] = {
                            "flood_prob":   fc.flood_probability or 0,
                            "rainfall_mm":  fc.predicted_rainfall_mm or 0,
                        }
                if fc_horizons:
                    forecast_data = {"horizons": fc_horizons}

        # ── Hitung skor per komponen ──
        weather_score = 0.0
        if weather:
            weather_score, r_en, r_bn = self._score_weather(
                weather.rainfall_1h or 0,
                weather.rainfall_6h or 0,
                weather.wind_speed or 0,
                weather.pressure,
            )
            all_reasons_en.extend(r_en)
            all_reasons_bn.extend(r_bn)

        river_score, max_level_pct, r_en, r_bn = self._score_river(river_readings)
        all_reasons_en.extend(r_en)
        all_reasons_bn.extend(r_bn)

        forecast_score, flood_prob_24h, r_en, r_bn = self._score_forecast(forecast_data)
        all_reasons_en.extend(r_en)
        all_reasons_bn.extend(r_bn)

        anomaly_score = 0.0
        top_anomalies = anomalies or []
        if anomalies:
            anomaly_score, r_en, r_bn = self._score_anomalies(anomalies)
            all_reasons_en.extend(r_en)
            all_reasons_bn.extend(r_bn)

        # ── Hitung skor final dengan bobot ──
        raw_score = (
            weather_score  * self.WEIGHT_WEATHER +
            river_score    * self.WEIGHT_RIVER +
            forecast_score * self.WEIGHT_FORECAST +
            anomaly_score  * self.WEIGHT_ANOMALY
        )

        # Terapkan multiplier zona (zona rawan dapat skor lebih tinggi)
        final_score = min(1.0, raw_score * zone.risk_multiplier)

        # Tentukan level
        alert_level = self._determine_level(final_score)
        level_changed = alert_level != prev_level

        assessment = RiskAssessment(
            zone_id=zone_id,
            assessed_at=now,
            risk_score=round(final_score, 4),
            alert_level=alert_level,
            prev_level=prev_level,
            level_changed=level_changed,
            weather_score=round(weather_score, 4),
            river_score=round(river_score, 4),
            forecast_score=round(forecast_score, 4),
            anomaly_score=round(anomaly_score, 4),
            reasons=all_reasons_en[:5],
            reasons_bn=all_reasons_bn[:5],
            top_anomalies=top_anomalies[:3],
            current_rainfall_mm=weather.rainfall_6h if weather else 0,
            current_wind_kmh=weather.wind_speed if weather else 0,
            max_river_level_pct=max_level_pct,
            flood_prob_24h=flood_prob_24h,
        )

        # Simpan alert ke database jika level berubah atau merah/kuning
        if level_changed or alert_level in [AlertLevel.YELLOW, AlertLevel.RED]:
            await self._save_alert(assessment)

        if level_changed:
            logger.warning(f"🚨 LEVEL BERUBAH zona {zone_id}: "
                           f"{prev_level.upper()} → {alert_level.upper()} "
                           f"(skor: {final_score:.2f})")
        else:
            logger.debug(f"📊 Risiko {zone_id}: {alert_level} (skor: {final_score:.2f})")

        return assessment

    async def _save_alert(self, assessment: RiskAssessment):
        """Simpan atau update record alert di database."""
        async with AsyncSessionLocal() as db:
            # Nonaktifkan alert lama
            result = await db.execute(
                select(AlertRecord)
                .where(AlertRecord.zone_id == assessment.zone_id,
                       AlertRecord.is_active == True)
            )
            old_alerts = result.scalars().all()
            for old in old_alerts:
                old.is_active = False
                old.resolved_at = datetime.utcnow()

            # Buat alert baru
            new_alert = AlertRecord(
                zone_id    = assessment.zone_id,
                issued_at  = assessment.assessed_at,
                level      = assessment.alert_level,
                prev_level = assessment.prev_level,
                risk_score = assessment.risk_score,
                reason     = "; ".join(assessment.reasons),
                is_active  = True,
            )
            db.add(new_alert)
            await db.commit()

    async def assess_all_zones(self,
                                forecasts: Optional[Dict] = None,
                                anomalies: Optional[Dict] = None) -> Dict[str, RiskAssessment]:
        """Nilai risiko semua zona."""
        results = {}
        for zone_id in BANGLADESH_ZONES:
            try:
                fc = forecasts.get(zone_id) if forecasts else None
                an = anomalies.get(zone_id) if anomalies else None
                assessment = await self.assess_zone(zone_id, fc, an)
                results[zone_id] = assessment
            except Exception as e:
                logger.error(f"Error penilaian risiko zona {zone_id}: {e}")

        # Ringkasan
        levels = {AlertLevel.RED: 0, AlertLevel.YELLOW: 0, AlertLevel.GREEN: 0}
        for a in results.values():
            levels[a.alert_level] = levels.get(a.alert_level, 0) + 1

        logger.info(f"📊 Penilaian risiko selesai: "
                    f"🔴 {levels[AlertLevel.RED]} merah, "
                    f"🟡 {levels[AlertLevel.YELLOW]} kuning, "
                    f"🟢 {levels[AlertLevel.GREEN]} hijau")
        return results
