# Crop Distribution: Manikganj District

**Location:** Manikganj (BD59)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 72422.10 | 4.09 | Kharif-2 (Jul-Dec) |
| rice_boro | 67826.50 | 4.68 | Rabi (Dec-May) |
| jute | 15379.20 | 2.44 | Kharif-1 (Mar-Aug) |
| rice_aus | 12694.80 | 2.73 | Kharif-1 (Mar-Aug) |
| vegetables | 9299.60 | 11.41 | Rabi (Oct-Apr) |
| maize | 6668.80 | 7.30 | Rabi (Oct-Apr) |
| oilseeds | 6504.50 | 1.12 | Rabi (Oct-Mar) |
| pulses | 5592.20 | 1.03 | Rabi (Oct-Mar) |
| potato | 5099.20 | 22.53 | Rabi (Nov-Mar) |
| spices | 4482.70 | 4.60 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
