# Crop Distribution: Kushtia District

**Location:** Kushtia (BD57)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 82885.60 | 4.70 | Rabi (Dec-May) |
| rice_aman | 77574.80 | 3.74 | Kharif-2 (Jul-Dec) |
| rice_aus | 17647.20 | 2.94 | Kharif-1 (Mar-Aug) |
| jute | 9120.20 | 2.21 | Kharif-1 (Mar-Aug) |
| vegetables | 6412.40 | 12.15 | Rabi (Oct-Apr) |
| oilseeds | 5761.90 | 0.99 | Rabi (Oct-Mar) |
| pulses | 5303.30 | 0.94 | Rabi (Oct-Mar) |
| spices | 3835.50 | 4.52 | Rabi/Kharif |
| potato | 3230.00 | 20.52 | Rabi (Nov-Mar) |
| maize | 2595.90 | 9.63 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
