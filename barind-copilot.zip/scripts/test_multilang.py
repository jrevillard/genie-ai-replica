"""Test multi-language chatbot responses."""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from loguru import logger
logger.remove()
logger.add(sys.stderr, level="WARNING")

TESTS = [
    ("selamat siang",                    "Indonesian greeting"),
    ("lokasi mana bahaya?",              "Indonesian — which area dangerous"),
    ("bonjour, ça va?",                  "French greeting"),
    ("مرحبا",                            "Arabic greeting"),
    ("আজকে কি বন্যা হবে?",              "Bengali — will it flood today"),
    ("Is Sylhet safe right now?",        "English with location"),
    ("Sylhet mein barish kaisi hai?",    "Hindi/Urdu — how is rain in Sylhet"),
    ("今天洪水严重吗？",                   "Chinese — is flooding serious today"),
]

async def main():
    from chatbot.nlp.groq_client import groq_client

    if not groq_client.available:
        print("❌ GROQ_API_KEY not set")
        return

    print("=" * 60)
    print("Multi-Language Chatbot Test")
    print("=" * 60)

    for msg, label in TESTS:
        print(f"\n[{label}]")
        print(f"User: {msg}")
        r = await groq_client.generate_response(
            user_message=msg,
            conversation_history=[],
            context_data={},
            lang="auto",
            zone_id=None,
        )
        print(f"Bot:  {r[:250] if r else '❌ FAILED'}")

asyncio.run(main())
