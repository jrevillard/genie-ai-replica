# Soil Profile: Joypurhat District

**Location:** Joypurhat (BD43)

## Soil Characteristics
- **Soil region:** Barind_Tract
- **Soil pH:** 6.22
- **Clay content:** 45.90%
- **Sand content:** 18.80%
- **Silt content:** 36.70%
- **Soil organic carbon:** 7.78 g/kg
- **CEC:** 19.70 cmol/kg
- **Nitrogen:** 0.83 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
