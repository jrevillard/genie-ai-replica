# Soil Profile: Moulvibazar District

**Location:** Moulvibazar (BD61)

## Soil Characteristics
- **Soil region:** Sylhet_Basin
- **Soil pH:** 4.94
- **Clay content:** 30.80%
- **Sand content:** 19.70%
- **Silt content:** 48.70%
- **Soil organic carbon:** 18.79 g/kg
- **CEC:** 20.80 cmol/kg
- **Nitrogen:** 1.77 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
