# Crop Distribution: Kurigram District

**Location:** Kurigram (BD49)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 77282.90 | 4.20 | Kharif-2 (Jul-Dec) |
| rice_boro | 59271.60 | 5.44 | Rabi (Dec-May) |
| rice_aus | 15210.40 | 2.74 | Kharif-1 (Mar-Aug) |
| potato | 12152.30 | 17.94 | Rabi (Nov-Mar) |
| maize | 11400.20 | 9.13 | Rabi (Oct-Apr) |
| vegetables | 8667.10 | 10.67 | Rabi (Oct-Apr) |
| wheat | 8057.60 | 3.32 | Rabi (Nov-Mar) |
| pulses | 6468.10 | 1.10 | Rabi (Oct-Mar) |
| jute | 5214.80 | 2.43 | Kharif-1 (Mar-Aug) |
| oilseeds | 4515.50 | 1.00 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
