# Soil Profile: Narayanganj District

**Location:** Narayanganj (BD68)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.66
- **Clay content:** 30.20%
- **Sand content:** 30.80%
- **Silt content:** 38.30%
- **Soil organic carbon:** 10.36 g/kg
- **CEC:** 16.50 cmol/kg
- **Nitrogen:** 1.04 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
