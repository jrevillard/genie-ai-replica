"""Test GloFAS + Ensemble Forecast."""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

async def main():
    print("=" * 55)
    print("TEST: GloFAS + Ensemble Forecast")
    print("=" * 55)

    # 1. GloFAS API
    print("\n[1] GloFAS Flood API")
    from data.ingestion.river_collector import fetch_glofas_discharge, discharge_to_level
    data = await fetch_glofas_discharge(24.8949, 91.8687, past_days=7, forecast_days=14)
    if data:
        hist = data["hist_discharge"]
        fc = data["fc_discharge"]
        level = discharge_to_level(hist[-1], "surma_sylhet")
        print(f"  OK: Q={hist[-1]:.1f} m3/s -> level={level:.2f}m (danger=10.5m)")
        print(f"  Forecast: D+1={fc[0]:.1f}, D+7={fc[6]:.1f} m3/s")
    else:
        print("  FAILED - GloFAS API not reachable")

    # 2. Holt-Winters
    print("\n[2] Holt-Winters Exponential Smoothing")
    from ml.forecasting.ensemble_forecast import HoltWintersForecaster
    hw = HoltWintersForecaster()
    sample = [100, 105, 110, 108, 115, 120, 118, 125, 130, 128, 135, 140, 138, 145, 150]
    hw_fc = hw.forecast(sample, [1, 3, 7])
    for h in [1, 3, 7]:
        v = hw_fc[h]
        print(f"  D+{h}: {v['value']:.1f} m3/s  conf={v['confidence']:.2f}  "
              f"range=[{v['lower']:.1f}, {v['upper']:.1f}]")

    # 3. AR Model
    print("\n[3] AR(7) AutoRegressive")
    from ml.forecasting.ensemble_forecast import ARIMAForecaster
    ar = ARIMAForecaster(p=7)
    ar_fc = ar.forecast(sample, [1, 3, 7])
    for h in [1, 3, 7]:
        v = ar_fc[h]
        print(f"  D+{h}: {v['value']:.1f} m3/s  conf={v['confidence']:.2f}  "
              f"range=[{v['lower']:.1f}, {v['upper']:.1f}]")

    # 4. Full Ensemble
    print("\n[4] Full Ensemble (HW + AR + GloFAS)")
    from data.storage.database import init_db
    await init_db()
    from data.ingestion.river_collector import collect_river_for_station
    await collect_river_for_station("surma_sylhet", "SYL-01")

    from ml.forecasting.ensemble_forecast import ensemble_forecaster
    result = await ensemble_forecaster.forecast_station("surma_sylhet", "SYL-01", [6, 12, 24])
    if result:
        print("  Ensemble results:")
        for h, fp in result.items():
            print(f"  +{h}h: Q={fp.discharge_m3s:.1f}m3/s  "
                  f"level={fp.water_level_m:.2f}m  "
                  f"flood_prob={fp.flood_probability:.0%}  "
                  f"conf={fp.confidence:.2f}")
            print(f"       model: {fp.model_used[:80]}")
    else:
        print("  No result (need more historical data)")

    print("\n" + "=" * 55)
    print("DONE")

if __name__ == "__main__":
    asyncio.run(main())
