# Soil Profile: Cox's Bazar District

**Location:** Cox's Bazar (BD26)

## Soil Characteristics
- **Soil region:** Chittagong_Coastal_Plain
- **Soil pH:** 5.28
- **Clay content:** 27.30%
- **Sand content:** 39.20%
- **Silt content:** 32.40%
- **Soil organic carbon:** 8.31 g/kg
- **CEC:** 11.80 cmol/kg
- **Nitrogen:** 0.86 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
