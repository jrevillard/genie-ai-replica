// BFEWS Admin Panel JavaScript
const API = "";
let tok = localStorage.getItem("bfews_tok") || "";
let cu = null;

const ZN = {
  "SYL-01":"Sylhet Sadar","SYL-02":"Sunamganj","SYL-03":"Moulvibazar","SYL-04":"Habiganj",
  "DHA-01":"Dhaka City","DHA-02":"Manikganj","DHA-03":"Munshiganj","DHA-04":"Faridpur",
  "CTG-01":"Chittagong","CTG-02":"Cox's Bazar","CTG-03":"Noakhali","CTG-04":"Feni",
  "BAR-01":"Barisal","BAR-02":"Bhola","BAR-03":"Patuakhali",
  "RAJ-01":"Rajshahi","RAJ-02":"Sirajganj",
  "KHU-01":"Khulna","KHU-02":"Satkhira",
  "RAN-01":"Rangpur","RAN-02":"Kurigram",
  "MYM-01":"Mymensingh"
};

function ah() { return tok ? { Authorization: "Bearer " + tok } : {}; }
function fmt(v, d=1) { return v != null ? Number(v).toFixed(d) : "--"; }
function ta(ts) {
  if (!ts) return "--";
  const d = Math.floor((Date.now() - new Date(ts).getTime()) / 60000);
  return d < 1 ? "just now" : d < 60 ? d + "m ago" : Math.floor(d/60) + "h ago";
}

function notify(msg, type="s") {
  const bar = document.getElementById("nb");
  const el = document.createElement("div");
  el.className = "nt " + type;
  el.textContent = msg;
  bar.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// ── Login ──
async function doLogin() {
  const u = document.getElementById("lu").value;
  const p = document.getElementById("lp").value;
  const errEl = document.getElementById("le");
  errEl.style.display = "none";
  try {
    const r = await fetch(API + "/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: u, password: p })
    });
    if (!r.ok) { errEl.style.display = "block"; return; }
    const d = await r.json();
    tok = d.access_token;
    localStorage.setItem("bfews_tok", tok);
    cu = { u: d.username, r: d.role };
    showApp();
  } catch(e) {
    errEl.style.display = "block";
    console.error("Login error:", e);
  }
}

function doLogout() {
  tok = "";
  localStorage.removeItem("bfews_tok");
  document.getElementById("app").style.display = "none";
  document.getElementById("lw").style.display = "flex";
}

function showApp() {
  document.getElementById("lw").style.display = "none";
  document.getElementById("app").style.display = "block";
  document.getElementById("rb").textContent = cu.r;
  document.getElementById("hu").textContent = cu.u;
  populateZones();
  loadDB();
}

// ── Navigation ──
function sp(name) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".ni").forEach(n => n.classList.remove("active"));
  document.getElementById("p-" + name).classList.add("active");
  document.getElementById("n-" + name).classList.add("active");
  const loaders = { users: loadUsers, reports: loadReports, alerts: loadAH };
  if (loaders[name]) loaders[name]();
}

// ── Populate zone dropdowns ──
function populateZones() {
  ["uzf","au-z","ewz","erz","cz"].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    Object.entries(ZN).forEach(([z, n]) => {
      if (!el.querySelector('[value="' + z + '"]')) {
        const o = document.createElement("option");
        o.value = z; o.textContent = z + " — " + n;
        el.appendChild(o);
      }
    });
  });
  // Broadcast zone chips
  const bc = document.getElementById("bzc");
  if (bc && !bc.children.length) {
    Object.entries(ZN).forEach(([z, n]) => {
      const c = document.createElement("div");
      c.className = "zch"; c.dataset.z = z; c.textContent = n;
      c.onclick = () => c.classList.toggle("sel");
      bc.appendChild(c);
    });
  }
  // Char counter for broadcast
  const ta = document.getElementById("bcm");
  if (ta) ta.addEventListener("input", () => {
    document.getElementById("bcc").textContent = ta.value.length + " characters";
  });
}

// ── Dashboard ──
async function loadDB() {
  try {
    const r = await fetch(API + "/admin/dashboard", { headers: ah() });
    if (r.status === 401) { doLogout(); return; }
    const d = await r.json();
    document.getElementById("ds-u").textContent = d.total_users || 0;
    document.getElementById("ds-r").textContent = d.unhandled_reports || 0;
    document.getElementById("ds-a").textContent = d.active_alerts || 0;
    document.getElementById("ds-c").textContent = d.recent_chats_24h || 0;

    const zp = d.users_per_zone || {};
    const upzEl = document.getElementById("upz");
    if (!Object.keys(zp).length) {
      upzEl.innerHTML = '<div class="es">No registered users yet</div>';
    } else {
      upzEl.innerHTML = '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">' +
        Object.entries(zp).sort((a,b) => b[1]-a[1]).map(([z,c]) =>
          `<div style="background:#0f172a;border-radius:6px;padding:8px 12px;display:flex;justify-content:space-between">
            <span style="font-size:.8rem">${z}</span>
            <span style="font-weight:700;color:#60a5fa">${c}</span>
          </div>`
        ).join("") + "</div>";
    }

    const ar = await fetch(API + "/api/alerts", { headers: ah() });
    const ad = await ar.json();
    const dalEl = document.getElementById("dal");
    if (!ad.alerts || !ad.alerts.length) {
      dalEl.innerHTML = '<div class="es" style="color:#22c55e">✅ No active alerts</div>';
    } else {
      dalEl.innerHTML = ad.alerts.map(a =>
        `<div class="ai ${a.level}">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <strong>${ZN[a.zone_id] || a.zone_id}</strong>
            <span class="badge b${a.level[0]}">${a.level.toUpperCase()}</span>
          </div>
          <div style="font-size:.78rem;color:#94a3b8;margin-top:4px">${a.reason || "--"}</div>
        </div>`
      ).join("");
    }
  } catch(e) { console.error("Dashboard error:", e); }
}

// ── Users ──
let allU = [];
async function loadUsers() {
  const z = document.getElementById("uzf").value;
  try {
    const r = await fetch(API + "/admin/users?limit=200" + (z ? "&zone_id=" + z : ""), { headers: ah() });
    const d = await r.json();
    allU = d.users || [];
    document.getElementById("uc").textContent = "Total: " + d.total + " users";
    renderU(allU);
  } catch(e) { console.error(e); }
}

function fu() {
  const q = document.getElementById("us").value.toLowerCase();
  renderU(allU.filter(u => (u.phone||"").includes(q) || (u.name||"").toLowerCase().includes(q)));
}

function renderU(users) {
  const tb = document.getElementById("utb");
  if (!users.length) { tb.innerHTML = '<tr><td colspan="7" class="es">No users found</td></tr>'; return; }
  tb.innerHTML = users.map(u =>
    `<tr>
      <td><code style="font-size:.78rem">${u.phone}</code></td>
      <td>${u.name || "--"}</td>
      <td style="font-size:.75rem">${u.zone_id} — ${ZN[u.zone_id] || ""}</td>
      <td><span class="badge bb">${u.channel}</span></td>
      <td style="font-size:.75rem;color:#64748b">${ta(u.registered_at)}</td>
      <td style="font-size:.75rem;color:#64748b">${ta(u.last_alert)}</td>
      <td><button class="btn btn-d btn-sm" onclick="delU('${u.phone}')">Remove</button></td>
    </tr>`
  ).join("");
}

function openAU() { document.getElementById("m-au").classList.add("open"); }
function cm(id) { document.getElementById(id).classList.remove("open"); }

async function submitAU() {
  const ph = document.getElementById("au-p").value.trim();
  const z = document.getElementById("au-z").value;
  if (!ph || !z) { notify("Phone and zone required", "e"); return; }
  try {
    const r = await fetch(API + "/admin/users", {
      method: "POST",
      headers: { ...ah(), "Content-Type": "application/json" },
      body: JSON.stringify({
        phone: ph, zone_id: z,
        name: document.getElementById("au-n").value,
        channel: document.getElementById("au-c").value,
        telegram_id: document.getElementById("au-t").value || null
      })
    });
    const d = await r.json();
    notify("User " + d.action, "s");
    cm("m-au"); loadUsers();
  } catch(e) { notify("Error: " + e.message, "e"); }
}

async function delU(ph) {
  if (!confirm("Remove user " + ph + "?")) return;
  try {
    await fetch(API + "/admin/users/" + encodeURIComponent(ph), { method: "DELETE", headers: ah() });
    notify("User removed", "s"); loadUsers();
  } catch(e) { notify("Error", "e"); }
}

// ── Reports ──
async function loadReports() {
  const uo = document.getElementById("uo").checked;
  try {
    const r = await fetch(API + "/admin/reports?limit=50" + (uo ? "&unhandled_only=true" : ""), { headers: ah() });
    const d = await r.json();
    const tb = document.getElementById("rtb");
    if (!d.reports || !d.reports.length) {
      tb.innerHTML = '<tr><td colspan="8" class="es">No reports</td></tr>'; return;
    }
    tb.innerHTML = d.reports.map(r =>
      `<tr>
        <td style="font-size:.75rem;color:#64748b">${ta(r.reported_at)}</td>
        <td style="font-size:.78rem">${ZN[r.zone_id] || r.zone_id}</td>
        <td><code style="font-size:.72rem">${r.reporter || "--"}</code></td>
        <td style="max-width:180px;font-size:.78rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${r.description || ""}">${(r.description || "--").substring(0,60)}</td>
        <td>${r.flood_depth_cm ? r.flood_depth_cm + "cm" : "--"}</td>
        <td>${r.has_casualties ? '<span class="badge br">YES</span>' : "No"}</td>
        <td>${r.handled_by ? '<span class="badge bg">Handled</span>' : '<span class="badge by">Pending</span>'}</td>
        <td><button class="btn btn-s btn-sm" onclick="mh(${r.id})">✓ Handle</button></td>
      </tr>`
    ).join("");
  } catch(e) { console.error(e); }
}

async function mh(id) {
  try {
    await fetch(API + "/admin/reports/" + id + "?handled_by=" + encodeURIComponent(cu ? cu.u : "admin"), { method: "PUT", headers: ah() });
    notify("Marked as handled", "s"); loadReports();
  } catch(e) { notify("Error", "e"); }
}

// ── Alert History ──
async function loadAH() {
  const days = document.getElementById("ad").value;
  try {
    const r = await fetch(API + "/admin/alerts/history?days=" + days, { headers: ah() });
    const d = await r.json();
    const tb = document.getElementById("atb");
    if (!d.alerts || !d.alerts.length) {
      tb.innerHTML = '<tr><td colspan="8" class="es">No alerts</td></tr>'; return;
    }
    tb.innerHTML = d.alerts.map(a =>
      `<tr>
        <td style="font-size:.75rem;color:#64748b">${ta(a.issued_at)}</td>
        <td style="font-size:.78rem">${ZN[a.zone_id] || a.zone_id}</td>
        <td><span class="badge b${a.level[0]}">${a.level.toUpperCase()}</span></td>
        <td style="font-size:.78rem">${fmt(a.risk_score * 100, 0)}%</td>
        <td style="max-width:160px;font-size:.75rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${a.reason || "--"}</td>
        <td style="font-size:.75rem">${a.confirmed_by || "--"}</td>
        <td>${a.is_active ? '<span class="badge br">Active</span>' : '<span style="font-size:.72rem;color:#475569">Resolved</span>'}</td>
        <td>${a.is_active && !a.confirmed_by ? `<button class="btn btn-s btn-sm" onclick="confA('${a.zone_id}')">Confirm</button>` : "--"}</td>
      </tr>`
    ).join("");
  } catch(e) { console.error(e); }
}

async function confA(z) {
  const by = prompt("Confirmed by:", cu ? cu.u : "");
  if (!by) return;
  try {
    await fetch(API + "/admin/alerts/confirm", {
      method: "POST",
      headers: { ...ah(), "Content-Type": "application/json" },
      body: JSON.stringify({ zone_id: z, confirmed_by: by })
    });
    notify("Alert confirmed by " + by, "s"); loadAH();
  } catch(e) { notify("Error", "e"); }
}

// ── Broadcast ──
async function sendBC() {
  const msg = document.getElementById("bcm").value.trim();
  if (!msg) { notify("Message cannot be empty", "e"); return; }
  const sz = [...document.querySelectorAll(".zch.sel")].map(c => c.dataset.z);
  const ch = document.querySelector('input[name="bch"]:checked').value;
  if (!confirm("Send to " + (sz.length || "ALL") + " zones via " + ch + "?")) return;
  try {
    const r = await fetch(API + "/admin/broadcast", {
      method: "POST",
      headers: { ...ah(), "Content-Type": "application/json" },
      body: JSON.stringify({ message: msg, zone_ids: sz.length ? sz : null, channel: ch })
    });
    const d = await r.json();
    notify("Sent! WA:" + (d.stats?.whatsapp || 0) + " SMS:" + (d.stats?.sms || 0), "s");
  } catch(e) { notify("Error: " + e.message, "e"); }
}

// ── Export ──
function exp(type) {
  let url = "";
  if (type === "weather") {
    const z = document.getElementById("ewz").value;
    const h = document.getElementById("ewh").value;
    if (!z) { notify("Select a zone", "e"); return; }
    url = API + "/admin/export/weather?zone_id=" + z + "&hours=" + h;
  } else if (type === "rivers") {
    const z = document.getElementById("erz").value;
    const h = document.getElementById("erh").value;
    if (!z) { notify("Select a zone", "e"); return; }
    url = API + "/admin/export/rivers?zone_id=" + z + "&hours=" + h;
  } else {
    const d = document.getElementById("ead").value;
    url = API + "/admin/export/alerts?days=" + d;
  }
  fetch(url, { headers: ah() })
    .then(r => r.blob())
    .then(b => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(b);
      a.download = type + "_export.csv";
      a.click();
      notify("Download started", "s");
    })
    .catch(() => notify("Export failed", "e"));
}

// ── Charts ──
async function loadCharts() {
  const z = document.getElementById("cz").value;
  const h = document.getElementById("ch").value;
  if (!z) return;
  const el = document.getElementById("cc");
  el.innerHTML = '<div class="es">Loading...</div>';
  try {
    const r = await fetch(API + "/api/history/" + z + "?hours=" + h, { headers: ah() });
    const d = await r.json();
    const w = d.weather || [];
    if (!w.length) { el.innerHTML = '<div class="es">No data for this period</div>'; return; }

    const step = Math.max(1, Math.floor(w.length / 20));
    const sw = w.filter((_, i) => i % step === 0);
    const temps = sw.map(x => x.temperature || 0);
    const rains = sw.map(x => x.rainfall_1h || 0);
    const tms = sw.map(x => new Date(x.timestamp).toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" }));
    const mt = Math.max(...temps, 1);
    const mr = Math.max(...rains, 0.1);

    el.innerHTML = `
      <div style="margin-bottom:20px">
        <div style="font-size:.78rem;color:#64748b;margin-bottom:8px">🌡️ Temperature (°C) — ${ZN[z] || z}</div>
        <div class="cw">${temps.map(v => `<div class="cb" style="height:${(v/mt*100).toFixed(0)}%;background:#f97316"></div>`).join("")}</div>
        <div class="cl">${tms.map(t => `<div class="clb">${t}</div>`).join("")}</div>
      </div>
      <div style="margin-bottom:20px">
        <div style="font-size:.78rem;color:#64748b;margin-bottom:8px">🌧️ Rainfall 1h (mm)</div>
        <div class="cw">${rains.map(v => `<div class="cb" style="height:${Math.max(2,(v/mr*100)).toFixed(0)}%;background:#3b82f6"></div>`).join("")}</div>
        <div class="cl">${tms.map(t => `<div class="clb">${t}</div>`).join("")}</div>
      </div>`;

    const rivers = d.rivers || {};
    Object.entries(rivers).forEach(([sid, readings]) => {
      if (!readings.length) return;
      const s2 = Math.max(1, Math.floor(readings.length / 20));
      const sr = readings.filter((_, i) => i % s2 === 0);
      const levels = sr.map(r => r.water_level_m || 0);
      const rtimes = sr.map(r => new Date(r.timestamp).toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" }));
      const ml = Math.max(...levels, 1);
      el.innerHTML += `
        <div style="margin-bottom:20px">
          <div style="font-size:.78rem;color:#64748b;margin-bottom:8px">🌊 River — ${sid.replace(/_/g," ")}</div>
          <div class="cw">${levels.map(v => `<div class="cb" style="height:${(v/ml*100).toFixed(0)}%;background:#22c55e"></div>`).join("")}</div>
          <div class="cl">${rtimes.map(t => `<div class="clb">${t}</div>`).join("")}</div>
        </div>`;
    });
  } catch(e) { el.innerHTML = '<div class="es">Error loading charts</div>'; console.error(e); }
}

// ── Auto-login if token exists ──
window.addEventListener("load", () => {
  if (tok) {
    fetch(API + "/admin/me", { headers: ah() })
      .then(r => { if (r.ok) return r.json(); throw new Error("invalid"); })
      .then(d => { cu = { u: d.username, r: d.role }; showApp(); })
      .catch(() => { tok = ""; localStorage.removeItem("bfews_tok"); });
  }
});
