# Soil Profile: Natore District

**Location:** Natore (BD76)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.36
- **Clay content:** 36.10%
- **Sand content:** 21.10%
- **Silt content:** 38.90%
- **Soil organic carbon:** 10.17 g/kg
- **CEC:** 21.70 cmol/kg
- **Nitrogen:** 1.00 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
