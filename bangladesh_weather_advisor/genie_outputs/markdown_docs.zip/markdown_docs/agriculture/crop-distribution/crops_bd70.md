# Crop Distribution: Naogaon District

**Location:** Naogaon (BD70)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 69979.40 | 3.70 | Kharif-2 (Jul-Dec) |
| rice_boro | 67625.00 | 4.68 | Rabi (Dec-May) |
| rice_aus | 14560.40 | 2.68 | Kharif-1 (Mar-Aug) |
| maize | 12504.20 | 7.66 | Rabi (Oct-Apr) |
| potato | 10607.50 | 22.39 | Rabi (Nov-Mar) |
| wheat | 8755.40 | 3.64 | Rabi (Nov-Mar) |
| vegetables | 8541.00 | 10.67 | Rabi (Oct-Apr) |
| jute | 6758.00 | 2.65 | Kharif-1 (Mar-Aug) |
| pulses | 6403.00 | 0.99 | Rabi (Oct-Mar) |
| oilseeds | 6265.80 | 0.97 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
