# Crop Distribution: Patuakhali District

**Location:** Patuakhali (BD78)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 111197.70 | 4.14 | Kharif-2 (Jul-Dec) |
| rice_boro | 90676.50 | 5.41 | Rabi (Dec-May) |
| rice_aus | 23738.30 | 2.90 | Kharif-1 (Mar-Aug) |
| vegetables | 6353.80 | 10.48 | Rabi (Oct-Apr) |
| oilseeds | 6181.50 | 0.87 | Rabi (Oct-Mar) |
| pulses | 5296.30 | 0.97 | Rabi (Oct-Mar) |
| jute | 4881.00 | 2.40 | Kharif-1 (Mar-Aug) |
| spices | 3186.50 | 3.99 | Rabi/Kharif |
| potato | 2006.30 | 21.33 | Rabi (Nov-Mar) |
| sugarcane | 1740.40 | 55.89 | Perennial |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
