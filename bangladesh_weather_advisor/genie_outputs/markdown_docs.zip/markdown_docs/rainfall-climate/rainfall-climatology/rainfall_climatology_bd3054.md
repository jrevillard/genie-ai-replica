# Rainfall Climatology: District BD3054

## Climatology Summary
- **Mean daily climatological rainfall:** 5.46 mm
- **Median (P50) rainfall benchmark:** 2.97 mm
- **Upper percentile (P90) benchmark:** 12.91 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
