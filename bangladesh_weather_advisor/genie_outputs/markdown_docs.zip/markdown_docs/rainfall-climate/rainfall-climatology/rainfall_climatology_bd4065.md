# Rainfall Climatology: District BD4065

## Climatology Summary
- **Mean daily climatological rainfall:** 4.70 mm
- **Median (P50) rainfall benchmark:** 2.52 mm
- **Upper percentile (P90) benchmark:** 11.15 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
