# Crop Distribution: Rajbari District

**Location:** Rajbari (BD82)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 94247.70 | 4.36 | Kharif-2 (Jul-Dec) |
| rice_boro | 63208.80 | 4.51 | Rabi (Dec-May) |
| rice_aus | 17295.20 | 2.51 | Kharif-1 (Mar-Aug) |
| jute | 13165.00 | 2.21 | Kharif-1 (Mar-Aug) |
| maize | 7345.60 | 8.73 | Rabi (Oct-Apr) |
| vegetables | 6963.90 | 13.79 | Rabi (Oct-Apr) |
| potato | 6726.80 | 17.03 | Rabi (Nov-Mar) |
| pulses | 5662.80 | 1.16 | Rabi (Oct-Mar) |
| oilseeds | 5443.90 | 1.06 | Rabi (Oct-Mar) |
| spices | 3740.40 | 4.70 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
