# Crop Distribution: Netrokona District

**Location:** Netrokona (BD74)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 100015.10 | 4.36 | Kharif-2 (Jul-Dec) |
| rice_boro | 88908.60 | 5.64 | Rabi (Dec-May) |
| rice_aus | 19558.50 | 2.31 | Kharif-1 (Mar-Aug) |
| jute | 9413.60 | 2.26 | Kharif-1 (Mar-Aug) |
| vegetables | 6772.00 | 10.80 | Rabi (Oct-Apr) |
| maize | 6279.20 | 8.58 | Rabi (Oct-Apr) |
| oilseeds | 6080.90 | 0.84 | Rabi (Oct-Mar) |
| pulses | 5384.20 | 1.22 | Rabi (Oct-Mar) |
| potato | 4408.80 | 18.46 | Rabi (Nov-Mar) |
| spices | 4379.70 | 4.55 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
