"""
Climate Change Trend Analyzer untuk BFEWS.

Menganalisis tren jangka panjang dari data historis:
- Suhu rata-rata (pemanasan global)
- Curah hujan (intensifikasi siklus air)
- Level sungai (perubahan pola banjir)
- Kelembaban, angin, tekanan udara

Metode:
1. Linear regression (tren sederhana)
2. Mann-Kendall test (tren non-parametrik, cocok untuk data iklim)
3. Moving average (smoothing musiman)
4. Anomaly detection (deteksi tahun/bulan ekstrem)
"""

import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from loguru import logger

from data.storage.database import AsyncSessionLocal, WeatherReading, RiverReading
from sqlalchemy.future import select
from sqlalchemy import func


@dataclass
class TrendResult:
    """Hasil analisis tren satu variabel."""
    variable:       str
    unit:           str
    period_days:    int
    data_points:    int

    # Statistik dasar
    mean:           float
    std:            float
    min_val:        float
    max_val:        float

    # Tren linear
    slope_per_day:  float       # perubahan per hari
    slope_per_year: float       # perubahan per tahun (lebih intuitif)
    r_squared:      float       # kualitas fit (0-1)
    trend_direction: str        # "increasing", "decreasing", "stable"
    trend_strength:  str        # "strong", "moderate", "weak"

    # Mann-Kendall
    mk_tau:         float       # Kendall's tau (-1 to 1)
    mk_significant: bool        # apakah tren signifikan secara statistik

    # Anomali
    anomaly_count:  int         # jumlah nilai ekstrem (>2 std dev)
    recent_anomaly: bool        # apakah ada anomali dalam 30 hari terakhir

    # Interpretasi
    interpretation: str         # penjelasan dalam bahasa manusia
    climate_signal: str         # "warming", "cooling", "wetting", "drying", "intensifying", "stable"


@dataclass
class ClimateReport:
    """Laporan climate change lengkap untuk satu zona."""
    zone_id:        str
    zone_name:      str
    generated_at:   datetime
    period_days:    int
    total_readings: int

    trends:         Dict[str, TrendResult]  # variable → TrendResult
    summary:        str                      # ringkasan dalam bahasa Inggris
    risk_signals:   List[str]               # sinyal risiko iklim yang terdeteksi
    confidence:     str                     # "high", "medium", "low"


# ─────────────────────────────────────────────
# Statistical Functions
# ─────────────────────────────────────────────

def linear_regression(x: np.ndarray, y: np.ndarray) -> Tuple[float, float, float]:
    """
    Hitung regresi linear y = slope*x + intercept.
    Returns: (slope, intercept, r_squared)
    """
    if len(x) < 3:
        return 0.0, float(np.mean(y)) if len(y) > 0 else 0.0, 0.0

    n = len(x)
    x_mean = np.mean(x)
    y_mean = np.mean(y)

    ss_xy = np.sum((x - x_mean) * (y - y_mean))
    ss_xx = np.sum((x - x_mean) ** 2)

    if ss_xx == 0:
        return 0.0, y_mean, 0.0

    slope = ss_xy / ss_xx
    intercept = y_mean - slope * x_mean

    # R-squared
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - y_mean) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0.0

    return float(slope), float(intercept), float(max(0.0, r_squared))


def mann_kendall_test(data: np.ndarray) -> Tuple[float, bool]:
    """
    Mann-Kendall trend test — non-parametrik, cocok untuk data iklim.
    Tidak mengasumsikan distribusi normal.

    Returns: (tau, is_significant)
    - tau: -1 (tren turun kuat) to +1 (tren naik kuat)
    - is_significant: True jika p < 0.05
    """
    n = len(data)
    if n < 4:
        return 0.0, False

    # Hitung S statistic
    s = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            diff = data[j] - data[i]
            if diff > 0:
                s += 1
            elif diff < 0:
                s -= 1

    # Variance of S
    # Simplified (no ties correction)
    var_s = n * (n - 1) * (2 * n + 5) / 18

    # Z statistic
    if s > 0:
        z = (s - 1) / math.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / math.sqrt(var_s)
    else:
        z = 0.0

    # Kendall's tau
    tau = s / (n * (n - 1) / 2)

    # Significant if |z| > 1.96 (p < 0.05, two-tailed)
    is_significant = abs(z) > 1.96

    return float(tau), is_significant


def moving_average(data: np.ndarray, window: int = 7) -> np.ndarray:
    """Hitung moving average untuk smoothing."""
    if len(data) < window:
        return data
    kernel = np.ones(window) / window
    return np.convolve(data, kernel, mode='valid')


def detect_anomalies(data: np.ndarray, threshold_std: float = 2.0) -> Tuple[int, List[int]]:
    """
    Deteksi nilai anomali (outlier) menggunakan z-score.
    Returns: (count, indices)
    """
    if len(data) < 3:
        return 0, []
    mean = np.mean(data)
    std = np.std(data)
    if std == 0:
        return 0, []
    z_scores = np.abs((data - mean) / std)
    anomaly_indices = list(np.where(z_scores > threshold_std)[0])
    return len(anomaly_indices), anomaly_indices


# ─────────────────────────────────────────────
# Trend Analyzer
# ─────────────────────────────────────────────

class ClimateTrendAnalyzer:
    """
    Menganalisis tren climate change dari data historis BFEWS.
    """

    def _classify_trend(self, slope_per_year: float, r_squared: float,
                         mk_tau: float, mk_significant: bool,
                         variable: str) -> Tuple[str, str, str]:
        """
        Klasifikasi arah, kekuatan, dan sinyal iklim dari tren.
        Returns: (direction, strength, climate_signal)
        """
        # Threshold relatif per variabel
        thresholds = {
            "temperature":  {"strong": 0.5, "moderate": 0.1},   # °C/tahun
            "rainfall_1h":  {"strong": 2.0, "moderate": 0.5},   # mm/tahun
            "rainfall_6h":  {"strong": 5.0, "moderate": 1.0},
            "humidity":     {"strong": 2.0, "moderate": 0.5},    # %/tahun
            "wind_speed":   {"strong": 3.0, "moderate": 0.5},    # km/h/tahun
            "pressure":     {"strong": 1.0, "moderate": 0.2},    # hPa/tahun
            "water_level":  {"strong": 0.3, "moderate": 0.05},   # m/tahun
        }
        thresh = thresholds.get(variable, {"strong": 1.0, "moderate": 0.2})

        abs_slope = abs(slope_per_year)

        # Direction
        if abs_slope < thresh["moderate"] * 0.1 or not mk_significant:
            direction = "stable"
        elif slope_per_year > 0:
            direction = "increasing"
        else:
            direction = "decreasing"

        # Strength
        if abs_slope >= thresh["strong"] and r_squared > 0.3:
            strength = "strong"
        elif abs_slope >= thresh["moderate"] and r_squared > 0.1:
            strength = "moderate"
        else:
            strength = "weak"

        # Climate signal
        signal_map = {
            "temperature": {
                "increasing": "warming",
                "decreasing": "cooling",
                "stable": "stable",
            },
            "rainfall_1h": {
                "increasing": "intensifying",
                "decreasing": "drying",
                "stable": "stable",
            },
            "rainfall_6h": {
                "increasing": "intensifying",
                "decreasing": "drying",
                "stable": "stable",
            },
            "humidity": {
                "increasing": "wetting",
                "decreasing": "drying",
                "stable": "stable",
            },
            "water_level": {
                "increasing": "flood_risk_rising",
                "decreasing": "flood_risk_falling",
                "stable": "stable",
            },
        }
        climate_signal = signal_map.get(variable, {}).get(direction, "stable")

        return direction, strength, climate_signal

    def _interpret(self, variable: str, direction: str, strength: str,
                   slope_per_year: float, unit: str, mk_significant: bool) -> str:
        """Generate human-readable interpretation."""
        if direction == "stable" or not mk_significant:
            return f"No significant trend detected in {variable.replace('_', ' ')}."

        dir_word = "increasing" if direction == "increasing" else "decreasing"
        rate = abs(slope_per_year)

        interpretations = {
            "temperature": {
                "increasing": f"Temperature rising at {rate:.2f}°C/year — consistent with global warming signal.",
                "decreasing": f"Temperature decreasing at {rate:.2f}°C/year.",
            },
            "rainfall_1h": {
                "increasing": f"Hourly rainfall intensity increasing by {rate:.2f}mm/year — indicates more extreme precipitation events.",
                "decreasing": f"Hourly rainfall decreasing by {rate:.2f}mm/year — potential drying trend.",
            },
            "rainfall_6h": {
                "increasing": f"6-hour rainfall accumulation increasing by {rate:.2f}mm/year — higher flood risk.",
                "decreasing": f"6-hour rainfall decreasing by {rate:.2f}mm/year.",
            },
            "humidity": {
                "increasing": f"Humidity increasing by {rate:.2f}%/year.",
                "decreasing": f"Humidity decreasing by {rate:.2f}%/year — potential drying.",
            },
            "wind_speed": {
                "increasing": f"Wind speed increasing by {rate:.2f}km/h/year — potential intensification of storms.",
                "decreasing": f"Wind speed decreasing by {rate:.2f}km/h/year.",
            },
            "pressure": {
                "increasing": f"Atmospheric pressure increasing by {rate:.2f}hPa/year.",
                "decreasing": f"Atmospheric pressure decreasing by {rate:.2f}hPa/year — may indicate more cyclone activity.",
            },
            "water_level": {
                "increasing": f"River water levels rising by {rate:.3f}m/year — increasing flood frequency risk.",
                "decreasing": f"River water levels decreasing by {rate:.3f}m/year.",
            },
        }

        base = interpretations.get(variable, {}).get(direction,
               f"{variable.replace('_',' ')} {dir_word} at {rate:.3f}{unit}/year.")

        strength_note = {
            "strong": " This is a STRONG and statistically significant trend.",
            "moderate": " This is a moderate trend.",
            "weak": " This is a weak trend.",
        }
        return base + strength_note.get(strength, "")

    async def analyze_variable(
        self,
        zone_id: str,
        variable: str,
        values: List[float],
        timestamps: List[datetime],
        unit: str,
    ) -> TrendResult:
        """Analisis tren satu variabel."""
        if len(values) < 5:
            return TrendResult(
                variable=variable, unit=unit, period_days=0, data_points=len(values),
                mean=0, std=0, min_val=0, max_val=0,
                slope_per_day=0, slope_per_year=0, r_squared=0,
                trend_direction="stable", trend_strength="weak",
                mk_tau=0, mk_significant=False,
                anomaly_count=0, recent_anomaly=False,
                interpretation="Insufficient data for trend analysis.",
                climate_signal="stable",
            )

        arr = np.array(values, dtype=float)
        # Convert timestamps to days since first reading
        t0 = timestamps[0]
        days = np.array([(t - t0).total_seconds() / 86400 for t in timestamps])

        # Need at least 1 day of spread for meaningful trend
        total_span_days = float(days[-1]) if len(days) > 1 else 0

        # Basic stats
        mean_val = float(np.mean(arr))
        std_val = float(np.std(arr))
        min_val = float(np.min(arr))
        max_val = float(np.max(arr))

        # Linear regression — only meaningful if span > 1 day
        if total_span_days >= 1.0:
            slope_day, intercept, r2 = linear_regression(days, arr)
            slope_year = slope_day * 365.25
        else:
            slope_day, slope_year, r2 = 0.0, 0.0, 0.0

        # Mann-Kendall
        mk_tau, mk_sig = mann_kendall_test(arr)
        # Override significance if data span is too short
        if total_span_days < 3:
            mk_sig = False

        # Anomalies
        anom_count, anom_idx = detect_anomalies(arr)
        # Recent anomaly = anomaly in last 20% of data
        recent_threshold = int(len(arr) * 0.8)
        recent_anomaly = any(i >= recent_threshold for i in anom_idx)

        # Classify
        direction, strength, climate_signal = self._classify_trend(
            slope_year, r2, mk_tau, mk_sig, variable
        )

        # Interpret
        interpretation = self._interpret(variable, direction, strength, slope_year, unit, mk_sig)

        return TrendResult(
            variable=variable, unit=unit,
            period_days=int(total_span_days),
            data_points=len(values),
            mean=round(mean_val, 3), std=round(std_val, 3),
            min_val=round(min_val, 3), max_val=round(max_val, 3),
            slope_per_day=round(slope_day, 6),
            slope_per_year=round(slope_year, 4),
            r_squared=round(r2, 4),
            trend_direction=direction,
            trend_strength=strength,
            mk_tau=round(mk_tau, 4),
            mk_significant=mk_sig,
            anomaly_count=anom_count,
            recent_anomaly=recent_anomaly,
            interpretation=interpretation,
            climate_signal=climate_signal,
        )

    async def analyze_zone(self, zone_id: str, days: int = 30) -> ClimateReport:
        """
        Analisis climate change lengkap untuk satu zona.

        Args:
            zone_id: ID zona Bangladesh
            days: jumlah hari historis yang dianalisis (default 30)
        """
        from config import BANGLADESH_ZONES, RIVER_STATIONS

        zone = BANGLADESH_ZONES.get(zone_id)
        zone_name = zone.name_en if zone else zone_id

        cutoff = datetime.utcnow() - timedelta(days=days)

        # Ambil data cuaca historis
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(WeatherReading)
                .where(WeatherReading.zone_id == zone_id,
                       WeatherReading.timestamp >= cutoff)
                .order_by(WeatherReading.timestamp.asc())
            )
            weather_rows = result.scalars().all()

        if not weather_rows:
            return ClimateReport(
                zone_id=zone_id, zone_name=zone_name,
                generated_at=datetime.utcnow(), period_days=days,
                total_readings=0, trends={},
                summary="No historical data available for climate analysis.",
                risk_signals=[], confidence="low",
            )

        timestamps = [r.timestamp for r in weather_rows]

        # Analisis setiap variabel cuaca
        weather_vars = {
            "temperature":  ([r.temperature for r in weather_rows if r.temperature is not None], "°C"),
            "rainfall_1h":  ([r.rainfall_1h for r in weather_rows if r.rainfall_1h is not None], "mm/h"),
            "rainfall_6h":  ([r.rainfall_6h for r in weather_rows if r.rainfall_6h is not None], "mm"),
            "humidity":     ([r.humidity for r in weather_rows if r.humidity is not None], "%"),
            "wind_speed":   ([r.wind_speed for r in weather_rows if r.wind_speed is not None], "km/h"),
            "pressure":     ([r.pressure for r in weather_rows if r.pressure is not None], "hPa"),
        }

        trends = {}
        for var_name, (values, unit) in weather_vars.items():
            if len(values) >= 5:
                # Align timestamps with available values
                ts_aligned = timestamps[:len(values)]
                trends[var_name] = await self.analyze_variable(
                    zone_id, var_name, values, ts_aligned, unit
                )

        # Analisis level sungai
        if zone:
            for station_id in zone.river_stations:
                async with AsyncSessionLocal() as db:
                    result = await db.execute(
                        select(RiverReading)
                        .where(RiverReading.station_id == station_id,
                               RiverReading.timestamp >= cutoff)
                        .order_by(RiverReading.timestamp.asc())
                    )
                    river_rows = result.scalars().all()

                if len(river_rows) >= 5:
                    river_vals = [r.water_level_m for r in river_rows]
                    river_ts = [r.timestamp for r in river_rows]
                    trends[f"water_level_{station_id}"] = await self.analyze_variable(
                        zone_id, "water_level", river_vals, river_ts, "m"
                    )

        # Generate risk signals
        risk_signals = []
        for var, trend in trends.items():
            if trend.climate_signal == "warming" and trend.trend_strength in ["strong", "moderate"]:
                risk_signals.append(f"🌡️ Warming trend in {zone_name}: +{trend.slope_per_year:.2f}°C/year")
            elif trend.climate_signal == "intensifying" and trend.trend_strength in ["strong", "moderate"]:
                risk_signals.append(f"🌧️ Rainfall intensification: +{trend.slope_per_year:.2f}mm/year")
            elif trend.climate_signal == "flood_risk_rising" and trend.trend_strength in ["strong", "moderate"]:
                risk_signals.append(f"🌊 River levels rising: +{trend.slope_per_year:.3f}m/year")
            elif trend.climate_signal == "drying" and trend.trend_strength == "strong":
                risk_signals.append(f"🏜️ Drying trend detected in {var}")
            if trend.recent_anomaly:
                risk_signals.append(f"⚠️ Recent anomaly detected in {var.replace('_',' ')}")

        # Confidence based on data quantity
        if len(weather_rows) >= 100:
            confidence = "high"
        elif len(weather_rows) >= 30:
            confidence = "medium"
        else:
            confidence = "low"

        # Summary
        significant_trends = [t for t in trends.values() if t.mk_significant]
        if not significant_trends:
            summary = (f"No statistically significant climate trends detected in {zone_name} "
                      f"over the past {days} days ({len(weather_rows)} readings). "
                      f"Longer data collection period recommended for robust analysis.")
        else:
            signals = list(set(t.climate_signal for t in significant_trends if t.climate_signal != "stable"))
            summary = (f"Analysis of {len(weather_rows)} readings over {days} days in {zone_name}. "
                      f"Detected {len(significant_trends)} significant trend(s): {', '.join(signals) if signals else 'mixed'}. "
                      f"{'Risk signals present — monitor closely.' if risk_signals else 'No immediate climate risk signals.'}")

        return ClimateReport(
            zone_id=zone_id, zone_name=zone_name,
            generated_at=datetime.utcnow(),
            period_days=days,
            total_readings=len(weather_rows),
            trends=trends,
            summary=summary,
            risk_signals=risk_signals,
            confidence=confidence,
        )


# Singleton
climate_analyzer = ClimateTrendAnalyzer()
