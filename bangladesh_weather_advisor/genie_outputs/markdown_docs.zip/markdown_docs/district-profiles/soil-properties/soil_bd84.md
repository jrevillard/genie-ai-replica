# Soil Profile: Rangamati District

**Location:** Rangamati (BD84)

## Soil Characteristics
- **Soil region:** Hill_Tracts
- **Soil pH:** 4.90
- **Clay content:** 34.70%
- **Sand content:** 29.10%
- **Silt content:** 36.60%
- **Soil organic carbon:** 16.24 g/kg
- **CEC:** 15.50 cmol/kg
- **Nitrogen:** 1.43 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
