# Soil Profile: Tangail District

**Location:** Tangail (BD64)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 6.12
- **Clay content:** 33.20%
- **Sand content:** 27.40%
- **Silt content:** 38.10%
- **Soil organic carbon:** 11.98 g/kg
- **CEC:** 18.70 cmol/kg
- **Nitrogen:** 1.17 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
