# Crop Distribution: Dhaka District

**Location:** Dhaka (BD27)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 66210.70 | 4.43 | Kharif-2 (Jul-Dec) |
| rice_boro | 63930.10 | 5.30 | Rabi (Dec-May) |
| rice_aus | 14148.00 | 2.77 | Kharif-1 (Mar-Aug) |
| jute | 10921.20 | 2.42 | Kharif-1 (Mar-Aug) |
| maize | 8181.70 | 8.14 | Rabi (Oct-Apr) |
| vegetables | 7961.20 | 13.14 | Rabi (Oct-Apr) |
| pulses | 6572.10 | 1.07 | Rabi (Oct-Mar) |
| potato | 6497.40 | 17.92 | Rabi (Nov-Mar) |
| spices | 4640.50 | 3.95 | Rabi/Kharif |
| oilseeds | 4599.20 | 1.11 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
