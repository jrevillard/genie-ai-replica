# 🚀 Deploy BFEWS — Panduan Lengkap

```
Server IP  : 187.77.116.110
Domain     : https://forecast.masjidmupundong.com
OS         : Ubuntu 22.04 (Hostinger VPS)
```

---

## Langkah 1 — Koneksi ke VPS

Buka terminal (Windows: pakai PowerShell atau PuTTY):

```bash
ssh root@187.77.116.110
```

Masukkan password root dari hPanel Hostinger.

---

## Langkah 2 — Upload File Aplikasi

**Via FileZilla (paling mudah):**

1. Download [FileZilla](https://filezilla-project.org/)
2. Koneksi:
   - Host: `187.77.116.110`
   - Username: `root`
   - Password: *(password VPS dari Hostinger)*
   - Port: `22`
3. Di panel kanan (server), buat folder `/var/www/bfews`
4. Upload seluruh isi folder `bangladesh-flood-warning` ke `/var/www/bfews`

**Atau via SCP dari terminal lokal:**
```bash
scp -r bangladesh-flood-warning/* root@187.77.116.110:/var/www/bfews/
```

---

## Langkah 3 — Jalankan Setup Script

```bash
# Di VPS (setelah SSH):
bash /var/www/bfews/deploy/setup_vps.sh
```

Script otomatis:
- Install Python 3.11, Nginx, Certbot
- Buat virtual environment & install dependencies
- Setup systemd service (auto-start saat VPS reboot)
- Konfigurasi Nginx untuk domain

---

## Langkah 4 — Verifikasi API Keys

```bash
nano /var/www/bfews/.env
```

Pastikan isi sudah benar:
```
OPENWEATHER_API_KEY=cac539cc03e3d65f8b6db66ce19e5459
GROQ_API_KEY=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
TELEGRAM_BOT_TOKEN=8780152925:AAEg3O8YtUlI30DYhi5_gFgL6fwtWdPYYxo
DEBUG=false
```

Simpan: `Ctrl+X` → `Y` → `Enter`

Restart:
```bash
sudo systemctl restart bfews
```

---

## Langkah 5 — Pasang SSL (HTTPS)

Domain `forecast.masjidmupundong.com` harus sudah diarahkan ke IP `187.77.116.110` di DNS manager.

**Cek DNS sudah aktif:**
```bash
ping forecast.masjidmupundong.com
# Harus reply dari 187.77.116.110
```

**Pasang SSL gratis:**
```bash
sudo certbot --nginx -d forecast.masjidmupundong.com
```

Ikuti instruksi, masukkan email, pilih `2` (redirect HTTP ke HTTPS).

---

## Langkah 6 — Set Telegram Webhook

Setelah HTTPS aktif, buka URL ini di browser:

```
https://api.telegram.org/bot8780152925:AAEg3O8YtUlI30DYhi5_gFgL6fwtWdPYYxo/setWebhook?url=https://forecast.masjidmupundong.com/webhook/telegram/8780152925:AAEg3O8YtUlI30DYhi5_gFgL6fwtWdPYYxo
```

Harus muncul: `{"ok":true,"result":true}`

---

## Verifikasi Final

```bash
# Status service
sudo systemctl status bfews

# Test API
curl https://forecast.masjidmupundong.com/health

# Lihat log
sudo journalctl -u bfews -f
```

Buka browser:
- **Dashboard** : https://forecast.masjidmupundong.com
- **API Docs**  : https://forecast.masjidmupundong.com/docs
- **Health**    : https://forecast.masjidmupundong.com/health

---

## Perintah Berguna

```bash
# Restart aplikasi
sudo systemctl restart bfews

# Stop / Start
sudo systemctl stop bfews
sudo systemctl start bfews

# Lihat log real-time
sudo journalctl -u bfews -f

# Lihat log 100 baris terakhir
sudo journalctl -u bfews -n 100 --no-pager

# Cek penggunaan RAM/CPU
htop

# Cek port yang dipakai
ss -tlnp | grep 8000

# Perpanjang SSL otomatis (sudah disetup certbot)
sudo certbot renew --dry-run
```

---

## Troubleshooting

**Aplikasi tidak bisa diakses:**
```bash
sudo ufw allow 8000
sudo ufw allow 80
sudo ufw allow 443
```

**Nginx error:**
```bash
sudo nginx -t
sudo tail -20 /var/log/nginx/error.log
```

**Aplikasi crash:**
```bash
sudo journalctl -u bfews -n 50 --no-pager
```

**Database error:**
```bash
cd /var/www/bfews
source venv/bin/activate
python scripts/init_db.py
```

**Update aplikasi (setelah upload file baru):**
```bash
sudo systemctl restart bfews
```
