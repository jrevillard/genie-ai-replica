# Crop Distribution: Chattogram District

**Location:** Chattogram (BD15)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 77145.40 | 4.17 | Kharif-2 (Jul-Dec) |
| rice_boro | 51879.10 | 5.71 | Rabi (Dec-May) |
| rice_aus | 12957.80 | 2.91 | Kharif-1 (Mar-Aug) |
| vegetables | 7770.80 | 13.34 | Rabi (Oct-Apr) |
| jute | 7193.40 | 2.71 | Kharif-1 (Mar-Aug) |
| pulses | 6601.50 | 1.05 | Rabi (Oct-Mar) |
| oilseeds | 5244.70 | 0.91 | Rabi (Oct-Mar) |
| spices | 3975.80 | 3.83 | Rabi/Kharif |
| maize | 3243.50 | 7.55 | Rabi (Oct-Apr) |
| potato | 2613.60 | 22.77 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
