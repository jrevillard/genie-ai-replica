# Crop Distribution: Noakhali District

**Location:** Noakhali (BD75)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 79009.00 | 3.55 | Kharif-2 (Jul-Dec) |
| rice_boro | 69290.10 | 5.53 | Rabi (Dec-May) |
| rice_aus | 14048.90 | 2.79 | Kharif-1 (Mar-Aug) |
| vegetables | 8959.50 | 12.28 | Rabi (Oct-Apr) |
| jute | 8453.20 | 2.47 | Kharif-1 (Mar-Aug) |
| oilseeds | 5320.70 | 1.11 | Rabi (Oct-Mar) |
| pulses | 5297.80 | 0.99 | Rabi (Oct-Mar) |
| spices | 4371.60 | 4.41 | Rabi/Kharif |
| maize | 3894.70 | 8.06 | Rabi (Oct-Apr) |
| potato | 3096.70 | 20.79 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
