"""
Telegram Bot — antarmuka chatbot via Telegram.
Gratis tanpa batas, tidak butuh verifikasi bisnis.
Ideal untuk testing dan deployment awal.
"""

import asyncio
from typing import Optional
from loguru import logger

try:
    from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler,
        CallbackQueryHandler, ContextTypes, filters
    )
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    logger.warning("python-telegram-bot tidak tersedia")

from config import TELEGRAM_BOT_TOKEN, BANGLADESH_ZONES
from chatbot.core import ChatbotEngine


chatbot_engine = ChatbotEngine()


# ─────────────────────────────────────────────
# Command Handlers
# ─────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /start — sambutan awal."""
    user_id = str(update.effective_user.id)
    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="হ্যালো",
        platform="telegram",
    )
    # Tambah keyboard inline untuk zona populer
    keyboard = [
        [
            InlineKeyboardButton("🌊 সিলেট", callback_data="zone:SYL-01"),
            InlineKeyboardButton("🏙️ ঢাকা", callback_data="zone:DHA-01"),
        ],
        [
            InlineKeyboardButton("⛵ চট্টগ্রাম", callback_data="zone:CTG-01"),
            InlineKeyboardButton("🌴 বরিশাল", callback_data="zone:BAR-01"),
        ],
        [
            InlineKeyboardButton("🌾 রাজশাহী", callback_data="zone:RAJ-01"),
            InlineKeyboardButton("🏔️ রংপুর", callback_data="zone:RAN-01"),
        ],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        response,
        parse_mode="Markdown",
        reply_markup=reply_markup,
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /status — status terkini."""
    user_id = str(update.effective_user.id)
    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="INFO",
        platform="telegram",
    )
    await update.message.reply_text(response, parse_mode="Markdown")


async def cmd_forecast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /forecast — prakiraan cuaca."""
    user_id = str(update.effective_user.id)
    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="CUACA",
        platform="telegram",
    )
    await update.message.reply_text(response, parse_mode="Markdown")


async def cmd_river(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /river — level sungai."""
    user_id = str(update.effective_user.id)
    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="BANJIR",
        platform="telegram",
    )
    await update.message.reply_text(response, parse_mode="Markdown")


async def cmd_shelter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /shelter — titik pengungsian."""
    user_id = str(update.effective_user.id)
    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="BANTUAN",
        platform="telegram",
    )
    await update.message.reply_text(response, parse_mode="Markdown")


async def cmd_register(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /register — daftar notifikasi."""
    user_id = str(update.effective_user.id)
    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="DAFTAR",
        platform="telegram",
    )
    await update.message.reply_text(response, parse_mode="Markdown")


async def cmd_zones(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /zones — daftar semua zona."""
    lines = ["📍 *Daftar Zona Bangladesh:*\n"]
    for zone_id, zone in BANGLADESH_ZONES.items():
        lines.append(f"• `{zone_id}` — {zone.name_bn} ({zone.division})")

    lines.append("\nKetik nama distrik untuk info zona tersebut.")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ─────────────────────────────────────────────
# Message Handler (pesan biasa)
# ─────────────────────────────────────────────

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk semua pesan teks biasa."""
    user_id = str(update.effective_user.id)
    message = update.message.text or ""

    # Tampilkan "mengetik..."
    await context.bot.send_chat_action(
        chat_id=update.effective_chat.id,
        action="typing"
    )

    response, needs_escalation = await chatbot_engine.process_message(
        user_id=user_id,
        message=message,
        platform="telegram",
        lang="auto",
    )

    await update.message.reply_text(response, parse_mode="Markdown")

    if needs_escalation:
        logger.warning(f"🚨 Eskalasi diperlukan untuk user {user_id}: {message[:100]}")


async def handle_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk pesan lokasi GPS."""
    user_id = str(update.effective_user.id)
    location = update.message.location

    response, _ = await chatbot_engine.process_message(
        user_id=user_id,
        message="lokasi dikirim",
        platform="telegram",
        location_lat=location.latitude,
        location_lon=location.longitude,
    )

    await update.message.reply_text(
        f"📍 Lokasi diterima ({location.latitude:.4f}, {location.longitude:.4f})\n\n{response}",
        parse_mode="Markdown"
    )


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk tombol inline keyboard."""
    query = update.callback_query
    await query.answer()

    user_id = str(query.from_user.id)
    data = query.data

    if data.startswith("zone:"):
        zone_id = data.split(":")[1]
        zone = BANGLADESH_ZONES.get(zone_id)
        if zone:
            response, _ = await chatbot_engine.process_message(
                user_id=user_id,
                message=zone.name_bn,
                platform="telegram",
            )
            await query.edit_message_text(response, parse_mode="Markdown")


# ─────────────────────────────────────────────
# Alert Broadcaster
# ─────────────────────────────────────────────

async def broadcast_alert_telegram(
    bot: "Bot",
    telegram_ids: list,
    message: str,
):
    """Kirim peringatan ke semua pengguna Telegram terdaftar."""
    success = 0
    failed = 0

    for telegram_id in telegram_ids:
        try:
            await bot.send_message(
                chat_id=telegram_id,
                text=message,
                parse_mode="Markdown",
            )
            success += 1
            await asyncio.sleep(0.05)  # Rate limiting: 20 msg/detik
        except Exception as e:
            logger.warning(f"Gagal kirim Telegram ke {telegram_id}: {e}")
            failed += 1

    logger.info(f"📱 Telegram broadcast: {success} berhasil, {failed} gagal")
    return success, failed


# ─────────────────────────────────────────────
# Bot Runner
# ─────────────────────────────────────────────

def create_telegram_app() -> Optional["Application"]:
    """Buat dan konfigurasi Telegram bot application."""
    if not TELEGRAM_AVAILABLE:
        logger.error("python-telegram-bot tidak tersedia")
        return None

    if not TELEGRAM_BOT_TOKEN:
        logger.warning("TELEGRAM_BOT_TOKEN tidak dikonfigurasi, Telegram bot dinonaktifkan")
        return None

    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Daftarkan handlers
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("forecast", cmd_forecast))
    app.add_handler(CommandHandler("river", cmd_river))
    app.add_handler(CommandHandler("shelter", cmd_shelter))
    app.add_handler(CommandHandler("register", cmd_register))
    app.add_handler(CommandHandler("zones", cmd_zones))
    app.add_handler(MessageHandler(filters.LOCATION, handle_location))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(handle_callback))

    logger.info("✅ Telegram bot dikonfigurasi")
    return app
