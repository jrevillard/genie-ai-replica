# Rainfall Climatology: District BD4087

## Climatology Summary
- **Mean daily climatological rainfall:** 4.95 mm
- **Median (P50) rainfall benchmark:** 3.09 mm
- **Upper percentile (P90) benchmark:** 11.12 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
