"""
Klasifikasi intent pesan dari pengguna.
Mendukung Bahasa Bengali dan Inggris.

Intent yang didukung:
- greeting: salam/halo
- status_query: tanya kondisi saat ini
- forecast_query: tanya prakiraan
- river_query: tanya level sungai
- evacuation_query: tanya titik pengungsian
- help_query: minta bantuan/darurat
- register: daftar notifikasi
- unregister: berhenti notifikasi
- field_report: laporan kondisi lapangan
- location_share: berbagi lokasi
- unknown: tidak dikenali
"""

import re
from typing import Tuple, Optional
from dataclasses import dataclass


@dataclass
class Intent:
    name: str
    confidence: float
    extracted_location: Optional[str] = None
    extracted_depth: Optional[float] = None


# ─────────────────────────────────────────────
# Keyword Maps
# ─────────────────────────────────────────────

INTENT_KEYWORDS = {
    "greeting": {
        "bn": ["হ্যালো", "হ্যালো", "আস্সালামু", "সালাম", "নমস্কার", "হাই", "শুরু"],
        "en": ["hello", "hi", "hey", "start", "begin", "assalamu"],
        "commands": [],
    },
    "status_query": {
        "bn": ["অবস্থা", "পরিস্থিতি", "কেমন", "ঠিক আছে", "নিরাপদ", "বিপদ", "এখন"],
        "en": ["status", "condition", "safe", "danger", "current", "now", "situation"],
        "commands": ["INFO", "STATUS"],
    },
    "forecast_query": {
        "bn": ["পূর্বাভাস", "আগামীকাল", "পরে", "কাল", "ঘণ্টায়", "আবহাওয়া", "বৃষ্টি হবে"],
        "en": ["forecast", "tomorrow", "later", "predict", "weather", "will it rain"],
        "commands": ["CUACA", "FORECAST", "WEATHER"],
    },
    "river_query": {
        "bn": ["নদী", "পানি", "বন্যা", "জলস্তর", "সুরমা", "যমুনা", "পদ্মা", "মেঘনা", "ব্রহ্মপুত্র"],
        "en": ["river", "water level", "flood level", "surma", "jamuna", "padma", "meghna"],
        "commands": ["BANJIR", "RIVER", "FLOOD"],
    },
    "evacuation_query": {
        "bn": ["আশ্রয়", "আশ্রয়কেন্দ্র", "কোথায় যাব", "নিরাপদ স্থান", "সরে যাব", "পালাব", "ইভাকুয়েশন", "সাহায্য"],
        "en": ["shelter", "evacuation", "where to go", "safe place", "evacuate", "escape", "bantuan"],
        "commands": ["BANTUAN", "EVAKUASI", "SHELTER", "EVACUATE"],
    },
    "help_query": {
        "bn": ["সাহায্য", "জরুরি", "বিপদে", "ডুবছি", "আটকে", "উদ্ধার", "হেল্প"],
        "en": ["help", "emergency", "trapped", "drowning", "rescue", "sos", "urgent"],
        "commands": ["HELP", "SOS"],
    },
    "register": {
        "bn": ["নিবন্ধন", "রেজিস্ট্রেশন", "সতর্কতা পেতে চাই", "নোটিফিকেশন চাই"],
        "en": ["register", "subscribe", "sign up", "notification", "alert me"],
        "commands": ["DAFTAR", "REGISTER", "SUBSCRIBE"],
    },
    "unregister": {
        "bn": ["বাতিল", "বন্ধ করুন", "আর চাই না", "আনসাবস্ক্রাইব"],
        "en": ["unsubscribe", "stop", "cancel", "unregister", "opt out"],
        "commands": ["BERHENTI", "STOP", "UNSUBSCRIBE"],
    },
    "field_report": {
        "bn": ["বন্যা হয়েছে", "পানি উঠেছে", "ডুবে গেছে", "রাস্তা ডুবে", "ঘর ডুবে",
               "হাঁটু পানি", "কোমর পানি", "বুক পানি", "মানুষ আটকে"],
        "en": ["flooding here", "water rising", "road flooded", "house flooded",
               "knee deep", "waist deep", "people trapped", "flood report"],
        "commands": [],
    },
}

# Nama distrik Bangladesh untuk ekstraksi lokasi
DISTRICT_NAMES = {
    # Bengali → zone_id
    "সিলেট": "SYL-01", "sylhet": "SYL-01",
    "সুনামগঞ্জ": "SYL-02", "sunamganj": "SYL-02",
    "মৌলভীবাজার": "SYL-03", "moulvibazar": "SYL-03", "moulvi bazar": "SYL-03",
    "হবিগঞ্জ": "SYL-04", "habiganj": "SYL-04",
    "ঢাকা": "DHA-01", "dhaka": "DHA-01",
    "মানিকগঞ্জ": "DHA-02", "manikganj": "DHA-02",
    "মুন্সীগঞ্জ": "DHA-03", "munshiganj": "DHA-03",
    "ফরিদপুর": "DHA-04", "faridpur": "DHA-04",
    "চট্টগ্রাম": "CTG-01", "chittagong": "CTG-01", "chattogram": "CTG-01",
    "কক্সবাজার": "CTG-02", "cox's bazar": "CTG-02", "coxs bazar": "CTG-02",
    "নোয়াখালী": "CTG-03", "noakhali": "CTG-03",
    "ফেনী": "CTG-04", "feni": "CTG-04",
    "বরিশাল": "BAR-01", "barisal": "BAR-01", "barishal": "BAR-01",
    "ভোলা": "BAR-02", "bhola": "BAR-02",
    "পটুয়াখালী": "BAR-03", "patuakhali": "BAR-03",
    "রাজশাহী": "RAJ-01", "rajshahi": "RAJ-01",
    "সিরাজগঞ্জ": "RAJ-02", "sirajganj": "RAJ-02",
    "খুলনা": "KHU-01", "khulna": "KHU-01",
    "সাতক্ষীরা": "KHU-02", "satkhira": "KHU-02",
    "রংপুর": "RAN-01", "rangpur": "RAN-01",
    "কুড়িগ্রাম": "RAN-02", "kurigram": "RAN-02",
    "ময়মনসিংহ": "MYM-01", "mymensingh": "MYM-01",
}

# Pola kedalaman banjir
DEPTH_PATTERNS = [
    (r"(\d+)\s*সেন্টিমিটার", 1.0),
    (r"(\d+)\s*cm", 1.0),
    (r"(\d+)\s*ইঞ্চি", 2.54),
    (r"হাঁটু", 50.0),   # lutut ~50cm
    (r"কোমর", 90.0),    # pinggang ~90cm
    (r"বুক", 120.0),    # dada ~120cm
    (r"গলা", 150.0),    # leher ~150cm
    (r"knee", 50.0),
    (r"waist", 90.0),
    (r"chest", 120.0),
]


class IntentClassifier:
    """
    Klasifikasi intent berbasis keyword matching.
    Cepat, deterministik, tidak butuh model ML.
    """

    def classify(self, text: str) -> Intent:
        """
        Klasifikasi intent dari teks pesan.
        Returns Intent dengan nama dan confidence.
        """
        text_lower = text.lower().strip()

        # Cek command eksplisit dulu (prioritas tertinggi)
        text_upper = text.upper().strip()
        for intent_name, keywords in INTENT_KEYWORDS.items():
            if text_upper in keywords.get("commands", []):
                return Intent(
                    name=intent_name,
                    confidence=1.0,
                    extracted_location=self._extract_location(text_lower),
                )

        # Hitung skor per intent berdasarkan keyword
        scores = {}
        for intent_name, keywords in INTENT_KEYWORDS.items():
            score = 0
            total_keywords = 0

            for lang in ["bn", "en"]:
                for kw in keywords.get(lang, []):
                    total_keywords += 1
                    if kw.lower() in text_lower:
                        score += 1

            if total_keywords > 0:
                scores[intent_name] = score / total_keywords * (score + 1)  # boost untuk lebih banyak match

        if not scores or max(scores.values()) == 0:
            return Intent(name="unknown", confidence=0.0)

        best_intent = max(scores, key=scores.get)
        max_score = scores[best_intent]

        # Normalisasi confidence
        confidence = min(1.0, max_score * 5)

        # Ekstrak lokasi dan kedalaman
        location = self._extract_location(text_lower)
        depth = self._extract_depth(text_lower)

        return Intent(
            name=best_intent,
            confidence=confidence,
            extracted_location=location,
            extracted_depth=depth,
        )

    def _extract_location(self, text: str) -> Optional[str]:
        """Ekstrak nama distrik dari teks."""
        text_lower = text.lower()
        for name, zone_id in DISTRICT_NAMES.items():
            if name.lower() in text_lower:
                return zone_id
        return None

    def _extract_depth(self, text: str) -> Optional[float]:
        """Ekstrak kedalaman banjir dari teks (dalam cm)."""
        for pattern, multiplier in DEPTH_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                try:
                    value = float(match.group(1)) if match.lastindex else multiplier
                    return value * multiplier if match.lastindex else multiplier
                except (IndexError, ValueError):
                    return multiplier
        return None

    def needs_escalation(self, text: str) -> bool:
        """
        Cek apakah pesan perlu dieskalasi ke manusia.
        Trigger: korban, darurat ekstrem, pertanyaan di luar kemampuan bot.
        """
        escalation_keywords = [
            # Bengali
            "মারা গেছে", "মৃত", "আহত", "আটকে পড়েছি", "ডুবে যাচ্ছি",
            "সাহায্য করুন", "বাঁচান", "উদ্ধার করুন", "হাসপাতাল",
            # English
            "dead", "died", "injured", "trapped", "drowning", "save me",
            "rescue", "hospital", "casualty", "victim",
        ]
        text_lower = text.lower()
        return any(kw.lower() in text_lower for kw in escalation_keywords)
