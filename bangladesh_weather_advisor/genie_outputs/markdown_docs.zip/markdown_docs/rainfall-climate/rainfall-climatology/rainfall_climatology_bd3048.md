# Rainfall Climatology: District BD3048

## Climatology Summary
- **Mean daily climatological rainfall:** 6.40 mm
- **Median (P50) rainfall benchmark:** 4.27 mm
- **Upper percentile (P90) benchmark:** 14.07 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
