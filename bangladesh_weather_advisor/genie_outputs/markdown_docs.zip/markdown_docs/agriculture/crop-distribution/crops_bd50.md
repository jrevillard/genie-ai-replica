# Crop Distribution: Khulna District

**Location:** Khulna (BD50)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 88394.90 | 3.48 | Kharif-2 (Jul-Dec) |
| rice_boro | 58467.10 | 4.76 | Rabi (Dec-May) |
| rice_aus | 18276.40 | 2.82 | Kharif-1 (Mar-Aug) |
| jute | 8246.30 | 2.75 | Kharif-1 (Mar-Aug) |
| pulses | 6854.20 | 1.14 | Rabi (Oct-Mar) |
| vegetables | 6348.70 | 13.57 | Rabi (Oct-Apr) |
| oilseeds | 5757.10 | 0.91 | Rabi (Oct-Mar) |
| spices | 4123.60 | 5.00 | Rabi/Kharif |
| potato | 3693.00 | 22.68 | Rabi (Nov-Mar) |
| maize | 2809.30 | 8.64 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
