# Crop Distribution: Jhalokati District

**Location:** Jhalokati (BD42)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 105944.70 | 4.83 | Rabi (Dec-May) |
| rice_aman | 87983.10 | 4.33 | Kharif-2 (Jul-Dec) |
| rice_aus | 17655.70 | 2.71 | Kharif-1 (Mar-Aug) |
| vegetables | 6524.60 | 11.46 | Rabi (Oct-Apr) |
| oilseeds | 6282.20 | 0.84 | Rabi (Oct-Mar) |
| pulses | 4837.90 | 1.13 | Rabi (Oct-Mar) |
| jute | 4538.80 | 2.53 | Kharif-1 (Mar-Aug) |
| spices | 3955.00 | 5.09 | Rabi/Kharif |
| potato | 2517.60 | 17.90 | Rabi (Nov-Mar) |
| maize | 1867.00 | 7.61 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
