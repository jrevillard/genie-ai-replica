# ERA5 Climatology: District BD3068

## Baseline Summary
- **Mean temperature climatology:** 25.42 °C
- **Mean evaporation climatology:** -2.99 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
