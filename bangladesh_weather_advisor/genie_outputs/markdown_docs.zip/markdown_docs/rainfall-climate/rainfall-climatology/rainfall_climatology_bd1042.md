# Rainfall Climatology: District BD1042

## Climatology Summary
- **Mean daily climatological rainfall:** 5.79 mm
- **Median (P50) rainfall benchmark:** 3.28 mm
- **Upper percentile (P90) benchmark:** 13.52 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
