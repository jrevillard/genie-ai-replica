# Crop Distribution: Gopalganj District

**Location:** Gopalganj (BD35)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 86063.20 | 3.83 | Kharif-2 (Jul-Dec) |
| rice_boro | 62661.10 | 4.62 | Rabi (Dec-May) |
| jute | 15589.70 | 2.66 | Kharif-1 (Mar-Aug) |
| rice_aus | 13161.20 | 2.72 | Kharif-1 (Mar-Aug) |
| maize | 7875.50 | 9.40 | Rabi (Oct-Apr) |
| potato | 7042.50 | 22.55 | Rabi (Nov-Mar) |
| pulses | 6574.60 | 1.07 | Rabi (Oct-Mar) |
| vegetables | 6505.10 | 10.42 | Rabi (Oct-Apr) |
| oilseeds | 4522.30 | 1.00 | Rabi (Oct-Mar) |
| spices | 4207.20 | 4.96 | Rabi/Kharif |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
