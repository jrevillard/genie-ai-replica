"""
Admin API endpoints — hanya bisa diakses dengan token admin/operator.

Endpoints:
POST /admin/login              → Login, dapat token
GET  /admin/me                 → Info user saat ini
GET  /admin/users              → Daftar pengguna terdaftar
POST /admin/users              → Tambah pengguna
DELETE /admin/users/{phone}    → Hapus pengguna
GET  /admin/reports            → Laporan lapangan dari warga
PUT  /admin/reports/{id}       → Update status laporan
GET  /admin/alerts/history     → Riwayat semua alert
POST /admin/alerts/confirm     → Konfirmasi alert merah
GET  /admin/export/weather     → Export data cuaca CSV
GET  /admin/export/rivers      → Export data sungai CSV
GET  /admin/export/alerts      → Export riwayat alert CSV
POST /admin/broadcast          → Kirim pesan broadcast ke semua user
"""

import csv
import io
from datetime import datetime, timedelta
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from loguru import logger

from api.auth import get_current_user, require_admin, require_operator, authenticate_user, create_token
from data.storage.database import (
    AsyncSessionLocal, RegisteredUser, FieldReport,
    AlertRecord, WeatherReading, RiverReading, ChatSession
)
from config import BANGLADESH_ZONES
from sqlalchemy.future import select
from sqlalchemy import func, desc

router = APIRouter(prefix="/admin", tags=["admin"])


# ─────────────────────────────────────────────
# Models
# ─────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str

class AddUserRequest(BaseModel):
    phone: str
    zone_id: str
    name: Optional[str] = None
    channel: str = "both"
    telegram_id: Optional[str] = None

class BroadcastRequest(BaseModel):
    message: str
    zone_ids: Optional[List[str]] = None  # None = semua zona
    channel: str = "all"  # "whatsapp", "sms", "telegram", "all"

class ConfirmAlertRequest(BaseModel):
    zone_id: str
    confirmed_by: str
    notes: Optional[str] = None


# ─────────────────────────────────────────────
# Auth
# ─────────────────────────────────────────────

@router.post("/login")
async def login(req: LoginRequest):
    """Login dan dapatkan JWT token."""
    user = authenticate_user(req.username, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")

    token = create_token(user["username"], user["role"])
    logger.info(f"Admin login: {user['username']} ({user['role']})")

    return {
        "access_token": token,
        "token_type":   "bearer",
        "username":     user["username"],
        "role":         user["role"],
        "expires_in":   86400,  # 24 jam
    }


@router.get("/me")
async def get_me(user: dict = Depends(get_current_user)):
    """Info user yang sedang login."""
    return {"username": user["sub"], "role": user["role"]}


# ─────────────────────────────────────────────
# User Management
# ─────────────────────────────────────────────

@router.get("/users")
async def list_users(
    zone_id: Optional[str] = None,
    active_only: bool = True,
    limit: int = 100,
    offset: int = 0,
    user: dict = Depends(require_operator),
):
    """Daftar semua pengguna terdaftar."""
    async with AsyncSessionLocal() as db:
        query = select(RegisteredUser)
        if zone_id:
            query = query.where(RegisteredUser.zone_id == zone_id)
        if active_only:
            query = query.where(RegisteredUser.is_active == True)
        query = query.order_by(RegisteredUser.registered_at.desc()).limit(limit).offset(offset)

        result = await db.execute(query)
        users = result.scalars().all()

        # Total count
        count_q = select(func.count()).select_from(RegisteredUser)
        if zone_id:
            count_q = count_q.where(RegisteredUser.zone_id == zone_id)
        if active_only:
            count_q = count_q.where(RegisteredUser.is_active == True)
        total = (await db.execute(count_q)).scalar()

    zone_map = {zid: z.name_en for zid, z in BANGLADESH_ZONES.items()}

    return {
        "total": total,
        "users": [
            {
                "id":           u.id,
                "phone":        u.phone,
                "name":         u.name,
                "zone_id":      u.zone_id,
                "zone_name":    zone_map.get(u.zone_id, u.zone_id),
                "district":     u.district,
                "channel":      u.channel,
                "language":     u.language,
                "is_active":    u.is_active,
                "registered_at": u.registered_at.isoformat() if u.registered_at else None,
                "last_alert":   u.last_alert_sent.isoformat() if u.last_alert_sent else None,
                "telegram_id":  u.telegram_id,
            }
            for u in users
        ],
    }


@router.post("/users")
async def add_user(req: AddUserRequest, user: dict = Depends(require_operator)):
    """Tambah pengguna baru."""
    zone = BANGLADESH_ZONES.get(req.zone_id)
    if not zone:
        raise HTTPException(status_code=400, detail="Invalid zone_id")

    async with AsyncSessionLocal() as db:
        existing = (await db.execute(
            select(RegisteredUser).where(RegisteredUser.phone == req.phone)
        )).scalar_one_or_none()

        if existing:
            existing.zone_id = req.zone_id
            existing.is_active = True
            if req.name:
                existing.name = req.name
            if req.telegram_id:
                existing.telegram_id = req.telegram_id
            await db.commit()
            return {"success": True, "action": "updated", "phone": req.phone}

        new_user = RegisteredUser(
            phone=req.phone, zone_id=req.zone_id, name=req.name,
            district=zone.district, channel=req.channel,
            telegram_id=req.telegram_id, is_active=True,
        )
        db.add(new_user)
        await db.commit()

    logger.info(f"Admin {user['sub']} added user {req.phone} to {req.zone_id}")
    return {"success": True, "action": "created", "phone": req.phone}


@router.delete("/users/{phone}")
async def delete_user(phone: str, user: dict = Depends(require_admin)):
    """Nonaktifkan pengguna (soft delete)."""
    async with AsyncSessionLocal() as db:
        u = (await db.execute(
            select(RegisteredUser).where(RegisteredUser.phone == phone)
        )).scalar_one_or_none()

        if not u:
            raise HTTPException(status_code=404, detail="User not found")

        u.is_active = False
        await db.commit()

    logger.info(f"Admin {user['sub']} deactivated user {phone}")
    return {"success": True, "phone": phone}


# ─────────────────────────────────────────────
# Field Reports
# ─────────────────────────────────────────────

@router.get("/reports")
async def list_reports(
    zone_id: Optional[str] = None,
    unhandled_only: bool = False,
    limit: int = 50,
    user: dict = Depends(require_operator),
):
    """Daftar laporan lapangan dari warga."""
    async with AsyncSessionLocal() as db:
        query = select(FieldReport).order_by(FieldReport.reported_at.desc())
        if zone_id:
            query = query.where(FieldReport.zone_id == zone_id)
        if unhandled_only:
            query = query.where(FieldReport.handled_by == None)
        query = query.limit(limit)

        result = await db.execute(query)
        reports = result.scalars().all()

    zone_map = {zid: z.name_en for zid, z in BANGLADESH_ZONES.items()}

    return {
        "count": len(reports),
        "reports": [
            {
                "id":            r.id,
                "zone_id":       r.zone_id,
                "zone_name":     zone_map.get(r.zone_id, r.zone_id),
                "reporter":      r.reporter_phone,
                "description":   r.description,
                "flood_depth_cm": r.flood_depth_cm,
                "has_casualties": r.has_casualties,
                "reported_at":   r.reported_at.isoformat(),
                "is_verified":   r.is_verified,
                "handled_by":    r.handled_by,
                "media_url":     r.media_url,
            }
            for r in reports
        ],
    }


@router.put("/reports/{report_id}")
async def update_report(
    report_id: int,
    is_verified: Optional[bool] = None,
    handled_by: Optional[str] = None,
    user: dict = Depends(require_operator),
):
    """Update status laporan lapangan."""
    async with AsyncSessionLocal() as db:
        r = (await db.execute(
            select(FieldReport).where(FieldReport.id == report_id)
        )).scalar_one_or_none()

        if not r:
            raise HTTPException(status_code=404, detail="Report not found")

        if is_verified is not None:
            r.is_verified = is_verified
        if handled_by:
            r.handled_by = handled_by or user["sub"]

        await db.commit()

    return {"success": True, "report_id": report_id}


# ─────────────────────────────────────────────
# Alert Management
# ─────────────────────────────────────────────

@router.get("/alerts/history")
async def alert_history(
    days: int = 7,
    zone_id: Optional[str] = None,
    user: dict = Depends(require_operator),
):
    """Riwayat semua alert."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    async with AsyncSessionLocal() as db:
        query = select(AlertRecord).where(
            AlertRecord.issued_at >= cutoff
        ).order_by(AlertRecord.issued_at.desc())
        if zone_id:
            query = query.where(AlertRecord.zone_id == zone_id)

        result = await db.execute(query)
        alerts = result.scalars().all()

    zone_map = {zid: z.name_en for zid, z in BANGLADESH_ZONES.items()}

    return {
        "count": len(alerts),
        "alerts": [
            {
                "id":           a.id,
                "zone_id":      a.zone_id,
                "zone_name":    zone_map.get(a.zone_id, a.zone_id),
                "level":        a.level,
                "prev_level":   a.prev_level,
                "risk_score":   a.risk_score,
                "reason":       a.reason,
                "issued_at":    a.issued_at.isoformat(),
                "is_active":    a.is_active,
                "confirmed_by": a.confirmed_by,
                "resolved_at":  a.resolved_at.isoformat() if a.resolved_at else None,
            }
            for a in alerts
        ],
    }


@router.post("/alerts/confirm")
async def confirm_alert(req: ConfirmAlertRequest, user: dict = Depends(require_operator)):
    """Konfirmasi alert merah oleh petugas BMD."""
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(AlertRecord)
            .where(AlertRecord.zone_id == req.zone_id, AlertRecord.is_active == True)
            .order_by(AlertRecord.issued_at.desc())
            .limit(1)
        )
        alert = result.scalar_one_or_none()
        if not alert:
            raise HTTPException(status_code=404, detail="No active alert for this zone")

        alert.confirmed_by = req.confirmed_by or user["sub"]
        if req.notes:
            alert.reason = (alert.reason or "") + f" | Confirmed: {req.notes}"
        await db.commit()

    logger.info(f"Alert {req.zone_id} confirmed by {req.confirmed_by}")
    return {"success": True, "zone_id": req.zone_id, "confirmed_by": req.confirmed_by}


# ─────────────────────────────────────────────
# Data Export (CSV)
# ─────────────────────────────────────────────

@router.get("/export/weather")
async def export_weather(
    zone_id: str,
    hours: int = 168,
    user: dict = Depends(require_operator),
):
    """Export data cuaca sebagai CSV."""
    cutoff = datetime.utcnow() - timedelta(hours=min(hours, 720))

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(WeatherReading)
            .where(WeatherReading.zone_id == zone_id,
                   WeatherReading.timestamp >= cutoff)
            .order_by(WeatherReading.timestamp.asc())
        )
        rows = result.scalars().all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "timestamp", "zone_id", "temperature_c", "humidity_pct",
        "pressure_hpa", "wind_speed_kmh", "rainfall_1h_mm",
        "rainfall_6h_mm", "weather_desc", "source"
    ])
    for r in rows:
        writer.writerow([
            r.timestamp.isoformat(), r.zone_id, r.temperature,
            r.humidity, r.pressure, r.wind_speed,
            r.rainfall_1h, r.rainfall_6h, r.weather_desc, r.source
        ])

    output.seek(0)
    filename = f"bfews_weather_{zone_id}_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.get("/export/rivers")
async def export_rivers(
    zone_id: str,
    hours: int = 168,
    user: dict = Depends(require_operator),
):
    """Export data sungai sebagai CSV."""
    zone = BANGLADESH_ZONES.get(zone_id)
    if not zone:
        raise HTTPException(status_code=404, detail="Zone not found")

    cutoff = datetime.utcnow() - timedelta(hours=min(hours, 720))

    async with AsyncSessionLocal() as db:
        all_rows = []
        for station_id in zone.river_stations:
            result = await db.execute(
                select(RiverReading)
                .where(RiverReading.station_id == station_id,
                       RiverReading.timestamp >= cutoff)
                .order_by(RiverReading.timestamp.asc())
            )
            all_rows.extend(result.scalars().all())

    all_rows.sort(key=lambda r: r.timestamp)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "timestamp", "station_id", "zone_id",
        "water_level_m", "flow_rate_m3s", "change_6h_m",
        "danger_level_m", "level_pct", "source"
    ])
    for r in all_rows:
        pct = r.water_level_m / (r.danger_level_m or 10)
        writer.writerow([
            r.timestamp.isoformat(), r.station_id, r.zone_id,
            r.water_level_m, r.flow_rate_m3s, r.change_6h_m,
            r.danger_level_m, f"{pct:.3f}", r.source
        ])

    output.seek(0)
    filename = f"bfews_rivers_{zone_id}_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.get("/export/alerts")
async def export_alerts(
    days: int = 30,
    user: dict = Depends(require_operator),
):
    """Export riwayat alert sebagai CSV."""
    cutoff = datetime.utcnow() - timedelta(days=days)

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(AlertRecord)
            .where(AlertRecord.issued_at >= cutoff)
            .order_by(AlertRecord.issued_at.desc())
        )
        rows = result.scalars().all()

    zone_map = {zid: z.name_en for zid, z in BANGLADESH_ZONES.items()}

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "issued_at", "zone_id", "zone_name", "level", "prev_level",
        "risk_score", "reason", "confirmed_by", "is_active", "resolved_at"
    ])
    for r in rows:
        writer.writerow([
            r.issued_at.isoformat(), r.zone_id,
            zone_map.get(r.zone_id, r.zone_id),
            r.level, r.prev_level, r.risk_score, r.reason,
            r.confirmed_by, r.is_active,
            r.resolved_at.isoformat() if r.resolved_at else ""
        ])

    output.seek(0)
    filename = f"bfews_alerts_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


# ─────────────────────────────────────────────
# Broadcast
# ─────────────────────────────────────────────

@router.post("/broadcast")
async def broadcast_message(req: BroadcastRequest, user: dict = Depends(require_operator)):
    """Kirim pesan broadcast ke semua pengguna terdaftar."""
    from notifications.whatsapp_sender import WhatsAppSender, SMSSender

    async with AsyncSessionLocal() as db:
        query = select(RegisteredUser).where(RegisteredUser.is_active == True)
        if req.zone_ids:
            query = query.where(RegisteredUser.zone_id.in_(req.zone_ids))
        result = await db.execute(query)
        users = result.scalars().all()

    wa_numbers = [u.phone for u in users if u.channel in ["whatsapp", "both"]]
    sms_numbers = [u.phone for u in users if u.channel in ["sms", "both"]]

    stats = {"whatsapp": 0, "sms": 0, "total_recipients": len(users)}

    if req.channel in ["whatsapp", "all"] and wa_numbers:
        sender = WhatsAppSender()
        result = await sender.broadcast(wa_numbers, req.message)
        stats["whatsapp"] = result.get("success", 0)

    if req.channel in ["sms", "all"] and sms_numbers:
        sender = SMSSender()
        result = await sender.broadcast_sms(sms_numbers, req.message[:160])
        stats["sms"] = result.get("success", 0)

    logger.info(f"Broadcast by {user['sub']}: {stats}")
    return {"success": True, "stats": stats}


# ─────────────────────────────────────────────
# Dashboard Stats for Admin
# ─────────────────────────────────────────────

@router.get("/dashboard")
async def admin_dashboard_stats(user: dict = Depends(require_operator)):
    """Statistik lengkap untuk admin dashboard."""
    async with AsyncSessionLocal() as db:
        # Users per zone
        result = await db.execute(
            select(RegisteredUser.zone_id, func.count(RegisteredUser.id))
            .where(RegisteredUser.is_active == True)
            .group_by(RegisteredUser.zone_id)
        )
        users_per_zone = dict(result.all())

        # Unhandled reports
        unhandled = (await db.execute(
            select(func.count()).select_from(FieldReport)
            .where(FieldReport.handled_by == None)
        )).scalar()

        # Active alerts
        active_alerts = (await db.execute(
            select(func.count()).select_from(AlertRecord)
            .where(AlertRecord.is_active == True)
        )).scalar()

        # Recent chat sessions (24h)
        cutoff = datetime.utcnow() - timedelta(hours=24)
        recent_chats = (await db.execute(
            select(func.count()).select_from(ChatSession)
            .where(ChatSession.last_active >= cutoff)
        )).scalar()

    zone_map = {zid: z.name_en for zid, z in BANGLADESH_ZONES.items()}

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "users_per_zone": {
            zone_map.get(zid, zid): count
            for zid, count in users_per_zone.items()
        },
        "total_users": sum(users_per_zone.values()),
        "unhandled_reports": unhandled,
        "active_alerts": active_alerts,
        "recent_chats_24h": recent_chats,
    }
