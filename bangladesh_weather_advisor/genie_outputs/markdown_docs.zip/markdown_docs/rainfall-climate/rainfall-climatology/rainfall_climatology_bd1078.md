# Rainfall Climatology: District BD1078

## Climatology Summary
- **Mean daily climatological rainfall:** 7.63 mm
- **Median (P50) rainfall benchmark:** 4.60 mm
- **Upper percentile (P90) benchmark:** 17.42 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
