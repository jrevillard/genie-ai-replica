# Crop Distribution: Rajshahi District

**Location:** Rajshahi (BD81)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 67565.60 | 5.63 | Rabi (Dec-May) |
| rice_aman | 64184.00 | 4.15 | Kharif-2 (Jul-Dec) |
| rice_aus | 15398.80 | 2.33 | Kharif-1 (Mar-Aug) |
| potato | 12311.20 | 17.39 | Rabi (Nov-Mar) |
| maize | 10204.70 | 7.45 | Rabi (Oct-Apr) |
| wheat | 9952.80 | 3.67 | Rabi (Nov-Mar) |
| vegetables | 9285.60 | 10.85 | Rabi (Oct-Apr) |
| pulses | 6158.20 | 1.13 | Rabi (Oct-Mar) |
| oilseeds | 6061.40 | 1.08 | Rabi (Oct-Mar) |
| jute | 5681.20 | 2.63 | Kharif-1 (Mar-Aug) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
