# Crop Distribution: Comilla District

**Location:** Comilla (BD19)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 68077.30 | 3.63 | Kharif-2 (Jul-Dec) |
| rice_boro | 60711.60 | 4.71 | Rabi (Dec-May) |
| rice_aus | 13249.20 | 2.44 | Kharif-1 (Mar-Aug) |
| jute | 7756.10 | 2.08 | Kharif-1 (Mar-Aug) |
| vegetables | 7055.30 | 11.87 | Rabi (Oct-Apr) |
| pulses | 6993.70 | 1.09 | Rabi (Oct-Mar) |
| oilseeds | 4732.90 | 1.07 | Rabi (Oct-Mar) |
| spices | 4485.60 | 4.88 | Rabi/Kharif |
| maize | 3744.60 | 8.81 | Rabi (Oct-Apr) |
| potato | 3285.00 | 19.71 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
