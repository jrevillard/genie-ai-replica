# Soil Profile: Jhenaidah District

**Location:** Jhenaidah (BD44)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.33
- **Clay content:** 39.30%
- **Sand content:** 21.10%
- **Silt content:** 41.10%
- **Soil organic carbon:** 9.55 g/kg
- **CEC:** 21.30 cmol/kg
- **Nitrogen:** 1.01 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
