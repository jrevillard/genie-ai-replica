# Crop Distribution: Gaibandha District

**Location:** Gaibandha (BD32)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 93223.90 | 3.61 | Kharif-2 (Jul-Dec) |
| rice_boro | 69576.40 | 5.09 | Rabi (Dec-May) |
| potato | 15864.00 | 19.45 | Rabi (Nov-Mar) |
| rice_aus | 14776.80 | 2.82 | Kharif-1 (Mar-Aug) |
| wheat | 9681.00 | 3.57 | Rabi (Nov-Mar) |
| maize | 8373.10 | 7.93 | Rabi (Oct-Apr) |
| vegetables | 8302.30 | 11.37 | Rabi (Oct-Apr) |
| pulses | 5635.10 | 1.02 | Rabi (Oct-Mar) |
| jute | 4883.00 | 2.69 | Kharif-1 (Mar-Aug) |
| oilseeds | 4813.60 | 0.98 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
