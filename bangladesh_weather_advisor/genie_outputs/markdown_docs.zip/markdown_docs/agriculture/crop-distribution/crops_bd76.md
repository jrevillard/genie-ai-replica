# Crop Distribution: Natore District

**Location:** Natore (BD76)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 82655.90 | 4.06 | Kharif-2 (Jul-Dec) |
| rice_boro | 69160.60 | 4.70 | Rabi (Dec-May) |
| rice_aus | 12699.60 | 2.65 | Kharif-1 (Mar-Aug) |
| potato | 10584.70 | 18.14 | Rabi (Nov-Mar) |
| maize | 10276.40 | 7.33 | Rabi (Oct-Apr) |
| vegetables | 8487.00 | 13.47 | Rabi (Oct-Apr) |
| wheat | 7922.90 | 3.65 | Rabi (Nov-Mar) |
| pulses | 6687.60 | 1.01 | Rabi (Oct-Mar) |
| oilseeds | 6492.90 | 0.89 | Rabi (Oct-Mar) |
| jute | 5616.90 | 2.61 | Kharif-1 (Mar-Aug) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
