# Crop Distribution: Panchagarh District

**Location:** Panchagarh (BD80)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 73415.20 | 3.50 | Kharif-2 (Jul-Dec) |
| rice_boro | 71427.80 | 4.61 | Rabi (Dec-May) |
| rice_aus | 18322.40 | 3.03 | Kharif-1 (Mar-Aug) |
| potato | 12162.60 | 18.33 | Rabi (Nov-Mar) |
| maize | 9630.00 | 8.46 | Rabi (Oct-Apr) |
| wheat | 8084.00 | 3.06 | Rabi (Nov-Mar) |
| vegetables | 6987.70 | 10.46 | Rabi (Oct-Apr) |
| pulses | 6372.70 | 0.96 | Rabi (Oct-Mar) |
| oilseeds | 5053.90 | 0.97 | Rabi (Oct-Mar) |
| jute | 4630.70 | 2.72 | Kharif-1 (Mar-Aug) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
