# Soil Profile: Panchagarh District

**Location:** Panchagarh (BD80)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 5.63
- **Clay content:** 24.90%
- **Sand content:** 36.10%
- **Silt content:** 40.70%
- **Soil organic carbon:** 9.70 g/kg
- **CEC:** 13.40 cmol/kg
- **Nitrogen:** 1.08 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
