# Soil Profile: Netrokona District

**Location:** Netrokona (BD74)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 6.21
- **Clay content:** 31.40%
- **Sand content:** 29.30%
- **Silt content:** 41.30%
- **Soil organic carbon:** 11.30 g/kg
- **CEC:** 18.80 cmol/kg
- **Nitrogen:** 1.26 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
