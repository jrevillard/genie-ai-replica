# Rainfall Climatology: District BD1006

## Climatology Summary
- **Mean daily climatological rainfall:** 6.05 mm
- **Median (P50) rainfall benchmark:** 3.48 mm
- **Upper percentile (P90) benchmark:** 14.02 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
