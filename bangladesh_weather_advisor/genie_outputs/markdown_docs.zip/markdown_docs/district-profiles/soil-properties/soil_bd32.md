# Soil Profile: Gaibandha District

**Location:** Gaibandha (BD32)

## Soil Characteristics
- **Soil region:** Tista_Floodplain
- **Soil pH:** 5.67
- **Clay content:** 25.60%
- **Sand content:** 35.20%
- **Silt content:** 39.30%
- **Soil organic carbon:** 10.24 g/kg
- **CEC:** 14.30 cmol/kg
- **Nitrogen:** 1.15 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
