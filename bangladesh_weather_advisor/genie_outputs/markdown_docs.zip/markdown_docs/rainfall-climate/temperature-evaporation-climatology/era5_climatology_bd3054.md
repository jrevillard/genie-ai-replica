# ERA5 Climatology: District BD3054

## Baseline Summary
- **Mean temperature climatology:** 25.72 °C
- **Mean evaporation climatology:** -2.95 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
