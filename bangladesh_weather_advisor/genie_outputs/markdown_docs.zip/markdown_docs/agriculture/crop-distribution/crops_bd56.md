# Crop Distribution: Madaripur District

**Location:** Madaripur (BD56)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 72294.20 | 4.36 | Rabi (Dec-May) |
| rice_aman | 65227.60 | 4.38 | Kharif-2 (Jul-Dec) |
| rice_aus | 16229.10 | 2.36 | Kharif-1 (Mar-Aug) |
| jute | 11397.20 | 2.52 | Kharif-1 (Mar-Aug) |
| maize | 8989.50 | 8.25 | Rabi (Oct-Apr) |
| vegetables | 8974.30 | 10.99 | Rabi (Oct-Apr) |
| potato | 7163.60 | 22.03 | Rabi (Nov-Mar) |
| pulses | 5317.10 | 0.97 | Rabi (Oct-Mar) |
| oilseeds | 4475.10 | 1.09 | Rabi (Oct-Mar) |
| wheat | 4272.70 | 3.57 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
