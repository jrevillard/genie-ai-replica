# Rainfall Climatology: District BD5549

## Climatology Summary
- **Mean daily climatological rainfall:** 7.08 mm
- **Median (P50) rainfall benchmark:** 4.04 mm
- **Upper percentile (P90) benchmark:** 16.48 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
