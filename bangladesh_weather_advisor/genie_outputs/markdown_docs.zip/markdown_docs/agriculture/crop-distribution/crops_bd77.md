# Crop Distribution: Nawabganj District

**Location:** Nawabganj (BD77)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 87428.40 | 3.87 | Kharif-2 (Jul-Dec) |
| rice_boro | 59297.70 | 5.48 | Rabi (Dec-May) |
| rice_aus | 14016.30 | 2.79 | Kharif-1 (Mar-Aug) |
| maize | 10166.90 | 7.94 | Rabi (Oct-Apr) |
| potato | 9775.40 | 19.83 | Rabi (Nov-Mar) |
| wheat | 8044.90 | 3.58 | Rabi (Nov-Mar) |
| vegetables | 6811.50 | 11.06 | Rabi (Oct-Apr) |
| oilseeds | 6275.10 | 1.06 | Rabi (Oct-Mar) |
| jute | 5779.30 | 2.16 | Kharif-1 (Mar-Aug) |
| pulses | 5281.60 | 1.11 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
