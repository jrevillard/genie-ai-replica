# Soil Profile: Kushtia District

**Location:** Kushtia (BD57)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 6.95
- **Clay content:** 36.70%
- **Sand content:** 22.40%
- **Silt content:** 39.30%
- **Soil organic carbon:** 9.99 g/kg
- **CEC:** 22.10 cmol/kg
- **Nitrogen:** 0.99 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
