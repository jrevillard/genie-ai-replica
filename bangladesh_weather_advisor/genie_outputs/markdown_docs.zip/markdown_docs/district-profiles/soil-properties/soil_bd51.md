# Soil Profile: Lakshmipur District

**Location:** Lakshmipur (BD51)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 6.83
- **Clay content:** 42.50%
- **Sand content:** 14.30%
- **Silt content:** 42.90%
- **Soil organic carbon:** 14.16 g/kg
- **CEC:** 23.70 cmol/kg
- **Nitrogen:** 1.34 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
