# Soil Profile: Magura District

**Location:** Magura (BD65)

## Soil Characteristics
- **Soil region:** Ganges_Floodplain
- **Soil pH:** 7.51
- **Clay content:** 39.30%
- **Sand content:** 21.70%
- **Silt content:** 38.20%
- **Soil organic carbon:** 9.61 g/kg
- **CEC:** 21.80 cmol/kg
- **Nitrogen:** 1.02 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
