# Rainfall Climatology: District BD6090

## Climatology Summary
- **Mean daily climatological rainfall:** 11.22 mm
- **Median (P50) rainfall benchmark:** 7.68 mm
- **Upper percentile (P90) benchmark:** 24.24 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
