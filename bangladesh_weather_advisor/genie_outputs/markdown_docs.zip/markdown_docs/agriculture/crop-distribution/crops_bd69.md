# Crop Distribution: Meherpur District

**Location:** Meherpur (BD69)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_boro | 85091.00 | 4.71 | Rabi (Dec-May) |
| rice_aman | 74445.20 | 3.92 | Kharif-2 (Jul-Dec) |
| rice_aus | 15515.50 | 2.37 | Kharif-1 (Mar-Aug) |
| vegetables | 8481.50 | 13.09 | Rabi (Oct-Apr) |
| jute | 7860.90 | 2.16 | Kharif-1 (Mar-Aug) |
| pulses | 6827.40 | 1.11 | Rabi (Oct-Mar) |
| oilseeds | 6039.70 | 0.99 | Rabi (Oct-Mar) |
| spices | 3343.20 | 3.87 | Rabi/Kharif |
| potato | 3027.20 | 22.23 | Rabi (Nov-Mar) |
| maize | 2297.40 | 7.55 | Rabi (Oct-Apr) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
