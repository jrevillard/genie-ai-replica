# ERA5 Climatology: District BD4572

## Baseline Summary
- **Mean temperature climatology:** 24.71 °C
- **Mean evaporation climatology:** -2.79 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
