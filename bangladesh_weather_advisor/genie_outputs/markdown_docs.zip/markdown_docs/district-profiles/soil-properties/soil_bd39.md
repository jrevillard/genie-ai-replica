# Soil Profile: Jamalpur District

**Location:** Jamalpur (BD39)

## Soil Characteristics
- **Soil region:** Old_Brahmaputra_Floodplain
- **Soil pH:** 6.33
- **Clay content:** 31.90%
- **Sand content:** 27.80%
- **Silt content:** 38.10%
- **Soil organic carbon:** 10.97 g/kg
- **CEC:** 17.70 cmol/kg
- **Nitrogen:** 1.25 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
