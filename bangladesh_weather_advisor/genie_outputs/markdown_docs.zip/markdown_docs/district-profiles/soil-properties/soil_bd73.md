# Soil Profile: Narsingdi District

**Location:** Narsingdi (BD73)

## Soil Characteristics
- **Soil region:** Urban_Peri_Urban
- **Soil pH:** 6.26
- **Clay content:** 28.70%
- **Sand content:** 28.90%
- **Silt content:** 39.60%
- **Soil organic carbon:** 9.92 g/kg
- **CEC:** 16.10 cmol/kg
- **Nitrogen:** 0.96 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
