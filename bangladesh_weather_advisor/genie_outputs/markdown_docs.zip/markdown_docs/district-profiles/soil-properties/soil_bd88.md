# Soil Profile: Sirajganj District

**Location:** Sirajganj (BD88)

## Soil Characteristics
- **Soil region:** Barind_Tract
- **Soil pH:** 6.26
- **Clay content:** 43.60%
- **Sand content:** 17.20%
- **Silt content:** 36.70%
- **Soil organic carbon:** 7.40 g/kg
- **CEC:** 20.70 cmol/kg
- **Nitrogen:** 0.76 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
