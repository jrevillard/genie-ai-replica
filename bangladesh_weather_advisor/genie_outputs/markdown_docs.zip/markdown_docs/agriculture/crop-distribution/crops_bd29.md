# Crop Distribution: Faridpur District

**Location:** Faridpur (BD29)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 95085.60 | 4.26 | Kharif-2 (Jul-Dec) |
| rice_boro | 71105.30 | 5.15 | Rabi (Dec-May) |
| jute | 12654.60 | 2.75 | Kharif-1 (Mar-Aug) |
| rice_aus | 12563.70 | 2.33 | Kharif-1 (Mar-Aug) |
| vegetables | 7663.50 | 12.52 | Rabi (Oct-Apr) |
| maize | 6604.90 | 8.94 | Rabi (Oct-Apr) |
| potato | 6183.10 | 20.64 | Rabi (Nov-Mar) |
| pulses | 5889.70 | 1.14 | Rabi (Oct-Mar) |
| oilseeds | 5879.80 | 0.85 | Rabi (Oct-Mar) |
| wheat | 4676.90 | 3.44 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
