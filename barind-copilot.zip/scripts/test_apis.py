"""
Test semua API keys yang terpasang di .env
Jalankan: python scripts/test_apis.py
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from loguru import logger
logger.remove()
logger.add(sys.stderr, level="WARNING")


async def test_groq_english():
    print("\n" + "="*55)
    print("TEST 1: Groq AI — English")
    print("="*55)

    from chatbot.nlp.groq_client import groq_client, GROQ_MODEL

    if not groq_client.available:
        print("❌ GROQ_API_KEY tidak dikonfigurasi")
        print("   → Daftar gratis di: https://console.groq.com")
        return False

    key_preview = os.getenv("GROQ_API_KEY", "")[-8:]
    print(f"✅ API key ditemukan: ...{key_preview}")
    print(f"   Model: {GROQ_MODEL}")

    result = await groq_client.generate_response(
        user_message="Is it safe to go outside in Sylhet today? Should I be worried about flooding?",
        conversation_history=[],
        context_data={
            "zone_name_en": "Sylhet Sadar",
            "zone_name_bn": "সিলেট সদর",
            "alert_level":  "yellow",
            "risk_score":   0.48,
            "weather": {
                "temperature": 29, "humidity": 88,
                "rainfall_1h": 8, "rainfall_6h": 35,
                "wind_speed": 22, "weather_desc": "Heavy rain",
                "pressure": 1005,
            },
            "river_data": [{
                "station_id":    "surma_sylhet",
                "name":          "Surma River at Sylhet",
                "water_level_m": 8.9,
                "danger_level_m": 10.5,
                "level_pct":     0.85,
                "change_6h_m":   0.6,
            }],
            "forecast": {"horizons": {
                6:  {"rainfall_mm": 20, "flood_prob": 0.35},
                12: {"rainfall_mm": 40, "flood_prob": 0.50},
                24: {"rainfall_mm": 65, "flood_prob": 0.65},
            }},
            "reasons": ["Heavy rainfall: 35mm in 6h", "River near danger level (85%)", "Rising trend: +0.6m in 6h"],
        },
        lang="en"
    )

    if result:
        print(f"✅ Groq BERHASIL! ({len(result)} chars)\n")
        print("─" * 50)
        print(result)
        print("─" * 50)
        return True
    else:
        print("❌ Groq GAGAL — cek API key dan koneksi")
        return False


async def test_groq_bengali():
    print("\n" + "="*55)
    print("TEST 2: Groq AI — Bengali (বাংলা)")
    print("="*55)

    from chatbot.nlp.groq_client import groq_client
    if not groq_client.available:
        print("⏭️  Skip (API key tidak ada)")
        return False

    result = await groq_client.generate_response(
        user_message="আজকে কি বাইরে যাওয়া নিরাপদ? বন্যার ঝুঁকি কতটুকু?",
        conversation_history=[],
        context_data={
            "zone_name_en": "Dhaka City",
            "zone_name_bn": "ঢাকা শহর",
            "alert_level":  "red",
            "risk_score":   0.78,
            "weather": {
                "temperature": 31, "humidity": 92,
                "rainfall_1h": 25, "rainfall_6h": 95,
                "wind_speed": 45, "weather_desc": "Thunderstorm",
                "pressure": 998,
            },
            "river_data": [{
                "station_id":    "buriganga",
                "name":          "Buriganga River",
                "water_level_m": 6.2,
                "danger_level_m": 6.0,
                "level_pct":     1.03,
                "change_6h_m":   0.9,
            }],
            "forecast": {"horizons": {
                6:  {"rainfall_mm": 50, "flood_prob": 0.75},
                24: {"rainfall_mm": 90, "flood_prob": 0.85},
            }},
            "reasons": ["River ABOVE danger level (103%)", "Extreme rainfall: 95mm/6h", "Pressure drop: cyclone risk"],
        },
        lang="auto"  # auto-detect Bengali
    )

    if result:
        print(f"✅ Bengali response ({len(result)} chars)\n")
        print("─" * 50)
        print(result)
        print("─" * 50)
        return True
    else:
        print("❌ Bengali test GAGAL")
        return False


async def test_groq_intent():
    print("\n" + "="*55)
    print("TEST 3: Groq Intent Classification")
    print("="*55)

    from chatbot.nlp.groq_client import groq_client
    if not groq_client.available:
        print("⏭️  Skip (API key tidak ada)")
        return False

    test_cases = [
        ("Will it flood tomorrow in Cox's Bazar?", "forecast_query"),
        ("আশ্রয়কেন্দ্র কোথায়?",                  "evacuation_query"),
        ("I need help, water is rising fast",      "help_query"),
        ("What is the river level right now?",     "river_query"),
    ]

    passed = 0
    for msg, expected in test_cases:
        intent = await groq_client.classify_intent(msg)
        ok = intent == expected
        if ok:
            passed += 1
        status = "✅" if ok else "⚠️ "
        print(f"  {status} '{msg[:45]}' → {intent or 'None'} (expected: {expected})")

    print(f"\n  Result: {passed}/{len(test_cases)} correct")
    return passed >= 3


async def test_openweathermap():
    print("\n" + "="*55)
    print("TEST 4: OpenWeatherMap API")
    print("="*55)

    from config import OPENWEATHER_API_KEY
    if not OPENWEATHER_API_KEY or "your_" in OPENWEATHER_API_KEY:
        print("⏭️  Skip (API key tidak dikonfigurasi)")
        return False

    print(f"✅ Key: ...{OPENWEATHER_API_KEY[-8:]}")
    from data.ingestion.weather_collector import fetch_openweathermap
    data = await fetch_openweathermap(23.8103, 90.4125)  # Dhaka

    if data:
        print(f"✅ OK — Dhaka: {data['temperature']}°C, {data['weather_desc']}, "
              f"wind {data['wind_speed']:.0f} km/h, rain {data['rainfall_1h']}mm/h")
        return True
    else:
        print("❌ GAGAL — cek API key")
        return False


async def test_openmeteo():
    print("\n" + "="*55)
    print("TEST 5: Open-Meteo (Free, No Key)")
    print("="*55)

    from data.ingestion.weather_collector import fetch_openmeteo
    data = await fetch_openmeteo(24.8949, 91.8687)  # Sylhet

    if data:
        print(f"✅ OK — Sylhet: {data['temperature']}°C, {data['weather_desc']}, "
              f"wind {data['wind_speed']} km/h, rain 6h: {data['rainfall_6h']} mm")
        return True
    else:
        print("❌ GAGAL (cek koneksi internet)")
        return False


async def main():
    print("╔══════════════════════════════════════════════════════╗")
    print("║     BFEWS — API Key Verification                     ║")
    print("╚══════════════════════════════════════════════════════╝")

    results = {}
    results["Groq AI (English)"]  = await test_groq_english()
    results["Groq AI (Bengali)"]  = await test_groq_bengali()
    results["Groq Intent Classify"] = await test_groq_intent()
    results["OpenWeatherMap"]     = await test_openweathermap()
    results["Open-Meteo"]         = await test_openmeteo()

    print("\n" + "="*55)
    print("SUMMARY")
    print("="*55)
    for name, ok in results.items():
        icon = "✅" if ok else "❌"
        print(f"  {icon}  {name}")

    passed = sum(1 for v in results.values() if v)
    print(f"\n  {passed}/{len(results)} tests passed")

    groq_ok = results.get("Groq AI (English)")
    weather_ok = results.get("Open-Meteo")

    if groq_ok and weather_ok:
        print("\n✅ System ready! Run: python main.py")
        print("   Then open: http://localhost:8000")
    elif not groq_ok:
        print("\n⚠️  Groq not working. Steps:")
        print("   1. Go to https://console.groq.com")
        print("   2. Sign up (free, no credit card)")
        print("   3. API Keys → Create API Key")
        print("   4. Paste key in .env: GROQ_API_KEY=gsk_...")
        print("   5. Run this test again")


if __name__ == "__main__":
    asyncio.run(main())
