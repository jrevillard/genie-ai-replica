# Crop Distribution: Rangpur District

**Location:** Rangpur (BD85)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 93933.40 | 4.26 | Kharif-2 (Jul-Dec) |
| rice_boro | 79392.40 | 5.79 | Rabi (Dec-May) |
| rice_aus | 13586.50 | 2.35 | Kharif-1 (Mar-Aug) |
| potato | 13386.40 | 21.03 | Rabi (Nov-Mar) |
| maize | 10636.70 | 8.17 | Rabi (Oct-Apr) |
| wheat | 8477.60 | 2.79 | Rabi (Nov-Mar) |
| vegetables | 6780.50 | 12.07 | Rabi (Oct-Apr) |
| pulses | 6771.60 | 1.10 | Rabi (Oct-Mar) |
| jute | 5748.10 | 2.28 | Kharif-1 (Mar-Aug) |
| oilseeds | 4400.40 | 0.85 | Rabi (Oct-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
