# Crop Distribution: Cox's Bazar District

**Location:** Cox's Bazar (BD26)

## Major Crops
| Crop | Area (ha) | Yield (t/ha) | Season |
|---|---:|---:|---|
| rice_aman | 78981.20 | 3.40 | Kharif-2 (Jul-Dec) |
| rice_boro | 62554.30 | 4.35 | Rabi (Dec-May) |
| rice_aus | 11079.20 | 2.39 | Kharif-1 (Mar-Aug) |
| vegetables | 9064.70 | 11.72 | Rabi (Oct-Apr) |
| jute | 8668.80 | 2.73 | Kharif-1 (Mar-Aug) |
| oilseeds | 6527.50 | 0.95 | Rabi (Oct-Mar) |
| pulses | 4887.40 | 1.25 | Rabi (Oct-Mar) |
| spices | 3632.20 | 4.32 | Rabi/Kharif |
| maize | 3325.10 | 7.61 | Rabi (Oct-Apr) |
| potato | 2578.40 | 19.49 | Rabi (Nov-Mar) |

## Interpretation
Crop distribution in this district indicates the dominant crop portfolio and seasonal priorities for drought advisory context.

---
*Source: MAPSPAM_BBS_reference*
