# Soil Profile: Habiganj District

**Location:** Habiganj (BD38)

## Soil Characteristics
- **Soil region:** Sylhet_Basin
- **Soil pH:** 5.21
- **Clay content:** 30.50%
- **Sand content:** 20.80%
- **Silt content:** 50.50%
- **Soil organic carbon:** 18.56 g/kg
- **CEC:** 19.70 cmol/kg
- **Nitrogen:** 1.77 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
