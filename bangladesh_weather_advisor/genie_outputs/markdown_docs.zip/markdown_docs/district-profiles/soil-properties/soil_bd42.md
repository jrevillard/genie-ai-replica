# Soil Profile: Jhalokati District

**Location:** Jhalokati (BD42)

## Soil Characteristics
- **Soil region:** Meghna_Estuarine_Floodplain
- **Soil pH:** 7.04
- **Clay content:** 42.90%
- **Sand content:** 15.20%
- **Silt content:** 44.00%
- **Soil organic carbon:** 13.26 g/kg
- **CEC:** 23.70 cmol/kg
- **Nitrogen:** 1.36 g/kg

## Interpretation
These soil properties support crop suitability assessment and district-level drought resilience analysis.

---
*Source: SoilGrids_reference*
