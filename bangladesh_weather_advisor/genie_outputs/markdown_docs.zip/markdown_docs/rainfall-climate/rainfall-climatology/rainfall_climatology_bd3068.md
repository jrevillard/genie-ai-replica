# Rainfall Climatology: District BD3068

## Climatology Summary
- **Mean daily climatological rainfall:** 5.64 mm
- **Median (P50) rainfall benchmark:** 3.38 mm
- **Upper percentile (P90) benchmark:** 12.94 mm
- **Coverage:** 366 day-of-year records

## Interpretation
This document provides district climatology baselines used for anomaly and drought computations.

---
*Source: gee_chirps_climatology*
