# ERA5 Climatology: District BD2022

## Baseline Summary
- **Mean temperature climatology:** 25.63 °C
- **Mean evaporation climatology:** -3.23 mm
- **Coverage:** 366 day-of-year baseline records

## Purpose
This baseline supports anomaly detection and drought index calculations.

---
*Source: gee_era5_climatology*
